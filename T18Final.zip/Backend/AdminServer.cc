#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <ctype.h>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include "KVcommunication.h"
#include "backLog.h"
#include "defaultport.h"
#include "basicServer.h"
#include "interface.h"
#include "MapFileFunctions.h"
#include "commandOperation.h"
#include "BackendMaster.h"
#define TRUE   1
#define FALSE  0
int PORT;
vector<int> portvec;
int debug = 0;
int second = 0;
int masterPort = 0;
int adminPort = 0;
using namespace std;
int mode = 0;
//MapFile MF;
command kvCommand;
backendMaster bm;
InterFaceAPI IFA;
vector<int> lostConnection;
map<int, int> port2socket;
void reconnectPort(basicServer &socketInfo, int port, int outport) {
	if (!socketInfo.checkPort(outport)) {
		int reconnect_socket = reconnectServer(port, outport);
		if (reconnect_socket < 0) {
			printf("Port %d should be open first\n", outport);
			//									exit(1);
		} else {
			printf("Connect to %d\n", outport);
			socketInfo.put(outport, reconnect_socket);
		}
	}
}

void send2port(int port, string &buffer, basicServer &socketInfo) {
	if (send(socketInfo.getSocketbyport(port), buffer.c_str(),
			strlen(buffer.c_str()), 0) != strlen(buffer.c_str())) {
		perror("send");
	}
}
void reply(int socket, string &buffer) {
	if (send(socket, buffer.c_str(), strlen(buffer.c_str()), 0)
			!= strlen(buffer.c_str())) {
		perror("send");
	}
}
void shutAllserver(basicServer &socketInfo, int max_clients,
		int master_socket) {
	for (int i = 0; i < max_clients; i++) {
		int sock = socketInfo.getSocketbyid(i);
		if (sock > 0 && sock != master_socket) {
			shutServer(sock);
			socketInfo.removeSocket(sock);
		}
	}
}
void MapToFILE(unordered_map<string, unordered_map<string, string>> hMap,
		string fileName) {
	//cout << "enter this function map to file" << endl;
	if (hMap.size() == 0) {
		cout << " map size is zero" << endl;
		return;
	}
	FILE *fp;
	fp = fopen(fileName.c_str(), "w");
	for (auto it : hMap) {
		string userName = it.first;
		for (auto inner : hMap[userName]) {
			if (inner.first.length() == 0) {
				continue;
			}
			string message = userName + " " + inner.first + " " + inner.second
					+ "\r\n";
			fprintf(fp, "%s", message.c_str());
			fflush(fp);
		}
	}
}

unordered_map<string, unordered_map<string, string>> FileToMap(
		string fileName) {
	unordered_map<string, unordered_map<string, string>> result;
	if (fileName.length() == 0) {
		return result;
	}
	printf("start\n");
	FILE *fp;
	if((fp = fopen(fileName.c_str(), "r")) == NULL){
		return result;
	}
//	fp = fopen(fileName.c_str(), "r");
	char line[1024];
	string latter = "";
	while (fgets(line, 1024, fp)) {
		printf("%s\n",line);
		if (strcmp(line, "") == 0) {
			break;
		}
		latter.append(line);
		int k1 = latter.find("\r\n");
		while (k1 != std::string::npos) {
			string allMsg = latter.substr(0, k1);
			latter = latter.substr(k1 + 2);
			int k2 = allMsg.find(" ");
			string username = allMsg.substr(0, k2);
			allMsg = allMsg.substr(k2 + 1);
			k2 = allMsg.find(" ");
			string column = allMsg.substr(0, k2);
			string value = allMsg.substr(k2 + 1);
			result[username][column] = value;
			k1 = latter.find("\r\n");
		}
	}
	return result;
}
int main(int argc, char *argv[]) {
	int sopt = TRUE;
	int master_socket, addrlen, client_socket[30], max_clients = 30, activity,
			i, valread, sd;
	map<int, string> client_socket_add;
	map<int, int> client_socket_port;
	map<int, int> client_port2socket;
	int max_sd;

	char buffer[102400];
	int PORTbuffer[3];

	int opt;
	string path = "";
	string modeString = "";
	int masterPort = 8014;
	int adminPort = 8020;
	int checkPort = 8001;
	int listen_socket, admin_socket, primary_socket, second_socket1,
			second_socket2, check_socket;
//	MF.constructKeyWord();
	while ((opt = getopt(argc, argv, "p:av")) != -1) {
		switch (opt) {
		case 'p':
			PORT = atoi(optarg);
			break;
		case 'a':
			fprintf(stderr, "Name: Shaozhe Lyu, Login: shaozhe\n");
			exit(1);
			break;
		case 'v':
			debug = 1;
			break;
		case '?':
			break;
		}
	}
	backLog log;
	log.setLog(path, PORT);
	string fname = "DataFile - " + to_string(PORT);
	IFA.serverDataMap = FileToMap(fname);
	InterFaceAPI IFA_log_begin;
	vector < string > logVector;
	logVector = log.readFile();
	int receiveData = 0;
	for (int i = 0; i < logVector.size(); i++) {
		IFA_log_begin.checkCommand(logVector[i]);
	}

	if (IFA_log_begin.serverDataMap.size() != 0) {
		for (auto it : IFA_log_begin.serverDataMap) {
			string outKey = it.first;
			unordered_map < string, string > innerMap =
					IFA_log_begin.serverDataMap[outKey];
			for (auto iit : innerMap) {
				string innerKey = iit.first;
				IFA.serverDataMap[outKey][innerKey] =
						IFA_log_begin.serverDataMap[outKey][innerKey];
			}
		}
	}

	printf("%s\n", log.showmode() ? "WRITE" : "READ");

	basicServer socketInfo;
	socketInfo.setServer(max_clients);

	for (i = 0; i < max_clients; i++) {
		client_socket[i] = 0;
	}
	admin_socket = 0;
	master_socket = 0;
	int shutdown = 0;
	int start2write = 0;

	listen_socket = listenServer(PORT, 10);
	master_socket = reconnectServer(PORT, masterPort);
	if (master_socket < 0) {
		printf("Master port should be open first\n");
		exit(1);
	}
	socketInfo.put(masterPort, master_socket);

	fd_set readfds;
	int lost = 0;
	int only_once = 0;

	while (TRUE) {

		FD_ZERO(&readfds);
		FD_SET(listen_socket, &readfds);
		max_sd = listen_socket;
		for (i = 0; i < max_clients; i++) {
			sd = socketInfo.getSocketbyid(i);
			if (sd > 0) {
				FD_SET(sd, &readfds);
			}
			if (sd > max_sd) {
				max_sd = sd;
			}
		}
		activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
		if ((activity < 0) && (errno != EINTR)) {
			printf("select error %d %d\n", activity, errno);
		}
		//accept new connection from new port
		int newportAcc;
		if (FD_ISSET(listen_socket, &readfds)) {
			newportAcc = acceptNewclient(listen_socket, socketInfo);
		}

		for (i = 0; i < max_clients; i++) {
			sd = socketInfo.getSocketbyid(i);
			if (FD_ISSET(sd, &readfds)) {
				int globalPort = socketInfo.getPortbysocket(sd);
				if (shutdown == 1 && sd != admin_socket) {
					continue;
				}
				struct sockaddr_in clientaddr;
				socklen_t cliendaddrlen = sizeof(clientaddr);
				if ((valread = read(sd, buffer, 102400)) == 0) {
					getpeername(sd, (struct sockaddr*) &clientaddr,
							(socklen_t*) &cliendaddrlen);
					int sock = sd;
					checkClient(sock, ntohs(clientaddr.sin_port),
							inet_ntoa(clientaddr.sin_addr), 1);
					printf("port is :%d, data port:%d\n",
							ntohs(clientaddr.sin_port),
							socketInfo.getPortbysocket(sd));
					string removedport = to_string(
							socketInfo.getPortbysocket(sd));
					close(sd);
					socketInfo.removeSocket(sd);
				} else {
					buffer[valread] = '\0';
					string m = "";
					m.append(buffer);
					printf("data: %s\n", m.c_str());

					if (m.length() < 5) {
						continue;
					}
					string comp = m.substr(0, 4);
					string out = m.substr(5);
					int adminTransPort = atoi(comp.c_str());
					if (globalPort == 8014 || globalPort == 5001
							|| globalPort == 5002 || globalPort == 5003
							|| globalPort == 6001 || globalPort == 6002
							|| globalPort == 6003 || globalPort == 7001
							|| globalPort == 7002 || globalPort == 7003) {
						continue;
					}

					if (socketInfo.checkPort(adminTransPort)) {
						printf("adminTransPort:%d out:%s\n", adminTransPort,
								out.c_str());
						send2port(adminTransPort, out, socketInfo);
						char *buf = (char*) malloc(sizeof(char) * 100000);
						if (buf == NULL)
							perror("Malloc Failed");
						memset(buf, '\0', sizeof(char) * 100000);
						string Msg = "";
						while (valread = read(
								socketInfo.getSocketbyport(adminTransPort), buf,
								100000) != 0) {
							Msg.append(buf);
							break;
						};

						reply(sd, Msg);
					} else {
						string errMsg = "-400 ERR";
//						printf(errMsg);
						reply(sd, errMsg);
					}

				}
			}
		}
	}
	return 0;
}
