#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <iostream>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <vector>
#include <unordered_set>
#include <map>
#include <sstream> 
#include <limits.h>

using namespace std;

#define max_connection 256 //max connection concurrenctly
int vflag = 0;  // vflag for -v user input
volatile int sig_flag = 0;  // volatile sig_flag for synchronization connection while signal captured

unordered_set<pthread_t> thread_set;
unordered_set<int> sock_set;

vector<int> fe_ports = {10000, 10001,10002};

// write to client with while loop
int sock_write(int fd, char *buffer){
	int total_len = strlen(buffer);
	int sent_byte = 0;
	while(sent_byte < total_len){
		int one_time_sent = write(fd, &buffer[sent_byte],total_len-sent_byte);
		if(one_time_sent < 0){
	        fprintf(stderr, "error write (server)\n");
	        exit(1);
		}
		sent_byte += one_time_sent;
	}
	return sent_byte;
}

// handle sigint in main thread
void sig_handler (int signuum ) {
	sig_flag = 1;
	for(auto sock: sock_set){
		cout << sock << endl;
		sock_write(sock,(char *)"-ERR Server shutting down\r\n");
		if(close(sock) < 0){
		    fprintf(stderr,"error close %d socket", sock);
			exit(1);
		}
	}

	for(auto thread: thread_set){
		pthread_cancel(thread);
	}
	exit(0);
}

// thread working
void *thread_handler(void *new_sock)
{

    int brower_sock = *(int*)new_sock;
    char *write_msg;
    char read_buffer[1025];
    map<int,int> port_to_num;

    for(int i = 0 ; i < fe_ports.size(); i++){
    	int feport = fe_ports[i];
    	int master_sock;
        if ((master_sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
        { 
            fprintf(stderr,"Socket creation error \n"); 
            exit(1);
        }
        struct sockaddr_in serv_addr; 
        serv_addr.sin_family = AF_INET; 
        serv_addr.sin_port = htons(feport); 
        if(inet_pton(AF_INET, "0.0.0.0", &serv_addr.sin_addr)<=0)  
        { 
            fprintf(stderr,"Invalid address/ Address not supported \n"); 
            exit(1);
        }
        cout << "master " << master_sock << endl;
        if (connect(master_sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) 
        { 
            cout << feport << " is down" << endl;
            continue;
        } 
        write_msg = (char*)"MASTER QUERY/r/n";
        sock_write(master_sock,write_msg);
        
        int valread = read( master_sock , read_buffer, 1024); 
        read_buffer[valread] = '\0';
        cout << read_buffer << endl;
        char* cur_port = strtok(read_buffer, " ");
        char* port_num = strtok(NULL,"");

        stringstream cur_port_str(cur_port);
        stringstream port_num_str(port_num);
        
        int cur_port_int = 0;
        int port_num_int = 0;
        
        cur_port_str >> cur_port_int;
        port_num_str >> port_num_int;
        
        port_to_num[cur_port_int] = port_num_int;
  
    }
    int chose_port;
    int chose_num = INT_MAX;
    for(auto itr = port_to_num.begin(); itr != port_to_num.end(); itr++){
    	if(itr -> second < chose_num){
    		chose_port = itr -> first;
    		chose_num = itr -> second;
    	}
    }
    stringstream sendstream;
    sendstream << "<head>\n";
    sendstream << "  <meta http-equiv=\"refresh\" content=\"5; URL=http://localhost:" << to_string(chose_port) << "/home\" />\n";
    sendstream << "</head>\n";
    sendstream << "<body>\n";
    sendstream << "  <p>If you are not redirected in five seconds, <a href=\"http://localhost:"<< to_string(chose_port) << "/home\">click here</a>.</p>\n";
    sendstream << "</body>";
    
    string sendstr = sendstream.str();
    string totest = string("HTTP/1.1 200 OK\r\n") + "Content-type: text/html\r\n" + "Content-length: "+ to_string(sendstr.length())+"\r\n" + "\r\n";
    totest = totest + sendstr;
    sock_write(brower_sock,&totest[0]);
    cout << totest << endl;
    sock_set.erase(brower_sock);
	if(close(brower_sock) < 0){
	    fprintf(stderr,"error close %d socket", brower_sock);
		exit(1);
	}
    
    return 0;
}


int main(int argc , char *argv[])
{
	//get user input, initial port is 10000 (-v(debug mode)  -a(std error)  -p(port) 10000)
	int PORT = 8000;
	int c;

	while ((c = getopt (argc, argv, "p:av")) != -1)
	switch (c)
	  {
	  case 'a':{
		fprintf(stderr,"Full Name: Xinlong Zheng, SEAS login: xinlongz\n");
		exit(1);
	  }
		break;

	  case 'v':{
		vflag = 1;
	  }
		break;

	  case 'p':{

		  string s = optarg;
		  auto it = s.begin();
		  while (it != s.end() && std::isdigit(*it)) ++it;

		  if(!s.empty() && it == s.end() && atoi(optarg) >= 1){
			  PORT = atoi(optarg);
		  }
		  else{
			fprintf(stderr, "Option -n requires a positive integer argument.\n");
			exit(1);
		  }
	  }
		break;

	  case '?':
		if (optopt == 'p')
		  fprintf (stderr, "Option -%c requires an argument.\n", optopt);
		else if (isprint (optopt))
		  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
		else
		  fprintf (stderr,"Unknown option character `\\x%x'.\n", optopt);
		exit(1);
	  default:
		abort ();
	  }
     // construct sock connection
    if ( signal(SIGINT, sig_handler) == SIG_ERR ) {
        fprintf(stderr, "error capture signal ctrl+c (server)\n");
        exit(1);
    }

    int server_fd , new_sock , addrlen, opt =1;
    struct sockaddr_in server_addr, client_addr;

    if((server_fd = socket(AF_INET , SOCK_STREAM , 0)) == 0){
        fprintf(stderr, "error create socket (server)\n");
        exit(1);
    }

    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    {
        fprintf(stderr, "error setosocketopt (server)\n");
        exit(1);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons( PORT );

    if( bind(server_fd,(struct sockaddr *)&server_addr , sizeof(server_addr)) < 0)
    {
        fprintf(stderr, "error bind (server)\n");
        exit(1);
    }


    if (listen(server_fd, max_connection) < 0)
    {
        fprintf(stderr, "error listen (server)\n");
        exit(1);
    }

    addrlen = sizeof(struct sockaddr_in);

    //waiting for connection and create threads
    while(true)
    {
    	new_sock = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t*)&addrlen);
    	if(new_sock < 0){
            fprintf(stderr, "error accept (server)\n");
            exit(1);
    	}
     // handle sychronization issue
    	if(sig_flag == 1){
    		sock_write(new_sock,(char *)"-ERR Server shutting down\r\n");
    		if(close(new_sock) < 0){
    		    fprintf(stderr,"error close %d server", new_sock);
    			exit(1);
    		}
    	}
    	//create thread and make a record
    	if(sig_flag == 0){
        	cout << '['<< new_sock << ']' << " New connection" << endl;

        	pthread_t thread;
			if( pthread_create(&thread , NULL ,  thread_handler , (void*) &new_sock) < 0)
			{
				fprintf(stderr, "error create thread (server)\n");
				exit(1);
			}
			thread_set.insert(thread);
			sock_set.insert(new_sock);

    	}
    }

    return 0;
}
