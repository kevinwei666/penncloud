#ifndef BASICSERVER_H
#define BASICSERVER_H

#include "backLog.h"
#include<vector>
using namespace std;
class basicServer {
private:
	int PORT;
	vector<int> portvec;
	int maxClient;
	int *client_socket;

	map<int, string> client_socket_add;
	map<int, int> client_socket_port;
	map<int, int> client_port2socket;

public:
	void put(int port, int socket);
	void setServer(int num);
	void removeSocket(int socket);
	int getSocketbyid(int id) {
		return client_socket[id];
	}
	int getSocketbyport(int port) {
		return client_port2socket[port];
	}
	int getPortbysocket(int socket) {
		return client_socket_port[socket];
	}
	bool checkPort(int port);
};

#endif
