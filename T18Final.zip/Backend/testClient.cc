#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include<string>
#include<map>
#include<vector>
#include <unistd.h>
#include "KVcommunication.h"
#include "backLog.h"
#include "defaultport.h"
#include "basicServer.h"
#include "interface.h"
#include "MapFileFunctions.h"
#include "commandOperation.h"
#include "BackendMaster.h"
#define TRUE   1
#define FALSE  0
int PORT = 5001;
vector<int> portvec;
int debug = 0;
int second = 0;
int masterPort = 0;
int adminPort = 0;
using namespace std;
int mode = 0;
MapFile MF;
command kvCommand;
backendMaster bm;
InterFaceAPI IFA;
vector<int> lostConnection;
map<int, int> port2socket;

string send2port(string &message, int port) {
	int sockfd, connfd;
	struct sockaddr_in servaddr, cli;

	// socket create and varification
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) {
		printf("socket creation failed...\n");
		exit(0);
	} else
		printf("Socket successfully created..\n");
	bzero(&servaddr, sizeof(servaddr));

	// assign IP, PORT
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(port);

	// connect the client socket to server socket
	if (connect(sockfd, (struct sockaddr*) &servaddr, sizeof(servaddr)) != 0) {
		printf("connection with the server failed...\n");
		exit(0);
	} else
		printf("connected to the server..\n");

	if (send(sockfd, message.c_str(), strlen(message.c_str()), 0)
			!= strlen(message.c_str())) {
		perror("send");
	}

	char buffer[1024];
//	int port;
	int valread;
	string m = "";
	while ((valread = read(sockfd, buffer, 1024)) != 0) {
		buffer[valread] = '\0';
		m.append(buffer);
		break;
	}
	close(sockfd);
	return m;
}

string sendMsg(string &message, string &message2) {
	string output = send2port(message, 8014);
	int k = output.find(":");
	int port = atoi(output.substr(k + 1).c_str());
	string out2 = send2port(message2, port);
	return out2;
}

int main(int argc, char *argv[]) {
	int masterPort = 8014;
	string message = "username";
	string message2 = "register username password";
	string out2 = sendMsg(message, message2);

//	string message1 = "Charl";
//	message2 = "register Charl password";
//	out2 = sendMsg(message1, message2);
	printf("register: %s\n", out2.c_str());
	message2 = "login username password";
	out2 = sendMsg(message, message2);
	printf("login: %s\n", out2.c_str());
	message2 = "setCookie username cookie";
	out2 = sendMsg(message, message2);
	printf("setCookie: %s\n", out2.c_str());

	message2 = "checkCookie username cookie";
	out2 = sendMsg(message, message2);
	printf("checkCookie: %s\n", out2.c_str());

	message2 = "changePSW username password newPSW";
	out2 = sendMsg(message, message2);
	printf("changePSW: %s\n", out2.c_str());

	message2 = "deleteCookie username cookie";
	out2 = sendMsg(message, message2);
	printf("deleteCookie: %s\n", out2.c_str());

//	string name ="didi";
//	message2 = "driveOpen didi /";
//	out2 = sendMsg(name, message2);
//	printf("%s\n", out2.c_str());
//	exit(1);
	message2 = "driveOpen username /";
	out2 = sendMsg(message, message2);
	printf("driveOpen:/ %s\n", out2.c_str());

	message2 = "driveCreate username /";
	out2 = sendMsg(message, message2);
	printf("driveCreate1: %s\n", out2.c_str());

	message2 = "driveOpen username /";
	out2 = sendMsg(message, message2);
	printf("driveOpen:/ %s\n", out2.c_str());
//	exit(1);

	message2 = "driveCreate username folderAddr";
	out2 = sendMsg(message, message2);
	printf("driveCreate1: %s\n", out2.c_str());

//	message2 = "driveOpen username /";
//	out2 = sendMsg(message, message2);
//	printf("driveOpen:fileAddr3 %s\n", out2.c_str());

	message2 = "driveCreate username folderAddr1";
	out2 = sendMsg(message, message2);
	printf("driveCreate2: %s\n", out2.c_str());

	message2 = "driveCreate username folderAddr/fileAddr";
	out2 = sendMsg(message, message2);
	printf("subdriveCreate1: %s\n", out2.c_str());

	message2 = "driveCreate username folderAddr/fileAddr1";
	out2 = sendMsg(message, message2);
	printf("subdriveCreate2: %s\n", out2.c_str());
	message2 = "driveCreate username folderAddr/fileAddr10";
	out2 = sendMsg(message, message2);
	printf("subdriveCreate2: %s\n", out2.c_str());

	message2 = "driveDelete username folderAddr/fileAddr";
	out2 = sendMsg(message, message2);
	printf("driveDelete: %s\n", out2.c_str());
//exit(1);
	message2 = "driveRename username folderAddr/fileAddr1 folderAddr/fileAddr2";
	out2 = sendMsg(message, message2);
	printf("driveRename: %s\n", out2.c_str());

	message2 = "driveOpen username folderAddr";
	out2 = sendMsg(message, message2);
	printf("driveOpen:folderAddr %s\n", out2.c_str());


	message2 = "driveRename username folderAddr folderAddr4";
	out2 = sendMsg(message, message2);
	printf("driveRename: %s\n", out2.c_str());
//	exit(1);

	message2 = "driveOpen username folderAddr";
	out2 = sendMsg(message, message2);
	printf("driveOpen:folderAddr %s\n", out2.c_str());

	message2 = "driveOpen username folderAddr4";
	out2 = sendMsg(message, message2);
	printf("driveOpen:folderAdd4 %s\n", out2.c_str());
//	exit(1);
	message2 = "driveMove username folderAddr4/fileAddr2 folderAddr1/fileAddr2";
	out2 = sendMsg(message, message2);
	printf("driveMove: %s\n", out2.c_str());
//	exit(1);
	message2 = "driveUpload username folderAddr4/fileAddr3  3 fileContent";
	out2 = sendMsg(message, message2);
	printf("driveUpload: %s\n", out2.c_str());

	message2 = "driveOpen username folderAddr4";
	out2 = sendMsg(message, message2);
	printf("driveOpen:folderAddr4 %s\n", out2.c_str());

	message2 = "driveOpen username /";
	out2 = sendMsg(message, message2);
	printf("driveOpen:/ %s\n", out2.c_str());

	message2 = "driveDownload username folderAddr4/fileAddr3";
	out2 = sendMsg(message, message2);
	printf("driveDownload: %s\n", out2.c_str());

	message2 = "mailGetuser username";
	out2 = sendMsg(message, message2);
	printf("mailGetuser: %s\n", out2.c_str());

	message2 =
			"mailRev username\r\ntestsubject From <xinlongz@localhost> Tue Dec 15 12:37:42 2020\r\ncontent\r\n ";
	out2 = sendMsg(message, message2);
	printf("mailRev: %s\n", out2.c_str());

	message2 =
			"mailRev username\r\ntestsubject From <shaozhe@localhost> Tue Dec 15 12:37:42 2020\r\ncontent\r\n ";
	out2 = sendMsg(message, message2);
	printf("mailRev: %s\n", out2.c_str());

	message2 = "mailInbox username";
	out2 = sendMsg(message, message2);
	printf("mailInbox: %s\n", out2.c_str());

	message2 =
			"mailFetch username\r\ntestsubject From <xinlongz@localhost> Tue Dec 15 12:37:42 2020";
	out2 = sendMsg(message, message2);
	printf("mailFetch: %s\n", out2.c_str());

//	message2 =
//			"mailDelete username\r\ntestsubject From <xinlongz@localhost> Tue Dec 15 12:37:42 2020 ";
//	out2 = sendMsg(message, message2);
//	printf("mailDelete: %s\n", out2.c_str());
//
//	message2 = "mailInbox username";
//	out2 = sendMsg(message, message2);
//	printf("mailInbox: %s\n", out2.c_str());
}

