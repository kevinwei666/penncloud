#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <resolv.h>
#include <netdb.h>
#include <iostream>
#include <arpa/inet.h>

using namespace std;
#define N 4096

string Domain2IP(string domain_input)
{
    u_char nsbuf[4096];
    char dispbuf[4096];
    ns_msg msg;
    ns_rr rr;
    int i, l;
    string mail_addr;
    string res;
    char* domain_str = &domain_input[0];
    l = res_query(domain_str,  C_IN, T_MX, nsbuf, sizeof(nsbuf));
    if (l < 0)
    {
      cerr << "wrong fetch ip from domain" << endl;
    }
    else
    {
      /* just grab the MX answer info */
      ns_initparse(nsbuf, l, &msg);
      l = ns_msg_count(msg, ns_s_an);

        ns_parserr(&msg, ns_s_an, 1, &rr);
        ns_sprintrr(&msg, &rr, NULL, NULL, dispbuf, sizeof(dispbuf));
        string buf_str(dispbuf);
        string m = buf_str;
        int k = m.find(" ");
        string latter=m;
        string formmer;
        while(k!=std::string::npos){
         formmer = latter.substr(0,k);
         latter = latter.substr(k+1);
         k = latter.find(" ");
        }
        latter = latter.substr(0,latter.length());
        mail_addr = latter;
    }
    cout << mail_addr << endl;

	l = res_query(&mail_addr[0],  C_IN, T_A, nsbuf, sizeof(nsbuf));
	if (l < 0)
	{
		cerr << "wrong fetch ip from domain" << endl;
	}
	ns_initparse(nsbuf, l, &msg);
	l = ns_msg_count(msg, ns_s_an);

	ns_parserr(&msg, ns_s_an, 0, &rr);
	ns_sprintrr(&msg, &rr, NULL, NULL, dispbuf, sizeof(dispbuf));
	string buf_str(dispbuf);
	string m = buf_str;
	int k = m.find(" ");
	string latter=m;
	string formmer;
	while(k!=std::string::npos){
		formmer = latter.substr(0,k);
		latter = latter.substr(k+1);
		k = latter.find(" ");
	}
	latter = latter.substr(0,latter.length());
	res = latter;

    return res;
}


int main (int argc, char *argv[])
{
  string res = Domain2IP("seas.upenn.edu");
 cout << res << endl;
    return 0;
}
