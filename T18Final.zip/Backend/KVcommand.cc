#include "KVcommand.h"



void KVcommand::writeToFile(){
	return;
};

void KVcommand::readToMap(){
	return;
};


void KVcommand::putFunction(string row, string col, string value) {
	if (keyValueMap.find(row) == keyValueMap.end()) {
		map < string, string > newMap;
		newMap[col] = value;
		keyValueMap[row] = newMap;
	} else {
		keyValueMap[row][col] = value;
	}
}

string KVcommand::getFunction(string row, string col) {
	if (keyValueMap.find(row) == keyValueMap.end()) {
		fprintf(stderr, "Row %s doesn't exist\n", row.c_str());
		return NULL;
	} else {
		if (keyValueMap[row].find(col) == keyValueMap[row].end()) {
			fprintf(stderr, "Col %s doesn't exist",col.c_str());
			return NULL;
		}
		return keyValueMap[row][col];
	}
}

void KVcommand::cputFunction(string row, string col, string val1, string val2) {

		if (keyValueMap.find(row) == keyValueMap.end()) {
			fprintf(stderr, "Row %s doesn't exist\n", row.c_str());
			return;
		} else {
			if (keyValueMap[row].find(col) == keyValueMap[row].end()) {
				fprintf(stderr, "Col %s doesn't exist",col.c_str());
				return;
			}
			if (keyValueMap[row][col].compare(val1) != 0) {
				return;
			}
			keyValueMap[row][col] = val2;
			return;
		}
	}

void KVcommand::deleteFunction(string row, string col) {
	if (keyValueMap.find(row) == keyValueMap.end()) {
		fprintf(stderr, "Row %s doesn't exist\n", row.c_str());
		return;
	} else {
		if (keyValueMap[row].find(col) == keyValueMap[row].end()) {
			fprintf(stderr, "Col %s doesn't exist",col.c_str());
			return;
		}
		keyValueMap[row].erase(col);
	}
}
