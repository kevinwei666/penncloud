#ifndef DEFAULTPORT_H
#define DEFAULTPORT_H
#include<map>
#include<vector>
using namespace std;
void portassign(int port, vector<int> &portvec);
#endif
