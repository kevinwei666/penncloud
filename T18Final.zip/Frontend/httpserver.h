#ifndef _HTTPSERVER_H
#define _HTTPSERVER_H
#include "config.h"

class HttpServer{
private:
	int sock;
	bool islogin;
	string cookie;
	string username;
	string request;
	string respond;
	string header_status;
	string header_type;
	string header_length;
	string content;
	string sid;
	string mailSubject; // needed
	vector<string> mailRCPTS;  //needed
	string mailContent;   //needed
	string mailSender;  // not necessary
	string driveAddr;
	string cur_cookie;

	int HandleGet();
	int HandleCookie();
	int HandlePost();
	int HandleDownload();
	int renderFile(string file,string file_type);
	int renderHome();
	int renderLogin();
	int renderRegister();
	int renderDrive();
	int renderMail();
	int renderLogout();
	int renderInbox();

	int postRegister();
	int postLogin();
	int postPSWchange();
	int postdriveOpen();
	int postdriveCreate();
	int postdriveDelete();
	int postdriveRename();
	int postdriveMove();
	int postdriveUpload();
	int postmailNewmsg();
	int postmailReply();
	int postmailForward();
	int postmailDelete();

	string urlDecode(string &SRC);
	string generateRandomStr(const int len);
	int sendMail();
	unordered_map<string,string> domain_to_ip;
	unordered_map<string,int> domain_to_port;

public:
	HttpServer(int sock);
	~HttpServer();
	int HandleRequest(char* read_buffer);
};


#endif
