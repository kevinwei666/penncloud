/*
 * MapFileFunctions.h
 *
 *  Created on: Dec 6, 2020
 *      Author: cis505
 */
#include <stdlib.h>
#include <string>
#include <stdio.h>
#include <sys/file.h>
#include <unordered_map>
#include <vector>
using namespace std;
#ifndef MAPFILEFUNCTIONS_H_
#define MAPFILEFUNCTIONS_H_
class MapFile{


	public: unordered_map<string, unordered_map<string, string>> FileToMap(string fileName);


	public: void MapToFILE(unordered_map<string, unordered_map<string, string>> hMap, string filenName);
};

#endif /* MAPFILEFUNCTIONS_H_ */
