#include "backLog.h"
#include <string>
#include <stdio.h>
#include <map>
#include <vector>
#include <fstream>
#include <iostream>
//#define READ 0;
//#define WRITE 1;
using namespace std;
void backLog::setLog(string path, int port) {
	string end_path = ".log";

	f_path = path + std::to_string(port) + end_path;

	checkRestart();
	if (mode == 0) {
		closeFile();
		checkRestart();
	}
}
int backLog::showmode() {
	return mode;
}
vector<string> backLog::readFile() {
	vector<string> res;
	if ((fp = fopen(f_path.c_str(), "r")) == NULL) {
		return res;
	}
	char line[1024];

	while (fgets(line, 1024, fp)) {
		cout << "enter here here here!!!!!!!!!!!!!!!" << endl;
		printf("%s\n", line);
		res.push_back(line);
	}
	return res;

}

void backLog::writeFile(int port, string &command) {
	fp = fopen(f_path.c_str(), "a");
	fprintf(fp, "%s\n", command.c_str());
	fflush(fp);
}

void backLog::closeFile() {
	fp = fopen(f_path.c_str(), "w");
	fprintf(fp, "%s", "");
	fflush(fp);
}

void backLog::checkRestart() {
	if ((fp = fopen(f_path.c_str(), "r")) != NULL) {
		mode = 0;
	} else {
		mode = 1;
		fp = fopen(f_path.c_str(), "w");
	}
}
