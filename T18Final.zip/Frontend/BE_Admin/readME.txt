./multSocket -m Master -p 8014

./multSocket -m Admin -p 8020

./multSocket -m Primary -p 5001

./multSocket -m Primary -p 6001

./multSocket -m Primary -p 7001

./multSocket -m Secondary -p 5002

./multSocket -m Secondary -p 6002

./multSocket -m Secondary -p 7002

./multSocket -m Secondary -p 5003

./multSocket -m Secondary -p 6003

./multSocket -m Secondary -p 7003

./backednMasterFile


