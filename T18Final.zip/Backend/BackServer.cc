#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <ctype.h>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include "KVcommunication.h"
#include "backLog.h"
#include "defaultport.h"
#include "basicServer.h"
#include "interface.h"
#include "MapFileFunctions.h"
#include "commandOperation.h"
#include "BackendMaster.h"
#define TRUE   1
#define FALSE  0
int PORT;
vector<int> portvec;
int debug = 0;
int second = 0;
int masterPort = 0;
int adminPort = 0;
using namespace std;
int mode = 1;
//MapFile MF;
command kvCommand;
InterFaceAPI IFA;
vector<int> lostConnection;
map<int, int> port2socket;
void reconnectPort(basicServer &socketInfo, int port, int outport) {
	if (!socketInfo.checkPort(outport)) {
		int reconnect_socket = reconnectServer(port, outport);
		if (reconnect_socket < 0) {
			printf("Port %d was closed\n", outport);
		} else {
			printf("Connect to %d\n", outport);
			socketInfo.put(outport, reconnect_socket);
		}
	}
}

void send2port(int port, string &buffer, basicServer &socketInfo) {
	if (send(socketInfo.getSocketbyport(port), buffer.c_str(),
			strlen(buffer.c_str()), 0) != strlen(buffer.c_str())) {
		perror("send");
	}
}

void reply(int socket, string &buffer) {
	if (send(socket, buffer.c_str(), strlen(buffer.c_str()), 0)
			!= strlen(buffer.c_str())) {
		perror("send");
	}
}
void shutAllserver(basicServer &socketInfo, int max_clients,
		int master_socket) {
	for (int i = 0; i < max_clients; i++) {
		int sock = socketInfo.getSocketbyid(i);
		if (sock > 0 && sock != master_socket) {
			shutServer(sock);
			socketInfo.removeSocket(sock);
		}
	}
}

void MapToFILE(unordered_map<string, unordered_map<string, string>> hMap,
		string fileName) {
	//cout << "enter this function map to file" << endl;
	if (hMap.size() == 0) {
		cout << " map size is zero" << endl;
		return;
	}
	FILE *fp;
	fp = fopen(fileName.c_str(), "w");
	for (auto it : hMap) {
		string userName = it.first;
		for (auto inner : hMap[userName]) {
			if (inner.first.length() == 0) {
				continue;
			}
			string message = userName + " " + inner.first + " " + inner.second
					+ "\r\n";
			printf("message:%s\n",message.c_str());
			fprintf(fp, "%s", message.c_str());
			fflush(fp);
		}
	}
	fclose(fp);
}

unordered_map<string, unordered_map<string, string>> FileToMap(
		string fileName) {
	unordered_map<string, unordered_map<string, string>> result;
	if (fileName.length() == 0) {
		return result;
	}
	printf("start\n");
	FILE *fp;
	if((fp = fopen(fileName.c_str(), "r")) == NULL){
		return result;
	}
	char line[1024];
	string latter = "";
	while (fgets(line, 1024, fp)) {
		printf("%s\n",line);
		if (strcmp(line, "") == 0) {
			break;
		}
		latter.append(line);
		int k1 = latter.find("\r\n");
		while (k1 != std::string::npos) {
			string allMsg = latter.substr(0, k1);
			printf("message:%s\n",allMsg.c_str());
			latter = latter.substr(k1 + 2);
			int k2 = allMsg.find(" ");
			string username = allMsg.substr(0, k2);
			allMsg = allMsg.substr(k2 + 1);
			k2 = allMsg.find(" ");
			string column = allMsg.substr(0, k2);
			string value = allMsg.substr(k2 + 1);
			result[username][column] = value;
			k1 = latter.find("\r\n");
		}
	}
	fclose(fp);
	return result;
}
void backInit(vector<int> &portvec, basicServer &socketInfo,
		int master_socket) {
	int friend_socket = reconnectServer(PORT, portvec.at(0));
	if (friend_socket < 0) {
	} else {
		socketInfo.put(portvec.at(0), friend_socket);
	}

	friend_socket = reconnectServer(PORT, portvec.at(1));
	if (friend_socket < 0) {
	} else {
		socketInfo.put(portvec.at(1), friend_socket);
	}

	string ask = "primary";
	reply(master_socket, ask);
	int reallen;
	char buf[1024];
	int pri_port;
	string m;
	while ((reallen = read(master_socket, buf, 1024)) != 0) {
		buf[reallen] = '\0';
		m.append(buf);
		break;
	}
	pri_port = atoi(buf);
	if (pri_port == PORT) {
		mode = 0;
	} else {
		mode = 1;
	}
	fprintf(stderr,"mode:%d port:%s\n", mode, m.c_str());
	fprintf(stderr,"start to read buf\n");

	if (mode == 1) {

		ask = "Replication";
		send2port(pri_port, ask, socketInfo);
		string fileName = "DataFile - " + to_string(PORT);
		FILE *fp;
		fp = fopen(fileName.c_str(), "w");
		fprintf(stderr,"start to read buf\n");
		while ((reallen = read(socketInfo.getSocketbyport(pri_port), buf,
				1024)) != 0) {
			fprintf(stderr,"%s",buf);
			buf[reallen] = '\0';
			if (strstr(buf, "Nothing") != NULL) {
				break;
			}
			string receivedData;
			receivedData.append(buf);
			if (strstr(receivedData.c_str(), "end write") != NULL) {
				int k = receivedData.find("end write");
				if (k > 0) {
					fprintf(fp, "%s", receivedData.substr(0, k).c_str());
					fflush(fp);
				}
				IFA.serverDataMap = FileToMap(fileName);
				return;
			} else {
				fprintf(fp, "%s", receivedData.c_str());
				fflush(fp);
			}
		}
		fclose(fp);
		printf("Replication finish\n");
	}
	if (mode == 0) {
		string fileName = "DataFile - " + to_string(PORT);
		IFA.serverDataMap = FileToMap(fileName);
	}
	printf("Initial finish\n");
}
int main(int argc, char *argv[]) {
	int sopt = TRUE;
	int master_socket, addrlen, client_socket[30], max_clients = 30, activity,
			i, valread, sd;
	map<int, string> client_socket_add;
	map<int, int> client_socket_port;
	map<int, int> client_port2socket;
	int max_sd;

	char buffer[102400];
	int PORTbuffer[3];

	int opt;
	string path = "";
	string modeString = "";
	int masterPort = 8014;
	int adminPort = 8020;
	int checkPort = 8001;
	int listen_socket, admin_socket, primary_socket, second_socket1,
			second_socket2, check_socket;
	//construct the keyword of this server
//	MF.constructKeyWord();
	while ((opt = getopt(argc, argv, "p:avm:")) != -1) {
		switch (opt) {
		case 'p':
			PORT = atoi(optarg);
			portassign(PORT, portvec);
			break;
		case 'a':
			fprintf(stderr, "Name: Shaozhe Lyu, Login: shaozhe\n");
			exit(1);
			break;
		case 'v':
			debug = 1;
			break;
		case 'm':
			modeString.append(optarg);
			if (strcmp(modeString.c_str(), "Primary") == 0) {
				mode = 0;
			} else if (strcmp(modeString.c_str(), "Secondary") == 0) {
				mode = 1;
			} else if (strcmp(modeString.c_str(), "Master") == 0) {
				mode = 2;
			} else if (strcmp(modeString.c_str(), "Admin") == 0) {
				mode = 3;
			}
			break;
		case '?':
			break;
		}
	}
	backLog log;
	log.setLog(path, PORT);
//	string fname = "DataFile - " + to_string(PORT);
//	IFA.serverDataMap = MF.FileToMap(fname);
	InterFaceAPI IFA_log_begin;
	vector < string > logVector;
	logVector = log.readFile();
	int receiveData = 0;
	for (int i = 0; i < logVector.size(); i++) {
		IFA_log_begin.checkCommand(logVector[i]);
	}
	if (IFA_log_begin.serverDataMap.size() != 0) {
		for (auto it : IFA_log_begin.serverDataMap) {
			string outKey = it.first;
			unordered_map < string, string > innerMap =
					IFA_log_begin.serverDataMap[outKey];
			for (auto iit : innerMap) {
				string innerKey = iit.first;
				IFA.serverDataMap[outKey][innerKey] =
						IFA_log_begin.serverDataMap[outKey][innerKey];
			}
		}
	}
//	printf("%s\n", log.showmode() ? "WRITE" : "READ");

	basicServer socketInfo;
	socketInfo.setServer(max_clients);

	for (i = 0; i < max_clients; i++) {
		client_socket[i] = 0;
	}
	admin_socket = 0;
	master_socket = 0;
	int shutdown = 0;
	int start2write = 0;
	listen_socket = listenServer(PORT, 10);
	master_socket = reconnectServer(PORT, masterPort);
	if (master_socket < 0) {
		printf("Master port should be open first\n");
		exit(1);
	}
	socketInfo.put(masterPort, master_socket);
	admin_socket = reconnectServer(PORT, adminPort);
	if (admin_socket < 0) {
		printf("Admin port should be open first\n");
		exit(1);
	}
	socketInfo.put(adminPort, admin_socket);

	backInit(portvec, socketInfo, master_socket);

	fd_set readfds;
	int lost = 0;
	int only_once = 0;
	while (TRUE) {

		FD_ZERO(&readfds);
		FD_SET(listen_socket, &readfds);
		max_sd = listen_socket;
		for (i = 0; i < max_clients; i++) {
			sd = socketInfo.getSocketbyid(i);
			if (sd > 0) {
				FD_SET(sd, &readfds);
			}
			if (sd > max_sd) {
				max_sd = sd;
			}
		}
		activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
		if ((activity < 0) && (errno != EINTR)) {
			printf("select error %d %d\n", activity, errno);
		}
		int newportAcc;
		if (FD_ISSET(listen_socket, &readfds)) {
			newportAcc = acceptNewclient(listen_socket, socketInfo);
		}

		for (i = 0; i < max_clients; i++) {
			sd = socketInfo.getSocketbyid(i);
			if (FD_ISSET(sd, &readfds)) {
				int globalPort = socketInfo.getPortbysocket(sd);
				if (shutdown == 1 && sd != admin_socket) {
					continue;
				}
				struct sockaddr_in clientaddr;
				socklen_t cliendaddrlen = sizeof(clientaddr);
				if ((valread = read(sd, buffer, 102400)) == 0) {
					getpeername(sd, (struct sockaddr*) &clientaddr,
							(socklen_t*) &cliendaddrlen);
					int sock = sd;
					checkClient(sock, ntohs(clientaddr.sin_port),
							inet_ntoa(clientaddr.sin_addr), 1);
					string removedport = to_string(
							socketInfo.getPortbysocket(sd));
					close(sd);
					socketInfo.removeSocket(sd);
				} else {
					buffer[valread] = '\0';
					string m = "";
					m.append(buffer);
					printf("[%d]:%s\n", globalPort, m.c_str());
					if (globalPort == 8014) {
						if (strcmp(m.c_str(), "primary") == 0) {
							mode = 0;
						}
					} else if (globalPort == 8020) {
						if (strcmp(m.c_str(), "shutdown") == 0
								&& shutdown == 0) {
							shutAllserver(socketInfo, max_clients,
									admin_socket);
							shutdown = 1;
//							for (auto it : IFA.serverDataMap) {
//								IFA.serverDataMap.erase(it.first);
//							}
							string succ = "+200 OK";
							reply(sd, succ);
							printf("shutdown success\n");

						} else if (strstr(m.c_str(), "restart") != NULL
								&& shutdown == 1) {
							reconnectPort(socketInfo, PORT, 8014);
							shutdown = 0;
							master_socket = socketInfo.getSocketbyport(8014);
							backInit(portvec, socketInfo, master_socket);
							string succ = "+200 OK";
							reply(sd, succ);
							printf("restart success\n");
						} else if (strstr(m.c_str(), "getValue") != NULL) {
							//get the number
							int spaceCount = 0;
							int k = m.find(" ");
							if (m.size() < 10) {
								string err = "-400 ERR";
								reply(sd, err);
							}
							int num;
							if (k == std::string::npos) {
								string err = "-400 ERR";
								reply(sd, err);
							} else {
								num = stoi(m.substr(k));
							}
							vector < string > succVector;
							int start = 10 * num - 10;
							int end = start + 9;
							if (IFA.serverDataMap.size() == 0
									|| start >= IFA.serverDataMap.size()) {
								string err = "-400 ERR";
								reply(sd, err);
							} else {
								string suc = "+200 OK ";
								for (auto it : IFA.serverDataMap) {
									string username = it.first;
									string innerKey;
									string value;
									for (auto itt : IFA.serverDataMap[username]) {
										innerKey = itt.first;
										value = itt.second;
										string oneUserInfo = "username = "
												+ username + "," + "InnerKey = "
												+ innerKey + "," + "value = "
												+ value + "&";
										succVector.push_back(oneUserInfo);
									}

								}
								//get result
								for (int i = start; i < succVector.size();
										i++) {
									if (i > end) {
										break;
									}
									suc += succVector[i];
								}
								reply(sd, suc);
							}
						} else {
							string sucMsg = "+200 OK";
							reply(sd, sucMsg);
						}
						printf("reply 8020 success\n");
					} else {
						if (mode == 0) {
							if (globalPort == portvec.at(1)
									|| globalPort == portvec.at(0)) {
								if (strstr(m.c_str(), "Replication") != NULL) {
									if (IFA.serverDataMap.size() == 0) {
										receiveData = 0;
										string replyReplication = "Nothing";
										reply(sd, replyReplication);
										printf("Nothing to reply\n");
										continue;
									}
									string fileName = "DataFile - "
											+ to_string(PORT);
									MapToFILE(IFA.serverDataMap, fileName);

									if (socketInfo.checkPort(portvec.at(0))) {
//										printf("write to %d\n", portvec.at(0));
										char buf[1024];
										FILE *fp;
										fp = fopen(fileName.c_str(), "r");
										while (fgets(buf, 1024, fp)) {
											string outk;
											outk.append(buf);
											reply(sd, outk);
										}
										string endstr = "end write";
										reply(sd, endstr);
									}
									printf("Replication success\n");
								}

							} else {
								string res = IFA.checkCommand(m);
								if (strcmp(res.c_str(), "") == 0) {
									continue;
								}

								string fileName = "DataFile - "
										+ to_string(PORT);
								MapToFILE(IFA.serverDataMap, fileName);

								if (socketInfo.checkPort(portvec.at(0))) {
									send2port(portvec.at(0), m, socketInfo);

								}
								if (socketInfo.checkPort(portvec.at(1))) {
									send2port(portvec.at(1), m, socketInfo);
								}
								reply(sd, res);
							}
						} else {
							string res = IFA.checkCommand(m);
							if (strcmp(res.c_str(), "") == 0) {
								continue;
							}
							string fileName = "DataFile - " + to_string(PORT);
							MapToFILE(IFA.serverDataMap, fileName);
						}

					}

				}
			}
		}
	}
	return 0;
}
