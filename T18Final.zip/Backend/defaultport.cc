#include<map>
#include<vector>
using namespace std;
#include "defaultport.h"

void portassign(int port, vector<int> &portvec) {
	if (port == 5001) {
		portvec.push_back(5002);
		portvec.push_back(5003);
	} else if (port == 5002) {
		portvec.push_back(5001);
		portvec.push_back(5003);
	}else if (port ==5003) {
		portvec.push_back(5001);
		portvec.push_back(5002);
	}else if (port == 6001) {
		portvec.push_back(6002);
		portvec.push_back(6003);
	}else if (port == 6002) {
		portvec.push_back(6001);
		portvec.push_back(6003);
	}else if (port == 6003) {
		portvec.push_back(6001);
		portvec.push_back(6002);
	}else if (port == 7001) {
		portvec.push_back(7002);
		portvec.push_back(7003);
	}else if (port == 7002) {
		portvec.push_back(7001);
		portvec.push_back(7003);
	}else if (port == 7003) {
		portvec.push_back(7001);
		portvec.push_back(7002);
	}
}
