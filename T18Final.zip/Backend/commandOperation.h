/*
 * commandOperation.h
 *
 *  Created on: Dec 12, 2020
 *      Author: cis505
 */

#include <stdlib.h>
#include <string>
#include <stdio.h>
#include <sys/file.h>
#include <unordered_map>
#include <vector>
#ifndef COMMANDOPERATION_H_
#define COMMANDOPERATION_H_
using namespace std;

class command{
	public: unordered_map<string, unordered_map<string, string>> serverMap;

	public: void putFunction(string row, string col, string val);

	public: string getFunction(string row, string col);

	public: void cputFunction(string row, string col, string oldValue, string newValue);

	public: void deleteFunction(string row, string col);

};
#endif /* COMMANDOPERATION_H_ */
