#include <stdlib.h>
#include <stdio.h>
#include <openssl/md5.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include<sys/wait.h>
#include<iostream>
#include<vector>
#include<string>
#include<limits.h>
#include <sys/mman.h>
#include <pthread.h>
#include<fstream>
#include<arpa/inet.h>
#include <signal.h>
#include <ctime>
#include <time.h>
#include<dirent.h>
using namespace std;

void computeDigest(char *data, int dataLengthBytes,
		unsigned char *digestBuffer) {
	MD5_CTX c;
	MD5_Init(&c);
	MD5_Update(&c, data, dataLengthBytes);
	MD5_Final(digestBuffer, &c);
}

string hash_compute(string &text) {
	time_t now;
	time(&now);
	text.append(ctime(&now));
	int size = text.size();
	unsigned char digestBuffer[MD5_DIGEST_LENGTH];
	char input[size + 1];
	strcpy(input, text.c_str());
	computeDigest(input, text.size() + 1, digestBuffer);
	string result;
	char buf[32];
	for (int i = 0; i < 5; i++) {
		sprintf(buf, "%02x", digestBuffer[i]);
		result.append(buf);
	}
	return result;
}

int main() {
	string f_path = "hello";
	FILE *fp;
	fp = fopen(f_path.c_str(), "r");
	char num[2000];
	fscanf(fp, "%s", num);
	cout << num << endl;
	string text = "m";
//	time_t now;
//	time(&now);
//	printf("Today is : %s", ctime(&now));
//	text.append(ctime(&now));
	string hash = hash_compute(text);
	printf("%s\n", hash.c_str());
//		remove(path.c_str());
}

