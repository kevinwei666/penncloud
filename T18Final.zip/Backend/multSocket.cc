#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <ctype.h>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include "KVcommunication.h"
#include "backLog.h"
#include "defaultport.h"
#include "basicServer.h"
#include "interface.h"
#include "MapFileFunctions.h"
#include "commandOperation.h"
#include "BackendMaster.h"
#define TRUE   1
#define FALSE  0
int PORT;
vector<int> portvec;
int debug = 0;
int second = 0;
int masterPort = 0;
int adminPort = 0;
using namespace std;
int mode = 0;
MapFile MF;
command kvCommand;
backendMaster bm;
InterFaceAPI IFA;
vector<int> lostConnection;
map<int, int> port2socket;
void reconnectPort(basicServer &socketInfo, int port, int outport) {
	if (!socketInfo.checkPort(outport)) {
		int reconnect_socket = reconnectServer(port, outport);
		if (reconnect_socket < 0) {
			printf("Port %d should be open first\n", outport);
			//									exit(1);
		} else {
			printf("Connect to %d\n", outport);
			socketInfo.put(outport, reconnect_socket);
		}
	}
}

void send2port(int port, string &buffer, basicServer &socketInfo) {
	if (send(socketInfo.getSocketbyport(port), buffer.c_str(),
			strlen(buffer.c_str()), 0) != strlen(buffer.c_str())) {
		perror("send");
	}
}
void reply(int socket, string &buffer) {
	if (send(socket, buffer.c_str(), strlen(buffer.c_str()), 0)
			!= strlen(buffer.c_str())) {
		perror("send");
	}
}
void shutAllserver(basicServer &socketInfo, int max_clients,
		int master_socket) {
	for (int i = 0; i < max_clients; i++) {
		int sock = socketInfo.getSocketbyid(i);
		if (sock > 0 && sock != master_socket) {
			shutServer(sock);
			socketInfo.removeSocket(sock);
		}
	}
}
int main(int argc, char *argv[]) {
	int sopt = TRUE;
	int master_socket, addrlen, client_socket[30], max_clients = 30, activity,
			i, valread, sd;
	map<int, string> client_socket_add;
	map<int, int> client_socket_port;
	map<int, int> client_port2socket;
	int max_sd;

	char buffer[102400];
//	char *buf = (char*) malloc(sizeof(char) * 100000);
//	if (buf == NULL)
//		perror("Malloc Failed");
//	memset(buf, '\0', sizeof(char) * 100000);
	int PORTbuffer[3];

	int opt;
	string path = "";
	string modeString = "";
	int masterPort = 8014;
	int adminPort = 8020;
	int checkPort = 8001;
	int listen_socket, admin_socket, primary_socket, second_socket1,
			second_socket2, check_socket;
	//construct the keyword of this server
	MF.constructKeyWord();
	while ((opt = getopt(argc, argv, "p:avm:")) != -1) {
		switch (opt) {
		case 'p':
			PORT = atoi(optarg);
			portassign(PORT, portvec);
			break;
		case 'a':
			fprintf(stderr, "Name: Shaozhe Lyu, Login: shaozhe\n");
			exit(1);
			break;
		case 'v':
			debug = 1;
			break;
		case 'm':
			modeString.append(optarg);
			if (strcmp(modeString.c_str(), "Primary") == 0) {
				mode = 0;
			} else if (strcmp(modeString.c_str(), "Secondary") == 0) {
				mode = 1;
			} else if (strcmp(modeString.c_str(), "Master") == 0) {
				mode = 2;
			} else if (strcmp(modeString.c_str(), "Admin") == 0) {
				mode = 3;
			}
			break;
		case '?':
			break;
		}
	}
	backLog log;
	log.setLog(path, PORT);
	string fname = "DataFile - " + to_string(PORT);
	IFA.serverDataMap = MF.FileToMap(fname);
	//cout << "the size of the server map is " << IFA.serverDataMap.size() << endl;
	//log ----> map
	InterFaceAPI IFA_log_begin;
	vector < string > logVector;
	logVector = log.readFile();
	int receiveData = 0;
	for (int i = 0; i < logVector.size(); i++) {
		IFA_log_begin.checkCommand(logVector[i]);
	}
	if (IFA_log_begin.serverDataMap.size() != 0) {
		for (auto it : IFA_log_begin.serverDataMap) {
			string outKey = it.first;
			unordered_map < string, string > innerMap =
					IFA_log_begin.serverDataMap[outKey];
			for (auto iit : innerMap) {
				string innerKey = iit.first;
//				if(IFA.serverDataMap.count(outKey) != 0 && IFA.serverDataMap[outKey].count(innerKey) != 0){
//						IFA.serverDataMap[outKey][innerKey] = IFA_log_begin.serverDataMap[outKey][innerKey];
//				}
//				if(IFA.serverDataMap.count(outKey) == 0){
//
//				}
				IFA.serverDataMap[outKey][innerKey] =
						IFA_log_begin.serverDataMap[outKey][innerKey];
			}
		}
	}
//	cout << "test data ::::::::::::::::" << IFA.serverDataMap["Alice"]["cookie"]
//			<< endl;

	printf("%s\n", log.showmode() ? "WRITE" : "READ");

	basicServer socketInfo;
	socketInfo.setServer(max_clients);

	for (i = 0; i < max_clients; i++) {
		client_socket[i] = 0;
	}
	admin_socket = 0;
	master_socket = 0;
	int shutdown = 0;
	int start2write = 0;
	if (mode == 0) {
		listen_socket = listenServer(PORT, 10);
		master_socket = reconnectServer(PORT, masterPort);
		if (master_socket < 0) {
			printf("Master port should be open first\n");
			exit(1);
		}
		socketInfo.put(masterPort, master_socket);
		admin_socket = reconnectServer(PORT, adminPort);

		if (admin_socket < 0) {
			printf("Admin port should be open first\n");
			exit(1);
		}
		socketInfo.put(adminPort, admin_socket);
	} else if (mode == 1) {
//		listen_socket = listenServer(PORT, 10);
		listen_socket = 0;
		primary_socket = reconnectServer(PORT, portvec.at(0));
		if (primary_socket < 0) {
			printf("Primary port should be open first\n");
			exit(1);
		}
		socketInfo.put(portvec.at(0), primary_socket);

		master_socket = reconnectServer(PORT, masterPort);
		if (master_socket < 0) {
			printf("Master port should be open first\n");
			exit(1);
		}

		socketInfo.put(masterPort, master_socket);
		admin_socket = reconnectServer(PORT, adminPort);
		if (admin_socket < 0) {
			printf("Admin port should be open first\n");
			exit(1);
		}
		socketInfo.put(adminPort, admin_socket);
//		shutdown = 1;
	} else if (mode == 2) {
		listen_socket = listenServer(PORT, 10);
//		listen_socket = 0;
		cout << "this is a master server" << endl;
		bm.serverMap = bm.constructServerMap("addressFile");
		bm.primaryMap = bm.constructPrimaryMap("GroupA", "127.0.0.1:5001",
				bm.primaryMap);
		bm.primaryMap = bm.constructPrimaryMap("GroupB", "127.0.0.1:6001",
				bm.primaryMap);
		bm.primaryMap = bm.constructPrimaryMap("GroupC", "127.0.0.1:7001",
				bm.primaryMap);
		bm.constructServerAddressTogroup();
		bm.constructGroupToServers();
	} else {
		listen_socket = listenServer(PORT, 10);
		master_socket = reconnectServer(PORT, masterPort);
		if (master_socket < 0) {
			printf("Master port should be open first\n");
			exit(1);
		}
		socketInfo.put(masterPort, master_socket);
	}

	fd_set readfds;
	int lost = 0;
	int only_once = 0;

	while (TRUE) {

		FD_ZERO(&readfds);
		FD_SET(listen_socket, &readfds);
		max_sd = listen_socket;
		//add child sockets to set
		for (i = 0; i < max_clients; i++) {
			sd = socketInfo.getSocketbyid(i);
			if (sd > 0) {
				FD_SET(sd, &readfds);
			}
			if (sd > max_sd) {
				max_sd = sd;
			}
		}
		activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
		if ((activity < 0) && (errno != EINTR)) {
			printf("select error %d %d\n", activity, errno);
		}
		//accept new connection from new port
		int newportAcc;
		if (shutdown == 0) {
			if (FD_ISSET(listen_socket, &readfds)) {
				newportAcc = acceptNewclient(listen_socket, socketInfo);
			}
//			if (mode == 2) {
//				if (newportAcc == 5001) {
//					//set 5001 as primary
//					string sAddress = "127.0.0.1:" + to_string(5001);
//					bm.primaryMap = bm.constructPrimaryMap("GroupA",
//							"127.0.0.1:5001", bm.primaryMap);
//					string primaryStr = "primary";
////					cout << "11111111111111111111111" << endl;
//					send2port(5001, primaryStr, socketInfo);
//					//tell 5002 5003, this is primary 5001
//					string primaryMessage = "primaryport " + to_string(5001);
//					if (socketInfo.checkPort(5002) == true) {
//						send2port(5002, primaryMessage, socketInfo);
//					}
//					if (socketInfo.checkPort(5003) == true) {
//						send2port(5003, primaryMessage, socketInfo);
//					}
//				}
//				if (newportAcc == 6001) {
//					string sAddress = "127.0.0.1:" + to_string(6001);
//					bm.primaryMap = bm.constructPrimaryMap("GroupB",
//							"127.0.0.1:6001", bm.primaryMap);
//					//tell 5002 5003, this is primary 5001
//					string primaryStr = "primary";
//					send2port(6001, primaryStr, socketInfo);
//					string primaryMessage = "primaryport " + to_string(6001);
//					if (socketInfo.checkPort(6002) == true) {
//						send2port(6002, primaryMessage, socketInfo);
////						string reconMessage = "reconnect" + to_string(6001);
////						send2port(6002, reconMessage, socketInfo);
//					}
//					if (socketInfo.checkPort(6003) == true) {
//						send2port(6003, primaryMessage, socketInfo);
////						string reconMessage = "reconnect" + to_string(6001);
////						send2port(6003, reconMessage, socketInfo);
//					}
//				}
//				if (newportAcc == 7001) {
//					//set 5001 as primary
//					string sAddress = "127.0.0.1:" + to_string(7001);
//					bm.primaryMap = bm.constructPrimaryMap("GroupC",
//							"127.0.0.1:7001", bm.primaryMap);
//					//tell 5002 5003, this is primary 5001
//					string primaryStr = "primary";
//					send2port(7001, primaryStr, socketInfo);
//					string primaryMessage = "primaryport " + to_string(7001);
//					if (socketInfo.checkPort(7002) == true) {
//						send2port(5002, primaryMessage, socketInfo);
//					}
//					if (socketInfo.checkPort(7003) == true) {
//						send2port(7003, primaryMessage, socketInfo);
//					}
//				}
//			}
		}
		for (i = 0; i < max_clients; i++) {
			sd = socketInfo.getSocketbyid(i);
			if (FD_ISSET(sd, &readfds)) {
				int globalPort = socketInfo.getPortbysocket(sd);
				if (shutdown == 1 && sd != admin_socket) {
					continue;
				}
				struct sockaddr_in clientaddr;
				socklen_t cliendaddrlen = sizeof(clientaddr);
				if ((valread = read(sd, buffer, 102400)) == 0) {
					getpeername(sd, (struct sockaddr*) &clientaddr,
							(socklen_t*) &cliendaddrlen);
					int sock = sd;
					checkClient(sock, ntohs(clientaddr.sin_port),
							inet_ntoa(clientaddr.sin_addr), 1);
					printf("port is :%d, data port:%d\n",
							ntohs(clientaddr.sin_port),
							socketInfo.getPortbysocket(sd));
					string removedport = to_string(
							socketInfo.getPortbysocket(sd));
					close(sd);
					socketInfo.removeSocket(sd);
					//get the crash of the primary server and assign new one
					if (mode == 2) {
//						if()
						string port = removedport;
						string crashesAddress;
						crashesAddress.append(inet_ntoa(clientaddr.sin_addr));
						crashesAddress = crashesAddress + ":" + port;
						string groupName =
								bm.serverAddressTogroup[crashesAddress];
						vector < string > serverAddresses =
								bm.groupToservers[groupName];
						bool newPrimary = false;
						for (int i = 0; i < serverAddresses.size(); i++) {
							if (serverAddresses[i].compare(crashesAddress)
									== 0) {
								continue;
							}
							string newip = bm.getIpAdress(serverAddresses[i]);
							string newport = bm.getPort(serverAddresses[i]);
							int portNum = stoi(newport);
							bool ifhasport = socketInfo.checkPort(portNum);
							if (ifhasport == true) {
								//set the new primary
								newPrimary = true;
								string primary = "primary";
								cout << "send the message primary to port "
										<< portNum << endl;
								send2port(portNum, primary, socketInfo);
								string addressOfserver = newip + ":" + newport;
								bm.primaryMap = bm.constructPrimaryMap(
										groupName, addressOfserver,
										bm.primaryMap);
								for (int i = 0; i < serverAddresses.size();
										i++) {
									if (serverAddresses[i].compare(
											crashesAddress) == 0
											|| serverAddresses[i].compare(
													addressOfserver) == 0) {
										continue;
									}
									string otherport = bm.getPort(
											serverAddresses[i]);
									int otherportNum = stoi(otherport);
									//tell other server the update
									string primaryMessage = "primaryport "
											+ newport;
									send2port(otherportNum, primaryMessage,
											socketInfo);
								}
								break;
							}
						}
						if (newPrimary == false) {
							cout << "no new primary server in group "
									<< groupName << endl;
						}
					}

				} else {
					buffer[valread] = '\0';
					string m = "";
					m.append(buffer);
					printf("data: %s\n", m.c_str());

					//master, get the message,
					if (mode == 2) {
						cout<< "get Message"<<endl;
						if (strstr(m.c_str(), "Primary?") != NULL) {
							string ress = "5001";
							reply(sd,ress);
							printf("send out 5001\n");
							continue;
						}
//						cout << "get the message from the client:" << m << endl;
						int port = socketInfo.getPortbysocket(sd);
						string addressStr = "127.0.0.1:" + to_string(port);
						//check if this message is from the client or the backend server
						if (bm.serverMap.count(addressStr) == 0) {

							if (m.compare("getUser") == 0) {
								string nameList;
								if (bm.clientTogroup.size() == 0) {
									string err = "ERR: -400 ERR";
									send2port(port, err, socketInfo);
								} else {
									for (auto it : bm.clientTogroup) {
										string username = it.first;
										nameList += username;
										nameList += " ";
									}
									string suc = "+200 OK " + nameList;
									send2port(port, suc, socketInfo);
								}

							} else if (strstr(m.c_str(), "getStatus") != NULL) {
								vector<int> portVector;
								portVector.push_back(5001);
								portVector.push_back(5002);
								portVector.push_back(5003);
								portVector.push_back(6001);
								portVector.push_back(6002);
								portVector.push_back(6003);
								portVector.push_back(7001);
								portVector.push_back(7002);
								portVector.push_back(7003);
								string status = "+200 OK ";
								bool ifLive;
								for (int i = 0; i < portVector.size(); i++) {
									ifLive = socketInfo.checkPort(
											portVector[i]);
									if (ifLive == true) {
										string portStatus = to_string(
												portVector[i]) + ":" + "Live ";
										status += portStatus;
									} else {
										string portStatus = to_string(
												portVector[i]) + ":" + "Die ";
										status += portStatus;
									}
								}
								send2port(port, status, socketInfo);

							} else {
								//from front client
								//cout << "userName is " << m << endl;
								string userName = m;
								if (bm.clientTogroup.count(userName) != 0) {
									cout << "old client" << endl;
									string group = bm.clientTogroup[userName];
									string res = bm.primaryMap[group] + "\n";
									reply(sd, res);
//									send2port(port, res, socketInfo);
								} else {
//									cout << "new client" << userName << endl;
									string assignedGroup =
											bm.getLessClientGroup(
													bm.groupToclient);
									bm.groupToclient =
											bm.constructGroupToClient(
													assignedGroup, userName,
													bm.groupToclient);
									bm.clientTogroup =
											bm.constructClientToGroup(
													bm.clientTogroup,
													bm.groupToclient);
									string res = bm.getAssignedServer(userName)
											+ "\n";
									reply(sd, res);
//									send2port(port, res, socketInfo);
								}
							}
						}
					}
					if (mode == 3) {
						if (m.length() < 5) {
							continue;
						}
						string comp = m.substr(0, 4);
						string out = m.substr(5);
						int adminTransPort = atoi(comp.c_str());
//						if (socketInfo.checkPort(8888)
//								&& socketInfo.getPortbysocket(sd) == 8888) {
						if (socketInfo.checkPort(adminTransPort)) {
							send2port(adminTransPort, out, socketInfo);
							char *buf = (char*) malloc(sizeof(char) * 100000);
							if (buf == NULL)
								perror("Malloc Failed");
							memset(buf, '\0', sizeof(char) * 100000);
							valread = read(
									socketInfo.getSocketbyport(adminTransPort),
									buf, 100000);
							string Msg = "";
							Msg.append(buf);
							reply(sd, Msg);
						} else {
							string errMsg = "-400 ERR";
							reply(sd, errMsg);
						}

//						}
					}

					if ((mode == 1 || mode == 0) && sd == admin_socket) {
//						printf("get from master\n");
						if (strcmp(m.c_str(), "shutdown") == 0
								&& shutdown == 0) {
							shutAllserver(socketInfo, max_clients,
									admin_socket);
							shutdown = 1;

							//empty the hashmap
							for (auto it : IFA.serverDataMap) {
								IFA.serverDataMap.erase(it.first);
							}
							printf("shutdown success\n");

						} else if (strstr(m.c_str(), "restart") != NULL
								&& shutdown == 1) {	//							int k = m.find(" ");
								//							printf("hello\n");
							reconnectPort(socketInfo, PORT, 8014);
							reconnectPort(socketInfo, PORT, portvec.at(0));
							reconnectPort(socketInfo, PORT, portvec.at(1));

//							listen_socket = listenServer(PORT, 10);
							shutdown = 0;
							master_socket = socketInfo.getSocketbyport(8014);
							printf("restart success\n");
//							break;
						}
						if (strstr(m.c_str(), "getValue") != NULL) {
							//get the number
//							printf("----------------\n");
							int spaceCount = 0;
//							int numBegin = 0;
//							for (int i = 0; i < m.length(); i++) {
//								if (isspace(m[i])) {
//									spaceCount++;
//									if (spaceCount == 1) {
//										numBegin = i;
//									}
//								}
//							}
							int k = m.find(" ");
							if (m.size() < 10) {
								string err = "-400 ERR";
								reply(sd, err);
							}
							int num;
							if (k == std::string::npos) {
								string err = "-400 ERR";
								reply(sd, err);
							} else {
								num = stoi(m.substr(k));
							}
							vector < string > succVector;
//							int num = stoi(m.substr(numBegin));
							int start = 10 * num - 10;
							int end = start + 9;
//							printf("%d\n",IFA.serverDataMap.size());
							if (IFA.serverDataMap.size() == 0
									|| start > IFA.serverDataMap.size()) {
								printf("Nothing\n");
								string err = "-400 ERR";
								reply(sd, err);
							} else {
								printf("1111\n");
								string suc = "+200 OK ";
								for (auto it : IFA.serverDataMap) {
									string username = it.first;
									string innerKey;
									string value;
									for (auto itt : IFA.serverDataMap[username]) {
										innerKey = itt.first;
										value = itt.second;
										string oneUserInfo = "username = "
												+ username + "," + "InnerKey = "
												+ innerKey + "," + "value = "
												+ value + "&";
										succVector.push_back(oneUserInfo);
									}

								}
								//get result
								if (end >= succVector.size() - 1) {
									for (int i = start; i < succVector.size();
											i++) {
										suc += succVector[i];
									}
									send2port(socketInfo.getPortbysocket(sd),
											suc, socketInfo);
								} else {
									for (int i = start; i <= end; i++) {
										suc += succVector[i];
									}
									send2port(socketInfo.getPortbysocket(sd),
											suc, socketInfo);
								}
							}
							continue;
						}
						string sucMsg = "+200 OK";
						reply(sd, sucMsg);

					}
					//get the reconnect message
					if ((mode == 0 || mode == 1)
							&& socketInfo.getPortbysocket(sd) == 8014) {
						if (strstr(m.c_str(), "reconnect") != NULL) {
							int k = m.find(" ");
							int newport;
							if (k != std::string::npos) {
								newport = atoi(m.substr(k).c_str());
								if (newport == 1) {
									listen_socket = listenServer(PORT, 10);
									break;
								}
								printf("%d\n", newport);
								primary_socket = reconnectServer(PORT, newport);
								if (primary_socket < 0) {
									printf("Port %d should be open first\n",
											newport);
									//									exit(1);
								} else {
									socketInfo.put(newport, primary_socket);
								}

							}
							break;
						} else if (strcmp(m.c_str(), "print") == 0) {
							for (i = 0; i < max_clients; i++) {
								int sock = socketInfo.getSocketbyid(i);
								if (sock > 0) {
									printf("ind:%d, socket: %d, port: %d\n", i,
											sock,
											socketInfo.getPortbysocket(sock));
								}
							}
						} else if (strcmp(m.c_str(), "primary") == 0) {

							string fname = "DataFile - " + to_string(PORT);
							IFA.serverDataMap = MF.FileToMap(fname);
							InterFaceAPI IFA_log;
							vector < string > logVector;
							logVector = log.readFile();
//							cout << "hehehehehheheh" << endl;
//							cout << logVector.size() << endl;
							for (int i = 0; i < logVector.size(); i++) {
								IFA_log.checkCommand(logVector[i]);
							}
							if (IFA_log.serverDataMap.size() != 0) {
								for (auto it : IFA_log.serverDataMap) {
									string outKey = it.first;
									unordered_map < string, string > innerMap =
											IFA_log.serverDataMap[outKey];
									for (auto iit : innerMap) {
										string innerKey = iit.first;
										IFA.serverDataMap[outKey][innerKey] =
												IFA_log.serverDataMap[outKey][innerKey];
									}
								}
							}
							if (listen_socket == 0) {
								listen_socket = listenServer(PORT, 10);
							}
							shutdown = 0;
							mode = 0;
						} else if (strcmp(m.c_str(), "secondary") == 0) {
							log.checkRestart();
							if (log.showmode() == 0) {
								InterFaceAPI IFA_log;
								vector < string > logVector;
								logVector = log.readFile();
								for (int i = 0; i < logVector.size(); i++) {
									IFA_log.checkCommand(logVector[i]);
								}
								if (IFA_log.serverDataMap.size() != 0) {
									//copy this to the server map
									IFA.serverDataMap = IFA_log.serverDataMap;
								}
							}
							shutdown = 1;
							mode = 1;
							int newport = portvec.at(0);
							primary_socket = reconnectServer(PORT, newport);
							socketInfo.put(newport, primary_socket);

						} else if (strstr(m.c_str(), "success") != NULL) {
							log.closeFile();
							log.checkRestart();
						} else if (strstr(m.c_str(), "primaryport") != NULL) {
							int k = m.find(" ");
							if (k != std::string::npos) {
								int newport = atoi(m.substr(k).c_str());
								if (socketInfo.getPortbysocket(primary_socket)
										== newport) {
									continue;
								} else {
									primary_socket = reconnectServer(PORT,
											newport);
									socketInfo.put(newport, primary_socket);
								}
							}
							if (listen_socket > 0) {
								shutServer(listen_socket);
								listen_socket = 0;
							}

							mode = 1;
							shutdown = 1;
							printf("listen_socket:%d shutdown:%d \n",
									listen_socket, shutdown);
							break;
						}
					}

					// primary receive data from non-master socket, mode == 0: primary server of group
					//construct the map of this server

					if (mode == 0 && sd != master_socket && sd != admin_socket
							&& globalPort != 8001) {
						receiveData = 1;
						printf("Can write file\n");
						MF.constructKeyWord();

						string res = IFA.checkCommand(m);
						if (strcmp(res.c_str(), "") == 0) {
							continue;
						}
						string fileName = "DataFile - " + to_string(PORT);
						MF.MapToFILE(IFA.serverDataMap, fileName);
						send2port(socketInfo.getPortbysocket(sd), res,
								socketInfo);
						vector < string > out;
						IFA.tokenize(m, out, 2);
						string userName = out[1];
						MF.constructUserName(userName);
						//log file
						string logData = "";
						logData.append(buffer);
						log.writeFile(socketInfo.getPortbysocket(sd), logData);
					}

					// checkpoint
					//write the content of hashmap to the datafile of this server, in the primary server
					if (mode == 0 && globalPort == 8001) {
						if (strstr(m.c_str(), "write") != NULL) {

							if (IFA.serverDataMap.size() == 0) {
								receiveData = 0;
								continue;
							}

							string fileName = "DataFile - " + to_string(PORT);
							MF.MapToFILE(IFA.serverDataMap, fileName);
							cout << "Checkpoint" << endl;
							printf("\n\n\nshow map");
							for (auto it : IFA.serverDataMap) {
								string username = it.first;
								string innerKey;
								string value;
								for (auto itt : IFA.serverDataMap[username]) {
									innerKey = itt.first;
									value = itt.second;
									string oneUserInfo = "username = "
											+ username + "," + "InnerKey = "
											+ innerKey + "," + "value = "
											+ value + "&";
									printf("%s\n", oneUserInfo.c_str());
									//									succVector.push_back(oneUserInfo);
								}

							}
							if (socketInfo.checkPort(portvec.at(0))) {
								printf("write to %d\n", portvec.at(0));
								char buf[102400];
								FILE *fp;
								fp = fopen(fileName.c_str(), "r");
								while (fgets(buf, 102400, fp)) {
									string outk;
									outk.append(buf);
									send2port(portvec.at(0), outk, socketInfo);
								}
								string endstr = "end write";
								send2port(portvec.at(0), endstr, socketInfo);
							}
							if (socketInfo.checkPort(portvec.at(1))) {
								printf("write to %d\n", portvec.at(1));
								char buf[1024];
								FILE *fp;
								fp = fopen(fileName.c_str(), "r");
								while (fgets(buf, 1024, fp)) {
									string outk;
									outk.append(buf);
									send2port(portvec.at(1), outk, socketInfo);
								}
								string endstr = "end write";
								send2port(portvec.at(1), endstr, socketInfo);
							}
							receiveData = 0;
						}
					}
					if (mode == 1 && sd == primary_socket) {
						string fileName = "DataFile - " + to_string(PORT);

						//write to file
//						int fileLineNum = MF.lineNumberOfFile(fileName);
//						if (fileLineNum != 0) {
//							MF.deleteLinesInfile(fileName, 1, fileLineNum);
//						}
						ofstream filePointer;
						if (start2write == 0) {
							filePointer.open(fileName, ios::out);
							printf("\n\n\nstart to write\n\n\n");
							start2write = 1;
						} else {
							filePointer.open(fileName, ios::app);
						}

//						FILE *fp;
//						fp = fopen(fileName.c_str(), "a");
//						while (fgets(buf, 1024, fp)) {
//							string outk;
//							outk.append(buf);
//							send2port(portvec.at(1), outk, socketInfo);
//						}

						if (strstr(m.c_str(), "end write") != NULL) {
							//file -> msp
							int k = m.find("end write");
							if (k > 0) {
								filePointer << m.substr(0, k);
								filePointer.close();
							}
							IFA.serverDataMap = MF.FileToMap(fileName);
							int size1 = IFA.serverDataMap.size();
							printf("\n\n\nshow map");
							for (auto it : IFA.serverDataMap) {
								string username = it.first;
								string innerKey;
								string value;
								for (auto itt : IFA.serverDataMap[username]) {
									innerKey = itt.first;
									value = itt.second;
									string oneUserInfo = "username = "
											+ username + "," + "InnerKey = "
											+ innerKey + "," + "value = "
											+ value + "&";
									printf("%s\n", oneUserInfo.c_str());
								}

							}
							printf("size:%d\n", size1);
							start2write = 0;
						} else {

							filePointer << m;
						}

					}

				}
			}
		}
	}
	return 0;
}
