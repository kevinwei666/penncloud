#include "client_server.h"

// handle sigint in main thread
void sig_handler (int signuum ) {
	sig_flag = 1;
	for(auto sock: sock_set){
		cout << sock << endl;
		sock_write(sock,(char *)"-ERR Server shutting down\r\n");
		if(close(sock) < 0){
		    fprintf(stderr,"error close %d socket", sock);
			exit(1);
		}
	}

	for(auto thread: thread_set){
		pthread_cancel(thread);
	}
	exit(0);
}

// thread working
void *thread_handler(void *new_sock)
{

    int sock = *(int *)new_sock;
    char *write_msg;

    //initilize some variables
    char read_buffer[10250];
    char temp_buffer[10250];
    int onetime_read_size;
    int read_count = 0;
    int line_flag = 0;
    int line_length;

    // read from client
    while( (onetime_read_size = read(sock , &read_buffer[read_count] , sizeof(read_buffer)-1)) > 0)
    {

    	cout << read_buffer << endl;
    	line_flag = 0;
    	read_count += onetime_read_size;
    	//exam and extract full line and keep the rest on temp_buffer
    	if(read_count >=2){
    		for(int i = 0; i <read_count-1 ;i++){
    			if(read_buffer[i] == '\r' && read_buffer[i+1] == '\n'){
    		   		line_flag = 1;
    		   		line_length = i+2;
    		   		for(int m = 0; m <  read_count - line_length;m++ ){
    		   			temp_buffer[m] = read_buffer[m+line_length];
    		   		}
    		   		break;
    			}
    		}
    	}

    	// the temp_buffer may contain mutiple full lines, thus while loop used
    	while(line_flag == 1){
    		line_flag = 0;
			read_buffer[line_length] = '\0';
			// debug mode
			string buffer_str(read_buffer);
			buffer_str = buffer_str.substr(0,buffer_str.length()-1);
			if(vflag) cout << '['<< sock << "] C: " << buffer_str << endl;
			// end of debug mode

			// get command

			char *command = strtok(read_buffer, " ");
			if(strcmp(command,"GET")==0){
				char* filename_t = strtok(NULL, " ");
				char* filename = strtok(filename_t, ".");
				char* suffix = strtok(NULL, ".");

				string file_loc;
				if (suffix == NULL){
					file_loc = string("assets") + filename + ".html";
				}else if(strcmp(suffix,"css")==0){
					file_loc = string("assets") + filename + ".css";
				}

//				cout << file_loc << endl;
			    ifstream content(&file_loc[0]);
			    stringstream html_content;
			    string line;
			    while(getline(content,line)){
			         html_content<<line;
			     }
			    string conten_string = html_content.str();
			    string totest;
			    if (suffix == NULL){
			    	totest = string("HTTP/1.1 200 OK\r\n") + "Content-type: text/html\r\n" + "Content-length: "+ to_string(conten_string.length())+"\r\n" + "\r\n";
			    }else if(strcmp(suffix,"css")==0){
					totest = string("HTTP/1.1 200 OK\r\n") + "Content-type: text/css\r\n" + "Content-length: "+ to_string(conten_string.length())+"\r\n" + "\r\n";
				}


			    totest = totest + conten_string;
//			    cout << totest<< endl;

			    write_msg = &totest[0];
			    sock_write(sock,write_msg);
			    // -v debug mode
			    string msg_str(write_msg);
			    msg_str = msg_str.substr(0,msg_str.length()-1);
			    if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
			    //end of -v debug mode
			}
			//push temp_buffer to read_buffer and clean data
			memset(read_buffer, 0, 1025);
			for(int m = 0; m < read_count - line_length ; m++){
				read_buffer[m] = temp_buffer[m];
			}
			memset(temp_buffer, 0, 1025);

			//update read_count
			read_count = read_count - line_length ;

			//detect whether there is new full line
			if(read_count>=2){
	    		for(int i = 0; i <read_count-1 ;i++){
	    			if(read_buffer[i] == '\r' && read_buffer[i+1] == '\n'){
	    		   		line_flag = 1;
	    		   		line_length = i+2;
	    		   		for(int m = 0; m <  read_count - line_length;m++ ){
	    		   			temp_buffer[m] = read_buffer[m+line_length];
	    		   		}
	    		   		break;
	    			}
	    		}
			}
    	}

    }
    if(onetime_read_size == 0)
    {
    	sock_set.erase(sock);
    	cout << "one thread terminated" << endl;
    	return 0;
    }


    if(onetime_read_size < 0)
    {
        fprintf(stderr, "error read (server)\n");
        exit(1);
    }
    cout << "end reached" << endl;
	return 0;

}


int main(int argc , char *argv[])
{
	//get user input, initial port is 10000 (-v(debug mode)  -a(std error)  -p(port) 10000)
	int PORT = 10000;
	int c;

	while ((c = getopt (argc, argv, "p:av")) != -1)
	switch (c)
	  {
	  case 'a':{
		fprintf(stderr,"Full Name: Xinlong Zheng, SEAS login: xinlongz\n");
		exit(1);
	  }
		break;

	  case 'v':{
		vflag = 1;
	  }
		break;

	  case 'p':{

		  string s = optarg;
		  auto it = s.begin();
		  while (it != s.end() && std::isdigit(*it)) ++it;

		  if(!s.empty() && it == s.end() && atoi(optarg) >= 1){
			  PORT = atoi(optarg);
		  }
		  else{
			fprintf(stderr, "Option -n requires a positive integer argument.\n");
			exit(1);
		  }
	  }
		break;

	  case '?':
		if (optopt == 'p')
		  fprintf (stderr, "Option -%c requires an argument.\n", optopt);
		else if (isprint (optopt))
		  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
		else
		  fprintf (stderr,"Unknown option character `\\x%x'.\n", optopt);
		exit(1);
	  default:
		abort ();
	  }
     // construct sock connection
    if ( signal(SIGINT, sig_handler) == SIG_ERR ) {
        fprintf(stderr, "error capture signal ctrl+c (server)\n");
        exit(1);
    }

    int server_fd , new_sock , addrlen, opt =1;
    struct sockaddr_in server_addr, client_addr;

    if((server_fd = socket(AF_INET , SOCK_STREAM , 0)) == 0){
        fprintf(stderr, "error create socket (server)\n");
        exit(1);
    }

    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    {
        fprintf(stderr, "error setosocketopt (server)\n");
        exit(1);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons( PORT );

    if( bind(server_fd,(struct sockaddr *)&server_addr , sizeof(server_addr)) < 0)
    {
        fprintf(stderr, "error bind (server)\n");
        exit(1);
    }


    if (listen(server_fd, max_connection) < 0)
    {
        fprintf(stderr, "error listen (server)\n");
        exit(1);
    }

    addrlen = sizeof(struct sockaddr_in);
    int thread_idx = 0;

    //waiting for connection and create threads
    while(true)
    {
    	new_sock = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t*)&addrlen);
    	if(new_sock < 0){
            fprintf(stderr, "error accept (server)\n");
            exit(1);
    	}

     // handle sychronization issue
    	if(sig_flag == 1){
    		sock_write(new_sock,(char *)"-ERR Server shutting down\r\n");
    		if(close(new_sock) < 0){
    		    fprintf(stderr,"error close %d server", new_sock);
    			exit(1);
    		}
    	}
    	//create thread and make a record
    	if(sig_flag == 0){
        	cout << '['<< new_sock << ']' << " New connection" << endl;
        	pthread_t thread;
			if( pthread_create(&thread , NULL ,  thread_handler , (void*) &new_sock) < 0)
			{
				fprintf(stderr, "error create thread (server)\n");
				exit(1);
			}
			thread_set.insert(thread);
			sock_set.insert(new_sock);
    	}
    }

    return 0;
}
