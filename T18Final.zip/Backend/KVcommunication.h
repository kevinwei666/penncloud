#ifndef KVCOMMUNICATION_H
#define KVCOMMUNICATION_H

#include <stdio.h>
#include <sys/socket.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <map>
#include "basicServer.h"
using namespace std;

void checkClient(int socket, int port, char *add, int connect);
int connect2Port(int socket, int masterPort);
int createSocket(int PORT);
void shutServer(int socket);
int reconnectServer(int selfPort, int connectedPort);
int listenServer(int PORT, int maxSocket);
void getNewclient(int socket, int *client_socket,
		map<int, int> &client_socket_port, map<int, int> &client_port2socket,
		map<int, string> &client_socket_add, int size);
int acceptNewclient(int socket, basicServer &socketInfo);

#endif
