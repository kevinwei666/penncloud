#ifndef _CONFIG_H
#define _CONFIG_H

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <iostream>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <vector>
#include <sstream> 
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>


#include <netinet/in.h>
#include <resolv.h>
#include <netdb.h>

using namespace std;



#endif
