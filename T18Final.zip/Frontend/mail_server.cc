#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <iostream>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <vector>
#include <sys/types.h>
#include <dirent.h>
#include <libgen.h>
#include <time.h>
#include <sys/file.h>
#include <unordered_map>
#include <unordered_set>

using namespace std;

#define max_connection 2048 //max connection concurrenctly
int vflag = 0;  // vflag for -v user input
volatile int sig_flag = 0;  // volatile sig_flag for synchronization connection while signal captured

unordered_set<pthread_t> thread_set;
unordered_set<int> sock_set;


// write to client with while loop
int sock_write(int fd, char *buffer){
	int total_len = strlen(buffer);
	int sent_byte = 0;
	while(sent_byte < total_len){
		int one_time_sent = write(fd, &buffer[sent_byte],total_len-sent_byte);
		if(one_time_sent < 0){
	        fprintf(stderr, "error write (server)\n");
	        exit(1);
		}
		sent_byte += one_time_sent;
	}
	return sent_byte;
}
void sig_handler (int signuum ) {
	sig_flag = 1;
	for(auto sock: sock_set){
		cout << sock << endl;
		sock_write(sock,(char *)"-ERR Server shutting down\r\n");
		if(close(sock) < 0){
		    fprintf(stderr,"error close %d socket", sock);
			exit(1);
		}
	}

	for(auto thread: thread_set){
		pthread_cancel(thread);
	}
	exit(0);
}
string send2port(string &message, int port) {
	int sockfd, connfd;
	struct sockaddr_in servaddr, cli;

	// socket create and varification
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) {
		printf("socket creation failed...\n");
		exit(0);
	} else
		printf("Socket successfully created..\n");
	bzero(&servaddr, sizeof(servaddr));

	// assign IP, PORT
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(port);

	// connect the client socket to server socket
	if (connect(sockfd, (struct sockaddr*) &servaddr, sizeof(servaddr)) != 0) {
		printf("connection with the server failed...\n");
		exit(0);
	} else
		printf("connected to the server..\n");

	if (send(sockfd, message.c_str(), strlen(message.c_str()), 0)
			!= strlen(message.c_str())) {
		perror("send");
	}

	char buffer[1024];
//	int port;
	int valread;
	string m = "";
	while ((valread = read(sockfd, buffer, 1024)) != 0) {
		buffer[valread] = '\0';
		m.append(buffer);
		break;
	}
	close(sockfd);
	return m;
}


string getUser(){
	string message = "getUser";
	string output = send2port(message, 8014);
	return output;
}

string sendMsg(string &message, string &message2) {
	string output = send2port(message, 8014);
	int k = output.find(":");
	int port = atoi(output.substr(k + 1).c_str());
	cout << "give back port:" << port << endl;
	string out2 = send2port(message2, port);
	return out2;
}


// thread working
void *thread_handler(void *new_sock)
{

	int sock = *(int*) new_sock;

    char *write_msg;
    // greeting to connection
    write_msg = (char*)"220 localhost service ready!\r\n";
    sock_write(sock,write_msg);

    // -v debug mode
    string msg_str(write_msg);
    msg_str = msg_str.substr(0,msg_str.length()-1);
    if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
    //end of -v debug mode

    //initilize some variables
    char read_buffer[1025];
    char temp_buffer[1025];
    int onetime_read_size;
    int read_count = 0;
    int line_flag = 0;
    int line_length;

    bool connected = false;
    bool get_sender = false;
    bool get_rev = false;
    bool trans_start = false;
    string sender_name;
    string sender_domain;
    string rev_name;
    vector<string> rev_name_set;
    vector<string> mail_content;

    // \mailGetuser
    string BE_reponse = getUser();
//    cout << BE_reponse << endl;
    vector<string> account_avaliable;
//    account_avaliable.push_back("xinlong");
//    account_avaliable.push_back("shaozhe");
//    account_avaliable.push_back("xiaozhou");
//    account_avaliable.push_back("kevin");


    // read from client
    while( (onetime_read_size = read(sock , &read_buffer[read_count] , sizeof(read_buffer)-1)) > 0)
    {
    	string BE_reponse = getUser();
    	account_avaliable.clear();
    	char* BE_ptr = &BE_reponse[0];
    	char* namelist = strstr(BE_ptr,"+200 OK ")+ strlen("+200 OK ");
    	char* firstname = strtok(namelist, " ");
    	string first_str(firstname);
    	account_avaliable.push_back(first_str);
    	cout << first_str << endl;

    	char* tmp;
    	while((tmp = strtok(NULL," ")) != NULL){
    		string tmp_str(tmp);
    		account_avaliable.push_back(tmp_str);
    		cout << tmp_str << endl;
    	}

    	line_flag = 0;
    	read_count += onetime_read_size;
    	cout << read_buffer << endl;
    	//exam and extract full line and keep the rest on temp_buffer
    	if(read_count >=2){
    		for(int i = 0; i <read_count-1 ;i++){
    			if(read_buffer[i] == '\r' && read_buffer[i+1] == '\n'){
    		   		line_flag = 1;
    		   		line_length = i+2;
    		   		for(int m = 0; m <  read_count - line_length;m++ ){
    		   			temp_buffer[m] = read_buffer[m+line_length];
    		   		}
    		   		break;
    			}
    		}
    	}

    	// the temp_buffer may contain mutiple full lines, thus while loop used
    	while(line_flag == 1){
    		line_flag = 0;
			read_buffer[line_length] = '\0';

			// debug mode
			string buffer_str(read_buffer);
			buffer_str = buffer_str.substr(0,buffer_str.length()-1);
			if(vflag) cout << '['<< sock << "] C: " << buffer_str << endl;
			// end of debug mode

			// get command
			char command[1025];
			int count = 0;
			while(count <read_count && read_buffer[count] != ' '){
				command[count] = read_buffer[count];
				count++;
			}
			command[count] = '\0';


			string command_string(command);
			string buffer_str_use(read_buffer);
			// after DATA command, start receive data
			if(trans_start){
				if(buffer_str_use.size() == 3 && buffer_str_use[0] == '.'&& buffer_str_use[1] == '\r'&& buffer_str_use[2] == '\n'){

					for(int m = 0; m < rev_name_set.size(); m++){
						string send_to_BE = "";
						string email_head_str;

						rev_name = rev_name_set[m];

						time_t raw_time = time(NULL);
						string email_time(ctime(&raw_time));
						email_head_str = "From " + sender_name + "@" + sender_domain + " " + email_time ;

						char* email_head = &email_head_str[0];

						for(int i = 0; i < mail_content.size(); i++){
							string mgs_str = mail_content[i];
							send_to_BE += mgs_str;
						}
						char* send_to_BE_ptr = &send_to_BE[0];
						char* content_we_get = strstr(send_to_BE_ptr,"\r\n\r\n") + strlen("\r\n\r\n");
						string cont_send(content_we_get);

						char* subject_we_get = strstr(send_to_BE_ptr,"Subject: ") + strlen("Subject: ");
						char* subject_tail = strstr(subject_we_get,"\r\n");
						string subject_str = send_to_BE.substr(subject_we_get-send_to_BE_ptr,subject_tail-subject_we_get);
						email_head_str = subject_str + " " + email_head_str;
						string send_BE = "mailRev " + rev_name + "\r\n" + email_head_str + "\r\n" + cont_send;
						string BE_response = sendMsg(rev_name,send_BE);

						cout << send_BE << endl;
						cout << BE_response << endl;

//						cout << email_head_str ;
//						cout << "cooooonnnnnnnnnnntttttttttttttteeeeeeenttttt" << endl;
//						cout << send_to_BE ;
						//\mailRev username<CRLF>head<CRLF>content<CRLF>
					}

					trans_start = false;
					write_msg = (char*)"250 OK\r\n";
					sock_write(sock,write_msg);
					// -v debug mode
					string msg_str(write_msg);
					msg_str = msg_str.substr(0,msg_str.length()-1);
					if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;

				}else{
					mail_content.push_back(buffer_str_use);
				}

			}else{
			// deal with multiple commands
			if(command_string.substr(0,4) == "HELO"){
				connected = true;

			    write_msg = (char*)"250 localhost\r\n";
			    sock_write(sock,write_msg);

			    // -v debug mode
			    string msg_str(write_msg);
			    msg_str = msg_str.substr(0,msg_str.length()-1);
			    if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
			    //end of -v debug mode

			}else if(command_string.substr(0,4) == "MAIL" && buffer_str_use.size() > 10 && buffer_str_use.substr(0,10) == "MAIL FROM:"){
				if(connected == false){
				    write_msg = (char*)"503 Bad sequence of commands\r\n";
				    sock_write(sock,write_msg);

				    // -v debug mode
				    string msg_str(write_msg);
				    msg_str = msg_str.substr(0,msg_str.length()-1);
				    if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
				    //end of -v debug mode
				}else{
					char* start_name = strstr(read_buffer,"<")+1;
					char* end_name = strstr(read_buffer,"@");
					char* start_domain = end_name + 1;
					char* end_domain = strstr(read_buffer,">");
					sender_name = buffer_str_use.substr(start_name-read_buffer,end_name-start_name);
					sender_domain = buffer_str_use.substr(start_domain-read_buffer,end_domain-start_domain);
					get_sender = true;
					write_msg = (char*)"250 OK\r\n";
					sock_write(sock,write_msg);
				}
			}
			else if(command_string.substr(0,4) == "RCPT" && buffer_str_use.size() > 8 && buffer_str_use.substr(0,8) == "RCPT TO:"){
				if(connected == false){
					write_msg = (char*)"503 Bad sequence of commands\r\n";
					sock_write(sock,write_msg);

					// -v debug mode
					string msg_str(write_msg);
					msg_str = msg_str.substr(0,msg_str.length()-1);
					if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
					//end of -v debug mode
				}else{
					char* start_name = strstr(read_buffer,"<")+1;
					char* end_name = strstr(read_buffer,"@");
					char* start_domain = end_name + 1;
					char* end_domain = strstr(read_buffer,">");

					rev_name = buffer_str_use.substr(start_name-read_buffer,end_name-start_name);
					string domain_name = buffer_str_use.substr(start_domain-read_buffer,end_domain-start_domain);

					get_rev = false;
					for(int i = 0; i < account_avaliable.size(); i++){
						if(account_avaliable[i] == rev_name && domain_name == "penncloud.com"){
							write_msg = (char*)"250 OK\r\n";
							sock_write(sock,write_msg);

							// -v debug mode
							string msg_str(write_msg);
							msg_str = msg_str.substr(0,msg_str.length()-1);
							if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
							//end of -v debug mode
							get_rev = true;
						}
					}
					if(get_rev == false){
						write_msg = (char*)"550 Invalid user to send(not exist!)\r\n";
						sock_write(sock,write_msg);
						// -v debug mode
						string msg_str(write_msg);
						msg_str = msg_str.substr(0,msg_str.length()-1);
						if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
						//end of -v debug mode
					}else{
						rev_name_set.push_back(rev_name);
					}
					if(rev_name_set.size() > 0) get_rev = true;
				}
			}else if(command_string.substr(0,4) == "DATA"){
				if(connected && get_sender && get_rev){
					mail_content.clear();
					trans_start = true;
					write_msg = (char*)"354 start sending email\r\n";
					sock_write(sock,write_msg);
					// -v debug mode
					string msg_str(write_msg);
					msg_str = msg_str.substr(0,msg_str.length()-1);
					if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
					//end of -v debug mode
				}else{
					write_msg = (char*)"502 commands not implemented\r\n";
					sock_write(sock,write_msg);
					// -v debug mode
					string msg_str(write_msg);
					msg_str = msg_str.substr(0,msg_str.length()-1);
					if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
					//end of -v debug mode
				}
			}else if(command_string.substr(0,4) == "RSET"){
				mail_content.clear();
				rev_name_set.clear();
			    get_sender = false;
			    get_rev = false;
			    trans_start = false;
			    memset(read_buffer, 0, 1025);
				memset(temp_buffer, 0, 1025);
				line_flag = 0;
				read_count = 0;
				line_length = 0;

				write_msg = (char*)"250 OK\r\n";
				sock_write(sock,write_msg);

				// -v debug mode
				string msg_str(write_msg);
				msg_str = msg_str.substr(0,msg_str.length()-1);
				if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
				//end of -v debug mode
			}
			else if(command_string.substr(0,4) == "QUIT"){
				write_msg = (char*)"221 Goodbye!\r\n";
				sock_write(sock , write_msg);
				//-v debug mode
				string msg_str(write_msg);
				msg_str = msg_str.substr(0,msg_str.length()-1);
				if(vflag) {
					cout << '['<< sock << "] S: " << msg_str << endl;
					cout << '['<< sock << "] " << "Connection closed" << endl;
				}
				// end of debug mode
				sock_set.erase(sock);
				if(close(sock) < 0){
					fprintf(stderr,"error close %d server", sock);
					exit(1);
				}
				return 0;

			}else if(command_string.substr(0,4) == "NOOP"){
				if(connected){
					write_msg = (char*)"250 OK\r\n";
					sock_write(sock,write_msg);

					// -v debug mode
					string msg_str(write_msg);
					msg_str = msg_str.substr(0,msg_str.length()-1);
					if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
				}else{
					write_msg = (char*)"503 Bad sequence of commands\r\n";
					sock_write(sock,write_msg);
					// -v debug mode
					string msg_str(write_msg);
					msg_str = msg_str.substr(0,msg_str.length()-1);
					if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
				}

			}else{
				write_msg = (char*)"500 syntax error, command unrecognized\r\n";
				sock_write(sock , write_msg);

				//debug mode
				string msg_str(write_msg);
				msg_str = msg_str.substr(0,msg_str.length()-1);
				if(vflag) cout << '['<< sock << "] S: " << msg_str << endl;
				// end of debug mode

			}
			}
			//push temp_buffer to read_buffer and clean data
			memset(read_buffer, 0, 1025);
			for(int m = 0; m < read_count - line_length ; m++){
				read_buffer[m] = temp_buffer[m];
			}
			memset(temp_buffer, 0, 1025);

			//update read_count
			read_count = read_count - line_length ;

			//detect whether there is new full line
			if(read_count>=2){
	    		for(int i = 0; i <read_count-1 ;i++){
	    			if(read_buffer[i] == '\r' && read_buffer[i+1] == '\n'){
	    		   		line_flag = 1;
	    		   		line_length = i+2;
	    		   		for(int m = 0; m <  read_count - line_length;m++ ){
	    		   			temp_buffer[m] = read_buffer[m+line_length];
	    		   		}
	    		   		break;
	    			}
	    		}
			}
    	}

    }

    if(onetime_read_size < 0)
    {
        fprintf(stderr, "error read (server)\n");
        exit(1);
    }

	return 0;

}


int main(int argc , char *argv[])
{
	//get user input, initial port is 10000 (-v(debug mode)  -a(std error)  -p(port) 10000)
	int PORT = 2500;
	int c;

	while ((c = getopt (argc, argv, "p:av")) != -1)
	switch (c)
	  {
	  case 'a':{
		fprintf(stderr,"Full Name: Xinlong Zheng, SEAS login: xinlongz\n");
		exit(1);
	  }
		break;

	  case 'v':{
		vflag = 1;
	  }
		break;

	  case 'p':{

		  string s = optarg;
		  auto it = s.begin();
		  while (it != s.end() && std::isdigit(*it)) ++it;

		  if(!s.empty() && it == s.end() && atoi(optarg) >= 1){
			  PORT = atoi(optarg);
		  }
		  else{
			fprintf(stderr, "Option -p requires a positive integer argument.\n");
			exit(1);
		  }
	  }
		break;

	  case '?':
		if (optopt == 'p')
		  fprintf (stderr, "Option -%c requires an argument.\n", optopt);
		else if (isprint (optopt))
		  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
		else
		  fprintf (stderr,"Unknown option character `\\x%x'.\n", optopt);
		exit(1);
	  default:
		abort ();
	  }

     // construct sock connection
    if ( signal(SIGINT, sig_handler) == SIG_ERR ) {
        fprintf(stderr, "error capture signal ctrl+c (server)\n");
        exit(1);
    }

    int server_fd , new_sock , addrlen, opt =1;
    struct sockaddr_in server_addr, client_addr;


    if((server_fd = socket(AF_INET , SOCK_STREAM , 0)) == 0){
        fprintf(stderr, "error create socket (server)\n");
        exit(1);
    }

    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    {
        fprintf(stderr, "error setosocketopt (server)\n");
        exit(1);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons( PORT );

    if( bind(server_fd,(struct sockaddr *)&server_addr , sizeof(server_addr)) < 0)
    {
        fprintf(stderr, "error bind (server)\n");
        exit(1);
    }


    if (listen(server_fd, max_connection) < 0)
    {
        fprintf(stderr, "error listen (server)\n");
        exit(1);
    }

    addrlen = sizeof(struct sockaddr_in);

    //waiting for connection and create threads
    while(true)
    {
    	new_sock = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t*)&addrlen);

    	if(new_sock < 0){
            fprintf(stderr, "error accept (server)\n");
            exit(1);
    	}
     // handle sychronization issue
    	if(sig_flag == 1){
    		sock_write(new_sock,(char *)"221 Server shutting down\r\n");
    		if(close(new_sock) < 0){
    		    fprintf(stderr,"error close %d server", new_sock);
    			exit(1);
    		}
    	}
    	//create thread and make a record
    	if(sig_flag == 0){
    		sock_set.insert(new_sock);

        	cout << '['<< new_sock << ']' << " New connection" << endl;
        	pthread_t thread;
			if( pthread_create(&thread , NULL ,  thread_handler , (void*) &new_sock) < 0)
			{
				fprintf(stderr, "error create thread (server)\n");
				exit(1);
			}
			thread_set.insert(thread);
    	}
    }

    return 0;
}
