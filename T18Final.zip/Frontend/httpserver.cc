#include "httpserver.h"

string Domain2IP(string domain_input)
{
    u_char nsbuf[4096];
    char dispbuf[4096];
    ns_msg msg;
    ns_rr rr;
    int i, l;
    string mail_addr;
    string res;
    char* domain_str = &domain_input[0];
    l = res_query(domain_str,  C_IN, T_MX, nsbuf, sizeof(nsbuf));
    if (l < 0)
    {
      cerr << "wrong fetch ip from domain" << endl;
    }
    else
    {
      /* just grab the MX answer info */
      ns_initparse(nsbuf, l, &msg);
      l = ns_msg_count(msg, ns_s_an);

        ns_parserr(&msg, ns_s_an, 0, &rr);
        ns_sprintrr(&msg, &rr, NULL, NULL, dispbuf, sizeof(dispbuf));
        string buf_str(dispbuf);
        string m = buf_str;
        int k = m.find(" ");
        string latter=m;
        string formmer;
        while(k!=std::string::npos){
         formmer = latter.substr(0,k);
         latter = latter.substr(k+1);
         k = latter.find(" ");
        }
        latter = latter.substr(0,latter.length());
        mail_addr = latter;
    }

	l = res_query(&mail_addr[0],  C_IN, T_A, nsbuf, sizeof(nsbuf));
	if (l < 0)
	{
		cerr << "wrong fetch ip from domain" << endl;
	}
	ns_initparse(nsbuf, l, &msg);
	l = ns_msg_count(msg, ns_s_an);

	ns_parserr(&msg, ns_s_an, 0, &rr);
	ns_sprintrr(&msg, &rr, NULL, NULL, dispbuf, sizeof(dispbuf));
	string buf_str(dispbuf);
	string m = buf_str;
	int k = m.find(" ");
	string latter=m;
	string formmer;
	while(k!=std::string::npos){
		formmer = latter.substr(0,k);
		latter = latter.substr(k+1);
		k = latter.find(" ");
	}
	latter = latter.substr(0,latter.length());
	res = latter;

    return res;
}



int sock_write(int fd, char *buffer){
	int total_len = strlen(buffer);
	int sent_byte = 0;
	while(sent_byte < total_len){
		int one_time_sent = write(fd, &buffer[sent_byte],total_len-sent_byte);
		if(one_time_sent < 0){
	        fprintf(stderr, "error write (server)\n");
	        exit(1);
		}
		sent_byte += one_time_sent;
	}
	return sent_byte;
}

string send2port(string &message, int port) {
	int sockfd, connfd;
	struct sockaddr_in servaddr, cli;

	// socket create and varification
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd == -1) {
		printf("socket creation failed...\n");
		exit(0);
	} else
		printf("Socket successfully created..\n");
	bzero(&servaddr, sizeof(servaddr));

	// assign IP, PORT
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	servaddr.sin_port = htons(port);

	// connect the client socket to server socket
	if (connect(sockfd, (struct sockaddr*) &servaddr, sizeof(servaddr)) != 0) {
		printf("connection with the server failed...\n");
		exit(0);
	} else
		printf("connected to the server..\n");

	if (send(sockfd, message.c_str(), strlen(message.c_str()), 0)
			!= strlen(message.c_str())) {
		perror("send");
	}

	char buffer[1024];
//	int port;
	int valread;
	string m = "";
	while ((valread = read(sockfd, buffer, 1024)) != 0) {
		buffer[valread] = '\0';
		m.append(buffer);
		break;
	}
	close(sockfd);
	return m;
}


string getUser(){
	string message = "getUser";
	string output = send2port(message, 8014);
	return output;
}

string sendMsg(string &message, string &message2) {
	string output = send2port(message, 8014);
	int k = output.find(":");
	int port = atoi(output.substr(k + 1).c_str());
	cout << "give back port:" << port << endl;
	string out2 = send2port(message2, port);
	return out2;
}


HttpServer::HttpServer(int sock){
	this->sock = sock;
	this->mailSubject = "No Subject";
	this->mailContent = "No Content";
	domain_to_ip["penncloud.com"] = "127.0.0.1";
	domain_to_ip["seas.upenn.edu"] = "148.163.137.158";
	domain_to_ip["gmail.com"] = "209.85.202.26";

	domain_to_port["penncloud.com"] = 2500;
	domain_to_port["seas.upenn.edu"] = 25;
	domain_to_port["gmail.com"] = 25;

}
HttpServer::~HttpServer(){
//    string send_BE = "deleteCookie " + username + " " + cur_cookie;
//    cout << "quittinnggggg--------------" << endl;
//    string BE_response = sendMsg(username,send_BE);
//    cout << BE_response << endl;
	cout << "one http server quit" << endl;
}
int HttpServer::sendMail(){
	cout << "start sendmail -------" << endl;
	for(int i = 0; i < mailRCPTS.size(); i++){
		cout << "getting to send one mail -------------" << endl;
		string rcpt = mailRCPTS[i];
		cout << rcpt << endl;
		char* rcpt_ptr = &rcpt[0];
		char* tmp_ptr = strstr(rcpt_ptr,"@");
		cout << rcpt_ptr << endl;
		cout << tmp_ptr << endl;
		string rcpt_name = rcpt.substr(0,tmp_ptr-rcpt_ptr);
		string rcpt_domain(tmp_ptr+1);
		cout << rcpt_name << endl;
		cout << rcpt_domain << endl;
		cout << "parse rcpt data -----------" << endl;
		int sock = 0, valread;
		struct sockaddr_in serv_addr;

		vector<string> tosend;
		tosend.push_back("HELO localhost\r\n");
		string mailfrom = "MAIL FROM:<" + username + "@penncloud.com>\r\n";
		//tosend.push_back("MAIL FROM:<xinlongztest@penncloud.local>\r\n");
		tosend.push_back(mailfrom);
		string rcptto = "RCPT TO:<" + rcpt + ">\r\n";
//		tosend.push_back("RCPT TO:<xinlongz@seas.upenn.edu>\r\n");
		tosend.push_back(rcptto);
//		tosend.push_back("RCPT TO:<shaozhe@seas.upenn.edu>\r\n");

		tosend.push_back("DATA\r\n");
		string content = "";
		content += "From: " + username + " <" + username +  "@penncloud.com>\r\n";
		content += "To: " + rcpt_name +  "<" + rcpt +  ">\r\n";
		time_t raw_time = time(NULL);
		string email_time(ctime(&raw_time));
		//content += "Date: Tue, 15 Dec 2020 00:41:25 -0500\r\n";
		content += "Date: " + email_time + " -0500\r\n";
		//content += "Subject: test lol! \r\n";
		content += "Subject: " + mailSubject + "\r\n";
		content += "\r\n";
		//content += "test it content \r\n";
		content += mailContent + "\r\n";
		content += ".\r\n";

		tosend.push_back(content);
		tosend.push_back("QUIT\r\n");
		cout << "set tosend -------" << endl;
		char buffer[1024] = {0};
		if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
			printf("\n Socket creation error \n");
			return -1;
		}

		serv_addr.sin_family = AF_INET;
		if(rcpt_domain == "penncloud.com"){
			serv_addr.sin_port = htons(2500);
		}else{
			serv_addr.sin_port = htons(25);
		}

		string domain_ip;
		//string domain_ip = domain_to_ip[rcpt_domain];
		if(rcpt_domain == "penncloud.com"){
			domain_ip = "127.0.0.1";
		}else{
			domain_ip = Domain2IP(rcpt_domain);
			cout << domain_ip << endl;
		}
		cout << "ip address ----------------" << endl;
		cout << domain_ip << endl;
		// Convert IPv4 and IPv6 addresses from text to binary form
		if(inet_pton(AF_INET, &domain_ip[0], &serv_addr.sin_addr)<=0)
		{
			printf("\nInvalid address/ Address not supported \n");
			return -1;
		}
		cout << "connect to server -------" << endl;
		if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
		{
			printf("\nConnection Failed \n");
			return -1;
		}
		cout << "sending msg -------" << endl;
		for(int i = 0; i < tosend.size(); i++){
			string msg = tosend[i];
			char * msg_ptr = &msg[0];
			send(sock , msg_ptr , strlen(msg_ptr) , 0 );
			cout << msg << endl;
			valread = read( sock , buffer, 1024);

			if(buffer[0] == '2' || buffer[0] == '3'){
				printf("%s\n",buffer );
			}else{
				cerr << "wrong response captured" << endl;
				cout << buffer << endl;
				return -1;
			}
		}
	}
	return 0;
}

int HttpServer::HandleCookie(){
	char * request_addr = &request[0];
	char * pch = strstr(request_addr,"Cookie:");
	if( pch == NULL){
		islogin = false;
	}else{
		pch += strlen("Cookie: ");
		char* cookie_tail = strstr(pch,"\r\n");
		string cookie_tmp = request.substr(pch-request_addr,cookie_tail-pch);
		char* name_tail = strstr(pch,"=");
		string username_tmp = request.substr(pch-request_addr,name_tail-pch);

		// \checkCookie cookie
		string send_BE = "checkCookie " + username_tmp + " " + cookie_tmp;
		string BE_response = sendMsg(username_tmp,send_BE);
		//string BE_response = "-400 ERR";

		char* BE_response_ptr = &BE_response[0];
		if(strncmp(BE_response_ptr,"+200 OK",7)==0){
			islogin = true;
			cookie = cookie_tmp;
			username = username_tmp;
			cout << "successfully Checkcookie------------" << endl;
			cout << cookie << endl;
			cout << username << endl;
		}else if(strncmp(BE_response_ptr,"-400 ERR",8)==0){
			islogin = false;
			cerr << "Clean Up Invalid Cookie" << endl;
		}
	}

	return 0;
}
int HttpServer::HandleRequest(char* read_buffer){
	string buffer_str(read_buffer);
	this->request = buffer_str;
	HandleCookie();
	if(strncmp(&request[0],"GET",3) == 0){
		HandleGet();
	}else if(strncmp(&request[0],"POST",4) == 0){
		HandlePost();
	}
	return 0;
}
int HttpServer::renderFile(string file_loc,string file_type){
    ifstream content(&file_loc[0]);
    stringstream html_content;
    string line;
    while(getline(content,line)){
         html_content<<line << "\n";
     }
    string conten_string = html_content.str();
    string tosend = "";
    if (file_type == "html"){
    	tosend += "HTTP/1.1 200 OK\r\n";
    	tosend += "Content-type: text/html\r\n";
    	tosend += "Content-length: "+ to_string(conten_string.length())+"\r\n";
    	tosend += "\r\n";// + "Set-Cookie: sid=123\r\n\r\n";
    }else if(file_type == "css"){
		tosend += "HTTP/1.1 200 OK\r\n";
		tosend += "Content-type: text/css\r\n";
		tosend += "Content-length: "+ to_string(conten_string.length())+"\r\n";
		tosend += "\r\n";// + "Set-Cookie: sid=deleted; expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n\r\n";
	}

    tosend += conten_string;

    sock_write(sock,&tosend[0]);
    return 0;

}
int HttpServer::renderInbox(){
	if(islogin){
		char* request_ptr = &request[0];
		char* cmd_ptr = strstr(request_ptr,"/mailInbox/") + strlen("/mailInbox/");
		char* cmd_tail = strstr(cmd_ptr," ");
		string cmd_key = request.substr(cmd_ptr-request_ptr,cmd_tail-cmd_ptr);
		string header = urlDecode(cmd_key);
		// \mailFetch username<CRLF>header
		string send_BE = "mailFetch " + username + "\r\n" + header + "\n";
		cout <<"send -------------" << endl;
		cout << send_BE << endl;
		string BE_response = sendMsg(username,send_BE);
		cout << BE_response << endl;
		char* BE_ptr = &BE_response[0];
		char* content_ptr = strstr(BE_ptr,"\r\n") + strlen("\r\n");
		string content(content_ptr);
		stringstream sendstream;

		sendstream << "<!DOCTYPE html>\n";
		sendstream << "<html lang=\"en\">\n";
		sendstream << "    <head>\n";
		sendstream << "        <meta charset=\"UTF-8\">\n";
		sendstream << "        <title>PennCloud Mail</title>\n";

		sendstream << "    </head>\n";

		sendstream << "    <body>\n";
		sendstream << "    	<h1 class = \"head-box\">" << username <<"'s PENN MAIL!</h1>\n";
		sendstream << "		<p>" <<  content << "<p>\n";

		sendstream << "        <form action=\"/mailReply\" method= \"POST\">\n";
		sendstream << "           <label> Subject :</label>\n";
		sendstream << "           <input type=\"text\" name=\"subject\" placeholder=\"subject\">\n";
		sendstream << "           <label> Content :</label>\n";
		sendstream << "           <input type=\"text\" name=\"content\" placeholder=\"content\">\n";
		sendstream << "           <input type=\"submit\" class=\"ok\" value=\"Reply\">\n";
		sendstream << "       </form>\n";

		sendstream << "      <form action=\"/mailForward\" method= \"POST\">\n";
		sendstream << "          <label> Reception:</label>\n";
		sendstream << "          <input type=\"text\" name=\"reception1\" placeholder=\"reception1\">\n";
		sendstream << "          <input type=\"text\" name=\"reception2\" placeholder=\"reception2\">\n";
		sendstream << "    		 <input type=\"text\" name=\"reception3\" placeholder=\"reception3\">\n";
		sendstream << "          <input type=\"submit\" class=\"ok\" value=\"Forward\">\n";
		sendstream << "      </form>\n";

		sendstream << "      <form action=\"/mailDelete\" method= \"POST\">\n";
		sendstream << "          <input type=\"submit\" class=\"ok\" value=\"Delete This Mail\">\n";
		sendstream << "      </form>\n";

		sendstream << " 	<a href=\"/home\">Home</a>\n";
		sendstream << "  	<a href=\"/mail\">Inbox</a>\n";
		sendstream << "  </body>\n";
		sendstream << "</html>\n";
	    string sendstr = sendstream.str();
	    string tosend = "";
	    tosend += "HTTP/1.1 200 OK\r\n";
	    tosend += "Content-type: text/html\r\n";
	    tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
	    tosend += "\r\n";
	    tosend += sendstr;
	    sock_write(sock,&tosend[0]);

	}else{
		renderFile("assets/login.html","html");
	}
	return 0;
}

int HttpServer::renderHome(){
	if(islogin){
		stringstream sendstream;
		sendstream << "<!DOCTYPE html>\n";
		sendstream << "	    <html lang=\"en\">\n";
		sendstream << "	        <head>\n";
		sendstream << "	            <meta charset=\"UTF-8\">\n";
		sendstream << "	            <title>PennCloud Home</title>\n";
		sendstream << "	            <link rel=\"stylesheet\" href=\"index.css\">\n";
		sendstream << "	        </head>\n";
		sendstream << "	        <body>\n";
		sendstream << "	            <h1 class = \"head-box\">"<< "Hi " << username <<" Welcome to PennCloud!</h1>\n";
		sendstream << "	            <div class=\"flex-box\">\n";
		sendstream << "	                <div class = \"text-box\" id = \"t1\">    \n";
		sendstream << "	                    <a href=\"/register\">Register/Change Password</a>\n";
		sendstream << "	                </div>\n";
		sendstream << "	                <div class = \"text-box\" id = \"t2\">\n";
		sendstream << "	                    <a href=\"/login\">Login</a>\n";
		sendstream << "	                </div>\n";
		sendstream << "	                <div class = \"text-box\" id = \"t3\">\n";
		sendstream << "	                    <a href=\"/drive\">PennDrive</a>\n";
		sendstream << "	                </div>\n";
		sendstream << "	                <div class = \"text-box\" id = \"t3\">\n";
		sendstream << "	                    <a href=\"/mail\">PennMail</a>\n";
		sendstream << "	                </div>\n";
		sendstream << "	                <div class = \"text-box\" id = \"t3\">\n";
		sendstream << "	                    <a href=\"/logout\">Logout</a>\n";
		sendstream << "	                </div>\n";
		sendstream << "	            </div>\n";
		sendstream << "	        </body>\n";
		sendstream << "	    </html>\n";

	    string sendstr = sendstream.str();
	    string tosend = "";
	    tosend += "HTTP/1.1 200 OK\r\n";
	    tosend += "Content-type: text/html\r\n";
	    tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
	    tosend += "\r\n";
	    tosend += sendstr;
	    sock_write(sock,&tosend[0]);
	}else{
		renderFile("assets/home.html","html");
	}
	return 0;
}
int HttpServer::renderLogin(){
	if(islogin){
		stringstream sendstream;
		sendstream << "<!DOCTYPE html>\n";
		sendstream << "<html lang=\"en\">\n";
		sendstream << "		    <head>\n";
		sendstream << "		        <meta charset=\"UTF-8\">\n";
		sendstream << "		        <title>Login</title>\n";
		sendstream << "		        <link rel=\"stylesheet\" href=\"index.css\">\n";
		sendstream << "		    </head>\n";
		sendstream << "		    <body>\n";
		sendstream << "		    	<p>You already Login as: "<< username << " , please logout</p>\n";
		sendstream << "		        <a href=\"/logout\">Logout</a>\n";
		sendstream << "		        <a href=\"/home\">home</a>\n";
		sendstream << "		    </body>\n";
		sendstream << "		</html>\n";

	    string sendstr = sendstream.str();
	    string tosend = "";
	    tosend += "HTTP/1.1 200 OK\r\n";
	    tosend += "Content-type: text/html\r\n";
	    tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
	    tosend += "\r\n";
	    tosend += sendstr;
	    sock_write(sock,&tosend[0]);
	}else{
		renderFile("assets/login.html","html");
	}
	return 0;
}
int HttpServer::renderRegister(){
	renderFile("assets/register.html","html");
	return 0;
}
int HttpServer::renderDrive(){
	string BE_response;
	if(islogin){
		// \driveOpen username "/"
		string send_BE;
		if(driveAddr=="/"){
			send_BE = "driveOpen " + username + " /";
			cout << "driveOpen / " << send_BE << endl;
			string BE_open = sendMsg(username,send_BE);
			cout << "open / : " << BE_open << endl;
			if(strncmp(&BE_open[0],"-400 ERR",8)==0){
				send_BE = "driveCreate "+ username + " /";
				string BE_create = sendMsg(username,send_BE);
				cout << "create / :" << BE_create << endl;
				if(strncmp(&BE_create[0],"-400 ERR",8)==0){
					renderFile("assets/fail_driveCreate.html","html");
				}else{
					renderDrive();
				}
			}else if(strncmp(&BE_open[0],"+200 OK",7)==0){
				BE_response = BE_open;
			}
		}else{
			send_BE = "driveOpen " + username + " "+ driveAddr;
			cout << "drive open : " <<  send_BE << endl;
			string BE_open = sendMsg(username,send_BE);
			BE_response = BE_open;
		}
		cout << "render drive -----------" << endl;
		cout << BE_response << endl;
		// string BE_response = "-400 ERR";
		char* BE_ptr = &BE_response[0];
		if(strncmp(BE_ptr,"+200 OK",7)==0){
			char * file_list_ptr = BE_ptr + strlen("+200 OK ");
			vector<string> file_list;
			vector<string> folder_list;
			int flag; // 0 : file, 1: folder
			char* tmp_ptr1 =  strtok(file_list_ptr," =");
			if(strcmp(tmp_ptr1,"file")== 0){
				flag = 0;
			}else if(strcmp(tmp_ptr1,"folder")== 0){
				flag = 1;
			}
			char* tmp = strtok(NULL, " =");
			int count = 1;
			while(tmp != NULL){
				string tmp_str(tmp);
				if (count%2==0){
					if(strcmp(tmp,"file")== 0){
						flag = 0;
					}else if(strcmp(tmp,"folder")== 0){
						flag = 1;
					}
				}else{
					if(flag == 0){
						file_list.push_back(tmp_str);
					}else if(flag == 1){
						folder_list.push_back(tmp_str);
					}
				}
				count++;
				tmp = strtok(NULL, " =");
			}

			string display_addr = driveAddr.substr(0,driveAddr.length());
			char* display_ptr = &display_addr[0];
			char* tmp_pt;
			while(tmp_pt = strstr(display_ptr,"/")){
				display_addr.replace(tmp_pt-display_ptr,1," ");
			}
			cout << display_addr << endl;


			stringstream sendstream;
			sendstream << "<!DOCTYPE html>\n";
			sendstream << "			<html lang=\"en\">\n";
			sendstream << "			    <head>\n";
			sendstream << "			        <meta charset=\"UTF-8\">\n";
			sendstream << "			        <title>PennCloud Drive</title>\n";
			sendstream << "			        <link rel=\"stylesheet\" href=\"index.css\">\n";
			sendstream << "			    </head>\n";
			sendstream << "			    <body>\n";
			sendstream << "			    	<h1 class = \"head-box\">" << username<< "'s PENN DRIVE!</h1>\n";
			sendstream << "	                <p>We are current at: "<< display_addr<< "</p>";
			sendstream << "			    	<a href=\"/home\">Home</a>\n";
			sendstream << "			        <form action=\"/driveOpen\" method= \"POST\">\n";
			sendstream << "			            <input type=\"text\" name=\"folderAddr\" placeholder=\"folderAddr\">\n";
			sendstream << "			            <input type=\"submit\" class=\"ok\" value=\"OPEN\">\n";
			sendstream << "			        </form>\n";
			sendstream << "					<form action=\"/driveCreate\" method= \"POST\">\n";
			sendstream << "			            <input type=\"text\" name=\"folderName\" placeholder=\"folderName\">\n";
			sendstream << "			            <input type=\"submit\" class=\"ok\" value=\"Create\">\n";
			sendstream << "			        </form>\n";
			sendstream << "			        <form action=\"/driveDelete\" method= \"POST\">\n";
			sendstream << "			            <input type=\"text\" name=\"folderName\" placeholder=\"folderName\">\n";
			sendstream << "			            <input type=\"submit\" class=\"ok\" value=\"Delete\">\n";
			sendstream << "			        </form>\n";
			sendstream << "			        <form action=\"/driveRename\" method= \"POST\">\n";
			sendstream << "			            <input type=\"text\" name=\"oldName\" placeholder=\"Old Name\">\n";
			sendstream << "			            <input type=\"text\" name=\"newName\" placeholder=\"New Name\">\n";
			sendstream << "			            <input type=\"submit\" class=\"ok\" value=\"Rename\">\n";
			sendstream << "			        </form>\n";
			sendstream << "			        <form action=\"/driveMove\" method= \"POST\">\n";
			sendstream << "			            <input type=\"text\" name=\"oldAddr\" placeholder=\"Old Addr\">\n";
			sendstream << "			            <input type=\"text\" name=\"newAddr\" placeholder=\"New Addr\">\n";
			sendstream << "			            <input type=\"submit\" class=\"ok\" value=\"Move\">\n";
			sendstream << "			        </form>\n";
			sendstream << "			        <form action=\"/driveUpload\" method=\"POST\" enctype=\"multipart/form-data\">\n";
			sendstream << "				    <input type=\"text\" name=\"fileAddr\" placeholder=\"fileAddr\">\n";
			sendstream << "				    <input type=\"file\" name=\"uploadFile\" >\n";
			sendstream << "			            <input type=\"submit\" class=\"ok\" value=\"Upload\">\n";
			sendstream << "				</form>\n";
			for(int i = 0; i < folder_list.size(); i++){
				sendstream << "				<p>" <<  folder_list[i] << "</p>\n";
			}
			for(int i = 0; i < file_list.size();i++){
				if(driveAddr=="/"){
					sendstream << "				<a href=/download" << driveAddr  <<file_list[i] <<" download>" << file_list[i]<<"</a>\n";
				}else{
					sendstream << "				<a href=/download/" << driveAddr <<"/" <<file_list[i] <<" download>" << file_list[i]<<"</a>\n";
				}
			}
			sendstream << "			    </body>\n";
			sendstream << "			</html>\n";

		    string sendstr = sendstream.str();
		    string tosend = "";
		    tosend += "HTTP/1.1 200 OK\r\n";
		    tosend += "Content-type: text/html\r\n";
		    tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
		    tosend += "\r\n";
		    tosend += sendstr;
		    sock_write(sock,&tosend[0]);

		}else if(strncmp(BE_ptr,"-400 ERR",8)==0){
			renderFile("assets/fail_driveOpen.html","html");
		}

		cout << "drive" << endl;
	}else{
		renderFile("assets/login.html","html");
	}
	return 0;
}
int HttpServer::renderMail(){
	if(islogin){
		// \mailInbox username
		string send_BE = "mailInbox " + username;

		string BE_response = sendMsg(username,send_BE);
		cout << BE_response << endl;
		char* BE_ptr = &BE_response[0];
		char* tmp;
		tmp = strtok(BE_ptr,"\r\n");
		vector<string> headers;
		while((tmp = strtok(NULL,"\r\n")) != NULL){
			string tmp_str(tmp);
			headers.push_back(tmp_str);
		}

		stringstream sendstream;
		sendstream << "			<!DOCTYPE html>\n";
				sendstream << "			<html lang=\"en\">\n";
				sendstream << "			    <head>\n";
				sendstream << "			        <meta charset=\"UTF-8\">\n";
				sendstream << "			        <title>PennCloud Mail</title>\n";
				sendstream << "			        <link rel=\"stylesheet\" href=\"index.css\">\n";
				sendstream << "			    </head>\n";
				sendstream << "			    <body>\n";
				sendstream << "			    	<h1 class = \"head-box\">" << username << "'s PENN MAIL!</h1>\n";
				sendstream << "			    	<a href=\"/home\">Home</a>\n";
				sendstream << "			        <form action=\"/mailNewmsg\" method= \"POST\">\n";
				sendstream << "			            <label> Subject :</label>\n";
				sendstream << "			            <input type=\"text\" name=\"subject\" placeholder=\"subject\">\n";
				sendstream << "			            <label> Reception:</label>\n";
				sendstream << "			            <input type=\"text\" name=\"reception1\" placeholder=\"reception1\">\n";
				sendstream << "			            <input type=\"text\" name=\"reception2\" placeholder=\"reception2\">\n";
				sendstream << "				        <input type=\"text\" name=\"reception3\" placeholder=\"reception3\">\n";
				sendstream << "			             <label> Content :</label>\n";
				sendstream << "			            <input type=\"text\" name=\"content\" placeholder=\"content\">\n";
				sendstream << "			            <input type=\"submit\" class=\"ok\" value=\"Send Mail\">\n";
				sendstream << "			        </form>\n";
				sendstream << "			        <ul>\n";
				for(int i= 0; i <  headers.size(); i++){
					string head = headers[i];
					sendstream << "			<li>	<a href=\"/mailInbox/"<< head << "\">" << head<<"</a> </li>\n";
				}
				sendstream << "			        </ul>\n";
				sendstream << "			    </body>\n";
				sendstream << "			</html>\n";

			    string sendstr = sendstream.str();
			    string tosend = "";
			    tosend += "HTTP/1.1 200 OK\r\n";
			    tosend += "Content-type: text/html\r\n";
			    tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
			    tosend += "\r\n";
			    tosend += sendstr;
			    sock_write(sock,&tosend[0]);


	}else{
		renderFile("assets/login.html","html");
	}
	return 0;
}

string HttpServer::generateRandomStr(const int len){
    string res = "";
    char data[] =
        "0123456789"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz";
    srand( (unsigned) time(NULL) * getpid());

    for (int i = 0; i < len; ++i)
        res += data[rand() % (sizeof(data) - 1)];
    return res;
};

string HttpServer::urlDecode(string &SRC) {
    string ret;
    char ch;
    int i, ii;
    for (i=0; i<SRC.length(); i++) {
    	if(SRC[i] == '+'){
    		ret+=" ";
    		continue;
    	}
        if (int(SRC[i])==37) {
            sscanf(SRC.substr(i+1,2).c_str(), "%x", &ii);
            ch=static_cast<char>(ii);
            ret+=ch;
            i=i+2;
        } else {
            ret+=SRC[i];
        }
    }
    return (ret);
}

int HttpServer::HandleDownload(){
	char* request_ptr = &request[0];
	char* file_addr_ptr = strstr(request_ptr,"/download/") + strlen("/download/");
	char* file_addr_tail = strstr(file_addr_ptr," ");
	string file_str = request.substr(file_addr_ptr-request_ptr,file_addr_tail-file_addr_ptr);
	// \driveDownload username fileAddr
	cout << file_str << endl;
	string send_BE = "driveDownload " + username + " " + file_str;
	string BE_respond = sendMsg(username,send_BE);
	char* BE_ptr = &BE_respond[0];
	cout << BE_respond << endl;
	if(strncmp(BE_ptr,"+200 OK",7)==0){
		char* cont = strstr(BE_ptr,"+200 OK ") + strlen("+200 OK ");
		char* content_end = strstr(cont," ") + strlen(" ");
		string sendstr(content_end);
		string tosend = "";
		tosend += "HTTP/1.1 200 OK\r\n";
		tosend += "Content-type: text/html\r\n";
		tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
		tosend += "\r\n";
		tosend += sendstr;
		sock_write(sock,&tosend[0]);
	}else if(strncmp(BE_ptr,"-400 ERR",8)==0){
		renderFile("assets/fail_Download.html","html");
	}




	return 0;
}

int HttpServer::renderLogout(){
	if(islogin){
	    char* request_ptr = &request[0];
	    char* cookie_get = strstr(request_ptr , "Cookie: ") + strlen("Cookie: ");
	    char* cookie_tail = strstr(cookie_get," ");
	    string cookie_str = request.substr(cookie_get-request_ptr,cookie_tail-cookie_get);
	    // \deleteCookie cookie
	    string send_BE = "deleteCookie " + username + " " + cookie_str;
	    cout << "send to be--------------" << endl;
	    cout << send_BE << endl;
	    string BE_response = sendMsg(username,send_BE);
	    cout << "get from BE --------------" << endl;
	    cout << BE_response << endl;
	    //string BE_response = "+200 OK";
	    char * BE_ptr = &BE_response[0];

	    if(strncmp(BE_ptr,"+200 OK",7)==0){
			stringstream sendstream;
			sendstream << "<!DOCTYPE html>\n";
			sendstream << "<html lang=\"en\">\n";
			sendstream << "		    <head>\n";
			sendstream << "		        <meta charset=\"UTF-8\">\n";
			sendstream << "		        <title>Logout</title>\n";
			sendstream << "		        <link rel=\"stylesheet\" href=\"index.css\">\n";
			sendstream << "		    </head>\n";
			sendstream << "		    <body>\n";
			sendstream << "		    	<p>Successfully Logout!</p>\n";
			sendstream << "		        <a href=\"/home\">Home</a>\n";
			sendstream << "		    </body>\n";
			sendstream << "		</html>\n";

		    string sendstr = sendstream.str();
		    string tosend = "";
		    tosend += "HTTP/1.1 200 OK\r\n";
		    tosend += "Content-type: text/html\r\n";
		    tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
		    tosend += "Set-Cookie: " + username + "=deleted; expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n";
		    tosend += "\r\n";
		    tosend += sendstr;
		    sock_write(sock,&tosend[0]);
	    }else if(strncmp(BE_ptr,"-400 ERR",8)==0){
	    	renderFile("assets/fail_logout.html","html");
	    }



	}else{
		stringstream sendstream;
		sendstream << "<!DOCTYPE html>\n";
		sendstream << "<html lang=\"en\">\n";
		sendstream << "		    <head>\n";
		sendstream << "		        <meta charset=\"UTF-8\">\n";
		sendstream << "		        <title>Logout</title>\n";
		sendstream << "		        <link rel=\"stylesheet\" href=\"index.css\">\n";
		sendstream << "		    </head>\n";
		sendstream << "		    <body>\n";
		sendstream << "		    	<p>You have not loged in yet!</p>\n";
		sendstream << "		        <a href=\"/home\">Home</a>\n";
		sendstream << "		    </body>\n";
		sendstream << "		</html>\n";

	    string sendstr = sendstream.str();
	    string tosend = "";
	    tosend += "HTTP/1.1 200 OK\r\n";
	    tosend += "Content-type: text/html\r\n";
	    tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
	    tosend += "\r\n";
	    tosend += sendstr;
	    sock_write(sock,&tosend[0]);
	}
	return 0;
}

int HttpServer::HandleGet(){
	char* temp_str = &request[0];
	char* cmd_tail = strstr(temp_str," ");
	cmd_tail += 1;
	char* file_tail = strstr(cmd_tail," ");
	string file_name = request.substr(cmd_tail-temp_str,file_tail-cmd_tail);

	char* file_prefix = strtok(&file_name[0],".");
	char* file_suffix = strtok(NULL,".");
	cout << file_name << endl;
	cout << strncmp(&file_name[0],"/download",9) << endl;
	string file_loc;
	string file_type;
	if(strncmp(&file_name[0],"/download",9) == 0){
		cout << file_name << endl;
		HandleDownload();
	}else if(strncmp(&file_name[0],"/mailInbox",strlen("/mailInbox")) == 0){
		renderInbox();
	}else{
		if (file_suffix == NULL){
			if(strcmp(file_prefix,"/home") == 0){
				renderHome();
			}else if(strcmp(file_prefix,"/login") == 0){
				renderLogin();
			}else if(strcmp(file_prefix,"/register") == 0){
				renderRegister();
			}else if(strcmp(file_prefix,"/drive") == 0){
				driveAddr = "/";
				renderDrive();
			}else if(strcmp(file_prefix,"/mail") == 0){
				cout << "mail right?" << endl;
				renderMail();
			}else if(strcmp(file_prefix,"/logout") == 0){
				renderLogout();
			}
		}else if(strcmp(file_suffix,"css")==0){
			file_loc = string("assets") + file_prefix + ".css";
			file_type = "css";
			renderFile(file_loc,file_type);
		}
	}
	return 0;
}
int HttpServer::postdriveOpen(){
	char* request_ptr = &request[0];
	char* pch = strstr(request_ptr,"\r\n\r\n") + strlen("\r\n\r\n");
	char* tmp = strstr(pch,"=")+1;
	string tmp_str(tmp);
	string folderAddr = urlDecode(tmp_str);

	driveAddr = folderAddr;

	renderDrive();

	return 0;
}
int HttpServer::postdriveCreate(){
	char* request_ptr = &request[0];
	char* pch = strstr(request_ptr,"\r\n\r\n") + strlen("\r\n\r\n");
	char* tmp = strstr(pch,"=")+1;
	string tmp_str(tmp);
	string folderAddr = urlDecode(tmp_str);
	// \driveCreate username folderAddr
	string send_BE = "driveCreate " + username +  " " + folderAddr;
	cout << "drivecreate send to BE---------" << endl;
	cout << send_BE << endl;
	string BE_response = sendMsg(username,send_BE);

	cout << "drivecreate from BE---------" << endl;
	cout << BE_response << endl;

	char* BE_ptr = &BE_response[0];
	if(strncmp(BE_ptr,"+200 OK",7)==0){
		renderFile("assets/success_driveCreate.html","html");
	}else if(strncmp(BE_ptr,"-400 ERR",8)==0){
		renderFile("assets/fail_driveCreate.html","html");
	}
	return 0;
}

int HttpServer::postdriveDelete(){
	char* request_ptr = &request[0];
	char* pch = strstr(request_ptr,"\r\n\r\n") + strlen("\r\n\r\n");
	char* tmp = strstr(pch,"=")+1;
	string tmp_str(tmp);
	string folderAddr = urlDecode(tmp_str);

	string send_BE = "driveDelete " + username + " " + folderAddr;
	string BE_response = sendMsg(username,send_BE);
	// \driveDelete username folderAddr
	char* BE_ptr = &BE_response[0];
	if(strncmp(BE_ptr,"+200 OK",7)==0){
		renderFile("assets/success_driveDelete.html","html");
	}else if(strncmp(BE_ptr,"-400 ERR",8)==0){
		renderFile("assets/fail_driveDelete.html","html");
	}

	return 0;
}

int HttpServer::postdriveRename(){
	char* request_ptr = &request[0];
	char* pch = strstr(request_ptr,"\r\n\r\n") + strlen("\r\n\r\n");
	char* tmp1 = strstr(pch,"=")+1;
	char* tmp2 = strstr(tmp1,"&");
	char* tmp3 = strstr(tmp2,"=")+1;
	string newAddr_tmp(tmp3);
	string newAddr = urlDecode(newAddr_tmp);
	string oldAddr_tmp = request.substr(tmp1-request_ptr,tmp2-tmp1);
	string oldAddr = urlDecode(oldAddr_tmp);
	string send_BE = "driveRename " + username + " " + oldAddr + " " + newAddr;
	string BE_response = sendMsg(username,send_BE);
	//\driveRename username oldAddr newAddr
	char* BE_ptr = &BE_response[0];
	if(strncmp(BE_ptr,"+200 OK",7)==0){
		renderFile("assets/success_driveRename.html","html");
	}else if(strncmp(BE_ptr,"-400 ERR",8)==0){
		renderFile("assets/fail_driveRename.html","html");
	}
	return 0;
}

int HttpServer::postdriveMove(){
	char* request_ptr = &request[0];
	char* pch = strstr(request_ptr,"\r\n\r\n") + strlen("\r\n\r\n");
	char* tmp1 = strstr(pch,"=")+1;
	char* tmp2 = strstr(tmp1,"&");
	char* tmp3 = strstr(tmp2,"=")+1;
	string newAddr_tmp(tmp3);
	string newAddr = urlDecode(newAddr_tmp);
	string oldAddr_tmp = request.substr(tmp1-request_ptr,tmp2-tmp1);
	string oldAddr = urlDecode(oldAddr_tmp);
	// \driveRename username oldAddr newAddr
	string send_BE = "driveMove " + username + " " + oldAddr + " " + newAddr;
	string BE_response = sendMsg(username,send_BE);
	char* BE_ptr = &BE_response[0];
	if(strncmp(BE_ptr,"+200 OK",7)==0){
		renderFile("assets/success_driveMove.html","html");
	}else if(strncmp(BE_ptr,"-400 ERR",8)==0){
		renderFile("assets/fail_driveMove.html","html");
	}
	return 0;
}

int HttpServer::postdriveUpload(){
	char* request_ptr = &request[0];
	char* tmpptr1 = strstr(request_ptr,"boundary=")+strlen("boundary=");
	char* tmpptr2 = strstr(tmpptr1,"\r\nContent-Length:");
	string boundary_str = "--" + request.substr(tmpptr1-request_ptr,tmpptr2-tmpptr1);
	char* boundary = &boundary_str[0];
	cout << boundary << endl;
	char* tmpptr3 = strstr(tmpptr2,boundary)+strlen(boundary)+strlen("\r\n");
	char* tmpptr4 = strstr(tmpptr3,boundary)-strlen("\r\n");
	string addrInfo = request.substr(tmpptr3-request_ptr,tmpptr4-tmpptr3);
	char* tmpptr5 = tmpptr4 + strlen(boundary)+2*strlen("\r\n");
	char* tmpptr6 = strstr(tmpptr5,boundary)-strlen("\r\n");
	string file_content = request.substr(tmpptr5-request_ptr,tmpptr6-tmpptr5);

	char* fileAddr = strstr(&addrInfo[0],"\r\n\r\n") + strlen("\r\n\r\n");
	char* fileupload = strstr(&file_content[0],"\r\n\r\n") + strlen("\r\n\r\n");
	string Addr(fileAddr);
	string FileLoad(fileupload);
	// \driveUpload username fileAddr strlen(fileupload) fileupload
	string BE_send = "driveUpload " + username + " " + Addr + " " + to_string(FileLoad.length()) + " " + FileLoad;
	string BE_respond = sendMsg(username,BE_send);
	char* BE_ptr = &BE_respond[0];
	if(strncmp(BE_ptr,"+200 OK",7)==0){
		renderFile("assets/success_Upload.html","html");
	}else if(strncmp(BE_ptr,"-400 ERR",8)==0){
		renderFile("assets/fail_Upload.html","html");
	}

	return 0;
}
int HttpServer::postmailDelete(){
	if(islogin){
		char* request_ptr = &request[0];
		char* refer_ptr = strstr(request_ptr,"Referer: ") + strlen("Referer: ");
		char* refer_tail = strstr(refer_ptr,"\r\n");
		string refer_str = request.substr(refer_ptr-request_ptr,refer_tail-refer_ptr);
		string refer_decode = urlDecode(refer_str);
		char* refer_decode_ptr = &refer_decode[0];
		cout << "referer ------------" << endl;
		cout << refer_decode << endl;
		char* head_get = strstr(refer_decode_ptr,"/mailInbox/") + strlen("/mailInbox/");
		string head(head_get);
		head += "\n";
		string send_BE = "mailDelete " + username + "\r\n" + head;
		string BE_responde = sendMsg(username,send_BE);
		char* BE_ptr = &BE_responde[0];
		if(strncmp(BE_ptr,"+200 OK",7)==0){
			renderMail();
		}else{
			renderFile("assets/fail_mailDelete.html","html");
		}
	}else{
		renderLogin();
	}
	return 0;
}

int HttpServer::postmailNewmsg(){
	char* request_ptr = &request[0];
	char* mail_get = strstr(request_ptr,"\r\n\r\n") + strlen("\r\n\r\n");
	string mail_get_str(mail_get);
	string mail_cont = urlDecode(mail_get_str);
	cout << mail_cont << endl;
	cout << "start here -------" << endl;
	char* tmp_ptr = &mail_cont[0];
	char* sub_ptr = strstr(tmp_ptr,"subject=") + strlen("subject=");
	char* sub_tail = strstr(sub_ptr,"&");
	cout << tmp_ptr << endl;
	cout << sub_ptr << endl;
	cout << sub_tail << endl;
	if(sub_ptr != sub_tail){
		mailSubject = mail_cont.substr(sub_ptr-tmp_ptr,sub_tail-sub_ptr);
		cout << mailSubject << endl;
	}
	cout << "get subject -------" << endl;
	char* rcpt1_ptr = strstr(tmp_ptr,"reception1=") + strlen("reception1=");
	char* rcpt1_tail = strstr(rcpt1_ptr,"&");
	mailRCPTS.clear();
	if(rcpt1_ptr != rcpt1_tail){
		mailRCPTS.push_back(mail_cont.substr(rcpt1_ptr-tmp_ptr,rcpt1_tail-rcpt1_ptr));
		cout << mail_cont.substr(rcpt1_ptr-tmp_ptr,rcpt1_tail-rcpt1_ptr) << endl;
	}
	char* rcpt2_ptr = strstr(tmp_ptr,"reception2=") + strlen("reception2=");
	char* rcpt2_tail = strstr(rcpt2_ptr,"&");
	if(rcpt2_ptr != rcpt2_tail){
		mailRCPTS.push_back(mail_cont.substr(rcpt2_ptr-tmp_ptr,rcpt2_tail-rcpt2_ptr));
		cout << mail_cont.substr(rcpt2_ptr-tmp_ptr,rcpt2_tail-rcpt2_ptr) << endl;
	}
	char* rcpt3_ptr = strstr(tmp_ptr,"reception3=") + strlen("reception3=");
	char* rcpt3_tail = strstr(rcpt3_ptr,"&");
	if(rcpt3_ptr != rcpt3_tail){
		mailRCPTS.push_back(mail_cont.substr(rcpt3_ptr-tmp_ptr,rcpt3_tail-rcpt3_ptr));
		cout << mail_cont.substr(rcpt3_ptr-tmp_ptr,rcpt3_tail-rcpt3_ptr) << endl;
	}
	cout << "get rcpts -------" << endl;
	char* cont_ptr = strstr(tmp_ptr,"content=") + strlen("content=");
	string cont_str(cont_ptr);
	cout << "get content -------" << endl;
	mailContent = cont_str;
    cout << mailContent << endl;
	mailSender = username + "@penncloud.com";
	int send_res = sendMail();
	if(send_res ==0){
		renderFile("assets/success_mailSend.html","html");
	} else{
		renderFile("assets/fail_mailSend.html","html");
	}
	return 0;
}

int HttpServer::postmailReply(){
	char* request_ptr = &request[0];
	char* refer_ptr = strstr(request_ptr,"Referer: ") + strlen("Referer: ");
	char* refer_tail = strstr(refer_ptr,"\r\n");
	string refer_str = request.substr(refer_ptr-request_ptr,refer_tail-refer_ptr);
	string refer_decode = urlDecode(refer_str);
	cout << "referer ------------" << endl;
	cout << refer_decode << endl;

	char* form_ptr = strstr(request_ptr,"\r\n\r\n") + strlen("\r\n\r\n");
	string form_str(form_ptr);
	string form_decode = urlDecode(form_str);

	cout << "form --------------" << endl;
	cout << form_decode << endl;

	char* refer_tmp = &refer_decode[0];
	char* mail_from = strstr(refer_tmp,"From ") + strlen("From ");
	char* mail_from_tail = strstr(mail_from," ");
	string mail_from_str = refer_decode.substr(mail_from-refer_tmp,mail_from_tail-mail_from);
	cout << "mail from ----------------" << endl;
	cout << mail_from_str << endl;

	mailRCPTS.clear();
	mailRCPTS.push_back(mail_from_str);

	char* form_tmp = &form_decode[0];
	char* subject_ptr = strstr(form_tmp, "subject=") + strlen("subject=");
	char* subject_tail = strstr(subject_ptr,"&");
	string subject = form_decode.substr(subject_ptr-form_tmp,subject_tail-subject_ptr);
	mailSubject = subject;

	char* content_ptr = strstr(form_tmp, "content=") + strlen("content=");
	string content_str(content_ptr);

	mailContent = content_str;

	cout << "mail subject ---------------" << endl;
	cout << mailSubject << endl;
	cout << "mail content ---------------" << endl;
	cout << mailContent << endl;
	int send_res = sendMail();
	if(send_res ==0){
		renderFile("assets/success_mailSend.html","html");
	} else{
		renderFile("assets/fail_mailSend.html","html");
	}

	return 0;

}

int HttpServer::postmailForward(){
	char* request_ptr = &request[0];
	char* refer_ptr = strstr(request_ptr,"Referer: ") + strlen("Referer: ");
	char* refer_tail = strstr(refer_ptr,"\r\n");
	string refer_str = request.substr(refer_ptr-request_ptr,refer_tail-refer_ptr);
	string refer_decode = urlDecode(refer_str);
	char* refer_decode_ptr = &refer_decode[0];
	cout << "referer ------------" << endl;
	cout << refer_decode << endl;
	char* head_get = strstr(refer_decode_ptr,"/mailInbox/") + strlen("/mailInbox/");
	string head(head_get);
	string subject_forward =  "Forward: " + head;

	mailSubject = subject_forward;
	mailContent = "ok this is content";


	char* rcpt_get = strstr(request_ptr,"\r\n\r\n")+strlen("\r\n\r\n");
	string rcpt_str(rcpt_get);
	string rcpt_decode = urlDecode(rcpt_str);
	char* rcpt_ptr = &rcpt_decode[0];
	char* rcpt1_ptr = strstr(rcpt_ptr,"reception1=") + strlen("reception1=");
	char* rcpt1_tail = strstr(rcpt1_ptr,"&");
	string rcpt1 = rcpt_decode.substr(rcpt1_ptr -rcpt_ptr,rcpt1_tail-rcpt1_ptr);
	mailRCPTS.clear();
	if(rcpt1_tail != rcpt1_ptr){
		mailRCPTS.push_back(rcpt1);
	}

	char* rcpt2_ptr = strstr(rcpt_ptr,"reception2=") + strlen("reception2=");
	char* rcpt2_tail = strstr(rcpt2_ptr,"&");
	string rcpt2 = rcpt_decode.substr(rcpt2_ptr -rcpt_ptr,rcpt2_tail-rcpt2_ptr);
	if(rcpt2_tail != rcpt2_ptr){
		mailRCPTS.push_back(rcpt2);
	}

	char* rcpt3_ptr = strstr(rcpt_ptr,"reception3=") + strlen("reception3=");
	string rcpt3(rcpt3_ptr);

	if(rcpt3 != ""){
		mailRCPTS.push_back(rcpt3);
	}

	cout <<" rcpt -----------------------" << endl;
	cout << rcpt1 << endl;
	cout << rcpt2 << endl;
	cout << rcpt3 << endl;
	int send_res = sendMail();
	if(send_res ==0){
		renderFile("assets/success_mailSend.html","html");
	} else{
		renderFile("assets/fail_mailSend.html","html");
	}
	return 0;
}


int HttpServer::postRegister(){
	char* request_ptr = &request[0];
	char* pch = strstr(request_ptr,"\r\n\r\n");
	pch += strlen("\r\n\r\n");
	char* account_ptr = strstr(pch,"=")+1;
	char* inter_ptr = strstr(pch,"&");
	string account = request.substr(account_ptr-request_ptr,inter_ptr-account_ptr);
	char* psw_cont = inter_ptr + 1;
	char* psw_ptr = strstr(psw_cont,"=")+1;
	string psw(psw_ptr);

	// \register username password
	string BE_send = "register " + account + " " +psw;
	cout << "register data to send -----------" << endl;
	cout << BE_send << endl;

	string BF_response = sendMsg(account,BE_send);
	cout << "register BF_response-----------" << endl;
	cout << BF_response << endl;

	char* BF_ptr = &BF_response[0];

	if(strncmp(BF_ptr,"+200 OK",7)==0){
		renderFile("assets/success_register.html","html");
	}else if(strncmp(BF_ptr,"-400 ERR",8)==0){
		renderFile("assets/fail_register.html","html");
	}
    return 0;
}
int HttpServer::postLogin(){
	char* request_ptr = &request[0];
	char* pch = strstr(request_ptr,"\r\n\r\n");
	pch += strlen("\r\n\r\n");
	char* account_ptr = strstr(pch,"=")+1;
	char* inter_ptr = strstr(pch,"&");
	string account = request.substr(account_ptr-request_ptr,inter_ptr-account_ptr);
	char* psw_cont = inter_ptr + 1;
	char* psw_ptr = strstr(psw_cont,"=")+1;
	string psw(psw_ptr);

	// \login username password
	string send_BE = "login " + account + " " + psw;
	cout << "login send to BE-----------" << endl;
	cout << send_BE << endl;
	string BF_response = sendMsg(account, send_BE);
	cout << "login back from BE-------------" << endl;
	cout << BF_response << endl;

	char* BF_ptr = &BF_response[0];

	if(strncmp(BF_ptr,"+200 OK",7)==0){
		string sid = generateRandomStr(17);
		string generated_cookie = account + "=" + sid ;
		// \setCookie cookie
		string send_cookie = "setCookie " + account + " " + generated_cookie;
		cur_cookie = generated_cookie;
		cout << "setcookie send to BE-----------" << endl;
		cout << send_cookie << endl;
		string BF_response_cookie = sendMsg(account,send_cookie);
		cout << "setcookie back from BE-------------" << endl;
		cout << BF_response_cookie << endl;

		char* BF_ptr_cookie = &BF_response_cookie[0];
		if(strncmp(BF_ptr_cookie,"+200 OK",7) == 0){
			stringstream sendstream;
			sendstream << "<!DOCTYPE html>\n";
			sendstream << "<html lang=\"en\">\n";
			sendstream << "		    <head>\n";
			sendstream << "		        <meta charset=\"UTF-8\">\n";
			sendstream << "		        <title>Login</title>\n";
			sendstream << "		        <link rel=\"stylesheet\" href=\"index.css\">\n";
			sendstream << "		    </head>\n";
			sendstream << "		    <body>\n";
			sendstream << "		    	<p>Successfully Login: "<< account << "</p>\n";
			sendstream << "		        <a href=\"/home\">Home</a>\n";
			sendstream << "		    </body>\n";
			sendstream << "		</html>\n";

			string sendstr = sendstream.str();

			string tosend = "";
			tosend += "HTTP/1.1 200 OK\r\n";
			tosend += "Content-type: text/html\r\n";
			tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
			tosend += "Set-Cookie: " + generated_cookie + "\r\n";
			tosend += "\r\n";
			tosend += sendstr;
			sock_write(sock,&tosend[0]);
		}else if(strncmp(BF_ptr_cookie,"-400 ERR",8)==0){
			renderFile("assets/fail_cookie.html","html");
		}
	}else if(strncmp(BF_ptr,"-400 ERR",8) == 0){
		renderFile("assets/fail_login.html","html");
	}

	return 0;
}
int HttpServer::postPSWchange(){
	char* request_ptr = &request[0];
	char* tmp_ptr1 = strstr(request_ptr,"\r\n\r\n");
	tmp_ptr1 += strlen("\r\n\r\n");
	char* tmp_ptr2 = strstr(tmp_ptr1,"=") +1;
	char* tmp_ptr3 = strstr(tmp_ptr1,"&");
	string account = request.substr(tmp_ptr2-request_ptr,tmp_ptr3-tmp_ptr2);

	char* tmp_ptr4 = strstr(tmp_ptr3,"=") +1;
	char* tmp_ptr5 = strstr(tmp_ptr3+1,"&");
	string oldPSW = request.substr(tmp_ptr4-request_ptr,tmp_ptr5- tmp_ptr4);

	char* tmp_ptr6 = strstr(tmp_ptr5,"=") +1;
	string newPSW(tmp_ptr6);

	string send_BE = "changePSW " +account+ " "+oldPSW + " " + newPSW;
	///changePSW username oldPSW newPSW
	string BF_response = sendMsg(account,send_BE);
	//string BF_response = "-400 ERR";
	char* BF_ptr = &BF_response[0];
	if(strncmp(BF_ptr,"+200 OK",7)==0){
		renderFile("assets/success_CPSW.html", "html");
	}else if(strncmp(BF_ptr,"-400 ERR",8)==0){
		renderFile("assets/fail_CPSW.html", "html");
	}

	return 0;
}
int HttpServer::HandlePost(){
	char* tmp_str = &request[0];
	char* cmd_tail = strstr(tmp_str," ");
	cmd_tail += 1;
	char* action_tail = strstr(cmd_tail," ");
	string action = request.substr(cmd_tail-tmp_str,action_tail-cmd_tail);
	char* request_action = &action[0];
	if(strcmp(request_action,"/register") == 0){
		postRegister();
	}else if(strcmp(request_action,"/login") == 0){
		postLogin();
	}else if(strcmp(request_action,"/changePSW") == 0){
		postPSWchange();
	}else if(strcmp(request_action,"/driveOpen") == 0){
		postdriveOpen();
	}else if(strcmp(request_action,"/driveCreate") == 0){
		postdriveCreate();
	}else if(strcmp(request_action,"/driveDelete") == 0){
		postdriveDelete();
	}else if(strcmp(request_action,"/driveRename") == 0){
		postdriveRename();
	}else if(strcmp(request_action,"/driveMove") == 0){
		postdriveMove();
	}else if(strcmp(request_action,"/driveUpload") == 0){
		postdriveUpload();
	}else if(strcmp(request_action,"/mailNewmsg") == 0){
		postmailNewmsg();
	}else if(strcmp(request_action,"/mailReply") == 0){
		postmailReply();
	}else if(strcmp(request_action,"/mailForward") == 0){
		postmailForward();
	}else if(strcmp(request_action,"/mailDelete") == 0){
		postmailDelete();
	}
	cout << "handle post" << endl;
	return 0;
}



