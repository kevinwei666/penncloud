#include "client_server.h"

// handle sigint in main thread
void sig_handler (int signuum ) {
	sig_flag = 1;
	for(auto sock: sock_set){
		cout << sock << endl;
		sock_write(sock,(char *)"-ERR Server shutting down\r\n");
		if(close(sock) < 0){
		    fprintf(stderr,"error close %d socket", sock);
			exit(1);
		}
	}

	for(auto thread: thread_set){
		pthread_cancel(thread);
	}
	exit(0);
}

// thread working
void *thread_handler(void *new_sock)
{

    int sock = *(int *)new_sock;
    char *write_msg;

    //initilize some variables
    char read_buffer[10250];
    char temp_buffer[10250];
    int onetime_read_size;
    int read_count = 0;
    int line_flag = 0;
    int line_length;

//    write_msg = (char*)"220 localhost service ready!\r\n";
//    sock_write(sock,write_msg);

    // read from client
    while( (onetime_read_size = read(sock , &read_buffer[read_count] , sizeof(read_buffer)-1)) > 0)
    {
    	read_buffer[onetime_read_size] = '\0';
    	cout << read_buffer << endl;
    	if(strcmp(read_buffer,"MASTER QUERY/r/n") == 0){
    		int sock_num = sock_set.size();
    		string write_back = to_string(PORT) + ' ' +  to_string(sock_num);
    		sock_write(sock,&write_back[0]);
    	}else{
    		if(strncmp(read_buffer,"POST",4)==0 || strncmp(read_buffer,"PUT",3)==0 || strncmp(read_buffer,"GET",3)==0 || strncmp(read_buffer,"DELETE",6)==0){
    			HttpServer http_handler(sock);
    			http_handler.HandleRequest(read_buffer);

    		}
    	}
    }
    if(onetime_read_size == 0)
    {
    	sock_set.erase(sock);
    	cout << "one thread terminated" << endl;
    	return 0;
    }else{
        fprintf(stderr, "error read (server)\n");
        exit(1);
    }
    cout << "end reached" << endl;
	return 0;

}


int main(int argc , char *argv[])
{
	//get user input, initial port is 10000 (-v(debug mode)  -a(std error)  -p(port) 10000)
	int c;

	while ((c = getopt (argc, argv, "p:av")) != -1)
	switch (c)
	  {
	  case 'a':{
		fprintf(stderr,"Full Name: Xinlong Zheng, SEAS login: xinlongz\n");
		exit(1);
	  }
		break;

	  case 'v':{
		vflag = 1;
	  }
		break;

	  case 'p':{

		  string s = optarg;
		  auto it = s.begin();
		  while (it != s.end() && std::isdigit(*it)) ++it;

		  if(!s.empty() && it == s.end() && atoi(optarg) >= 1){
			  PORT = atoi(optarg);
		  }
		  else{
			fprintf(stderr, "Option -n requires a positive integer argument.\n");
			exit(1);
		  }
	  }
		break;

	  case '?':
		if (optopt == 'p')
		  fprintf (stderr, "Option -%c requires an argument.\n", optopt);
		else if (isprint (optopt))
		  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
		else
		  fprintf (stderr,"Unknown option character `\\x%x'.\n", optopt);
		exit(1);
	  default:
		abort ();
	  }
     // construct sock connection
    if ( signal(SIGINT, sig_handler) == SIG_ERR ) {
        fprintf(stderr, "error capture signal ctrl+c (server)\n");
        exit(1);
    }

    int server_fd , new_sock , addrlen, opt =1;
    struct sockaddr_in server_addr, client_addr;

    if((server_fd = socket(AF_INET , SOCK_STREAM , 0)) == 0){
        fprintf(stderr, "error create socket (server)\n");
        exit(1);
    }

    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    {
        fprintf(stderr, "error setosocketopt (server)\n");
        exit(1);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons( PORT );

    if( bind(server_fd,(struct sockaddr *)&server_addr , sizeof(server_addr)) < 0)
    {
        fprintf(stderr, "error bind (server)\n");
        exit(1);
    }


    if (listen(server_fd, max_connection) < 0)
    {
        fprintf(stderr, "error listen (server)\n");
        exit(1);
    }

    addrlen = sizeof(struct sockaddr_in);
    int thread_idx = 0;

    //waiting for connection and create threads
    while(true)
    {
    	new_sock = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t*)&addrlen);
    	if(new_sock < 0){
            fprintf(stderr, "error accept (server)\n");
            exit(1);
    	}

     // handle sychronization issue
    	if(sig_flag == 1){
    		sock_write(new_sock,(char *)"-ERR Server shutting down\r\n");
    		if(close(new_sock) < 0){
    		    fprintf(stderr,"error close %d server", new_sock);
    			exit(1);
    		}
    	}
    	//create thread and make a record
    	if(sig_flag == 0){
        	cout << '['<< new_sock << ']' << " New connection" << endl;
        	pthread_t thread;
			if( pthread_create(&thread , NULL ,  thread_handler , (void*) &new_sock) < 0)
			{
				fprintf(stderr, "error create thread (server)\n");
				exit(1);
			}
			thread_set.insert(thread);
			sock_set.insert(new_sock);
    	}
    }

    return 0;
}
