/*
 * BackendMaster.cc
 *
 *  Created on: Dec 3, 2020
 *      Author: cis505
 */
#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <stdio.h>
#include <sys/file.h>
#include "BackendMaster.h"
#include <cassert>
#include <unordered_map>
using namespace std;

unordered_map<string, vector<string>> backendMaster ::constructServerMap(string fileName){
	unordered_map<string, vector<string>> serverMap;
	//read the file and construct the hashmap
	ifstream fin;
	fin.open(fileName);
	int count = 1;
	string line;
	while (getline(fin, line)) {

		if(count >= 1 && count <= 3){
			serverMap["GroupA"].push_back(line);
		}
		if(count >= 4 && count <= 6){
			serverMap["GroupB"].push_back(line);
		}
		if(count >= 7 && count <= 9){
			serverMap["GroupC"].push_back(line);
		}
			count++;
		}
	return serverMap;
}

unordered_map<string, string> backendMaster :: constructPrimaryMap(string groupName,
		                                                           string primaryAddress,
																   unordered_map<string, string> primaryMap){
	primaryMap[groupName] = primaryAddress;
	return primaryMap;
}

unordered_map<string, vector<string>> backendMaster :: constructGroupToClient(string groupName,
		                                                     string clientId,
															 unordered_map<string, vector<string>> groupToclient){

	if(groupToclient.size() == 0){
		 vector<string> inner1;
		 vector<string> inner2;
		 vector<string> inner3;
		 groupToclient["GroupA"] = inner1;
		 groupToclient["GroupB"] = inner2;
		 groupToclient["GroupC"] = inner3;
	}
	if(groupToclient.count(groupName) == 0){
    	  vector<string> inner;
    	  inner.push_back(clientId);
    	  groupToclient[groupName] = inner;
      }else{
    	  groupToclient[groupName].push_back(clientId);
      }
      return groupToclient;
}
// string backendMaster ::getLessClientGroup (unordered_map<string, vector<string>> groupToclient){

// 	 if(groupToclient.size() == 0){
// 		 vector<string> inner1;
// 		 vector<string> inner2;
// 		 vector<string> inner3;
// 		 groupToclient["GroupA"] = inner1;
// 		 groupToclient["GroupB"] = inner2;
// 		 groupToclient["GroupC"] = inner3;

// 	 }
//       int minSize = std::numeric_limits<int>::max();
//       string res;

//       for (auto it : groupToclient){
//     	  if(it.second.size() < minSize){
//     		  res = it.first;
//     		  minSize = it.second.size();
//     	  }
//       }

//       return res;

// }
string backendMaster ::gettargetClientGroup (string userName){
	string res;

	 if((userName[0] >= 65 && userName[0] <=72) || (userName[0] >= 97 && userName[0] <= 104)){
	 		res = "GroupA";
	 }else if((userName[0] >= 73 && userName[0] <= 80) || (userName[0] >= 105 && userName[0] <= 112)){
	 		res = "GroupB";
	 }else if((userName[0] >= 81 && userName[0] <= 90) || (userName[0] >= 113 && userName[0] <= 122)){
	 		res = "GroupC";
	 }
      return res;
}

unordered_map<string, string> backendMaster ::constructClientToGroup(unordered_map<string, string> clientTogroup,
    		                                                                 unordered_map<string, vector<string>> groupToclient){
	 for (auto it : groupToclient){
	    	 string groupName = it.first;
	    	 for(int i = 0; i < groupToclient[groupName].size(); i++){
	    		 clientTogroup[groupToclient[groupName][i]] = groupName;
	    	 }
	      }

	 return clientTogroup;
}

string backendMaster ::getAssignedServer(string userName){
	//return the primary address

	string groupName = this->clientTogroup[userName];
	string primaryAddress = this->primaryMap[groupName];

	return primaryAddress;

}

string backendMaster ::getPort(string address){
	int coloIndex = 0;
	for(int i = 0; i < address.length(); i++){
		if(address[i] == ':'){
			coloIndex = i;
			break;
		}
	}
	return address.substr(coloIndex + 1, address.length() - coloIndex - 1);
}

string backendMaster ::getIpAdress(string address){
	int coloIndex = 0;
		for(int i = 0; i < address.length(); i++){
			if(address[i] == ':'){
				coloIndex = i;
				break;
			}
		}

		return address.substr(0,  coloIndex);
}

void backendMaster ::constructServerAddressTogroup(){


  this->serverAddressTogroup["127.0.0.1:5001"] = "GroupA";
  this->serverAddressTogroup["127.0.0.1:5002"] = "GroupA";
  this->serverAddressTogroup["127.0.0.1:5003"] = "GroupA";


  this->serverAddressTogroup["127.0.0.1:6001"] = "GroupB";
  this->serverAddressTogroup["127.0.0.1:6002"] = "GroupB";
  this->serverAddressTogroup["127.0.0.1:6003"] = "GroupB";


  this->serverAddressTogroup["127.0.0.1:7001"] = "GroupC";
  this->serverAddressTogroup["127.0.0.1:7002"] = "GroupC";
  this->serverAddressTogroup["127.0.0.1:7003"] = "GroupC";
}


void backendMaster ::constructGroupToServers(){
  this->groupToservers["GroupA"].push_back("127.0.0.1:5001");
  this->groupToservers["GroupA"].push_back("127.0.0.1:5002");
  this->groupToservers["GroupA"].push_back("127.0.0.1:5003");
  this->groupToservers["GroupB"].push_back("127.0.0.1:6001");
  this->groupToservers["GroupB"].push_back("127.0.0.1:6002");
  this->groupToservers["GroupB"].push_back("127.0.0.1:6003");
  this->groupToservers["GroupC"].push_back("127.0.0.1:7001");
  this->groupToservers["GroupC"].push_back("127.0.0.1:7002");
  this->groupToservers["GroupC"].push_back("127.0.0.1:7003");
}



