#include<string>
#include <string.h>
#include<vector>
#include <time.h>
#include <openssl/md5.h>
#include "interface.h"
#include <stdio.h>
#include <iostream>
#include <unordered_map>
using namespace std;
void InterFaceAPI::newtime() {
	time_t now;
	time(&now);
	printf("Today is : %s", ctime(&now));
}
void InterFaceAPI::computeDigest(char *data, int dataLengthBytes,
		unsigned char *digestBuffer) {
	/* The digest will be written to digestBuffer, which must be at least MD5_DIGEST_LENGTH bytes long */

	MD5_CTX c;
	MD5_Init(&c);
	MD5_Update(&c, data, dataLengthBytes);
	MD5_Final(digestBuffer, &c);
}
string InterFaceAPI::hash_compute(string text) {
	int size = text.size();
	unsigned char digestBuffer[MD5_DIGEST_LENGTH];
	char input[size + 1];
	strcpy(input, text.c_str());
	computeDigest(input, text.size() + 1, digestBuffer);
	string result;
	char buf[32];
	for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
		sprintf(buf, "%02x", digestBuffer[i]);
		result.append(buf);
	}
	return result;
}
void InterFaceAPI::tokenize(string &m, vector<string> &vec, int vecsize) {
	char a[m.size() + 1];
	strcpy(a, m.c_str());
	char *token = strtok(a, " ");
	int i = 0;
	while (token != NULL) {
		//printf("%s\n", token);
		string str = "";
		str.append(token);
		vec.push_back(str);
		token = strtok(NULL, " ");
		i++;
		if (i == vecsize) {
			break;
		}
	}
}
string InterFaceAPI::toGet(string &key1, string &key2) {
	char str[1024];
	sprintf(str, "get %s %s", key1.c_str(), key2.c_str());
	if (strcmp(key2.c_str(), "") == 0) {
		return key2;
	}
	return this->serverDataMap[key1][key2];
//	sprintf(str, "get(%s,%s)", key1.c_str(), key2.c_str());
//	string toBack = "";
//	toBack.append(str);
//	printf("%s\n", str);
//	string out = "";
	//return out;
}

string InterFaceAPI::checkCookie(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string cookie = out.at(2);
	string key = "cookie";
	string newcookie = toGet(username, key);
	//cout<< "new cookie is " << newcookie << endl;
	if (strcmp(newcookie.c_str(), cookie.c_str()) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}

}
void InterFaceAPI::toPut(string &key1, string &key2, string &value) {
	char str[1024];
	sprintf(str, "put %s %s %s", key1.c_str(), key2.c_str(), value.c_str());
	this->serverDataMap[key1][key2] = value;

//	sprintf(str, "put(%s,%s,%s)", key1.c_str(), key2.c_str(), value.c_str());
	//string toBack = "";
	//toBack.append(str);
	//printf("%s\n", str);
}
string InterFaceAPI::newregister(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string key = "password";
	string value = out.at(2);

	toPut(username, key, value);

	if (this->serverDataMap[username][key].compare(value) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

void InterFaceAPI::toCput(string &key1, string &key2, string &oldvalue,
		string &newvalue) {
	char str[1024];
	if (this->serverDataMap[key1][key2].compare(oldvalue) != 0) {
		//old value doesn't match
		//do nothing
		return;
	}
	this->serverDataMap[key1][key2] = newvalue;

}
string InterFaceAPI::login(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string key = "password";
	string value = out.at(2);
	string realpass = toGet(username, key);
	if (strcmp(realpass.c_str(), value.c_str()) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}

}
string InterFaceAPI::setCookie(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string key = "cookie";
	string value = out.at(2);
	toPut(username, key, value);
//	string toBack = "put username cookie cookie";
	if (this->serverDataMap[username][key].compare(value) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

string InterFaceAPI::changePSW(string &m) {
	vector < string > out;
	tokenize(m, out, 4);
	string username = out.at(1);
	string key = "password";
	string oldvalue = out.at(2);
	string newvalue = out.at(3);
	toCput(username, key, oldvalue, newvalue);
	if (this->serverDataMap[username][key].compare(newvalue) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}
void InterFaceAPI::toDelete(string &key1, string &key2) {

	this->serverDataMap[key1].erase(key2);

}
string InterFaceAPI::deleteCookie(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string key = "cookie";
	string oldvalue = out.at(2);
	toDelete(username, key);

	if (this->serverDataMap[username].count(oldvalue) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

string InterFaceAPI::hash2name(string &username, string &folderhash) {
	string hash;
	string out = toGet(username, folderhash);
//	string toBack = "get username folder-hash";
	return out;
}
string InterFaceAPI::name2hash(string &username, string &foldername) {
//	string toBack = "get username name";
	string out = toGet(username, foldername);
	return out;
}
string InterFaceAPI::decodeDir(string &username, string &m, int mode) {
	// is mode =0 return folder
	// if mode =1 return all the files
	string out = "";
	string formmer = "";
	string latter = m;
	int k = latter.find("/");
	string dir = "";
	if (k == std::string::npos) {
		formmer = "/";
	}
	while (k != std::string::npos) {
		formmer = formmer + latter.substr(0, k);
		latter = latter.substr(k + 1);
		k = latter.find("/");
	}
	printf("add is %s\n", formmer.c_str());
	if (strcmp(formmer.c_str(), "") != 0) {
		dir = name2hash(username, formmer);
	}
//	dir = name2hash(username, formmer);
	return dir;
}

string InterFaceAPI::hashlist2namelist(string &username, string &m,
		string &unique, int mode) {
	//mode 0 return name list
	//mode 1 return newcontent after delete

	char a[m.size() + 1];
	strcpy(a, m.c_str());
	char *token = strtok(a, ";");
	int i = 0;
	string out;
	string newcontent = "";
	while (token != NULL) {
		//printf("%s\n", token);
		if (strcmp(token, unique.c_str()) == 0) {
			token = strtok(NULL, ";");
			continue;
		}
		string str = "";
		str.append(token);
		newcontent += str;
		newcontent.append(";");
		out += hash2name(username, str);
		out.append(";");
		token = strtok(NULL, ";");
	}
	printf("%s\n", out.c_str());
	if (mode == 0) {
		return out;
	} else {
		return newcontent;
	}

}
//void
string InterFaceAPI::addContent(string &username, string &foldername,
		string &filehash) {

//	string folderhash = toGet(username, foldername);
	string folderhash = foldername;
	printf("folderhash update %s\n", foldername.c_str());
	int k = folderhash.find("-");
	string foldercontent = "foldercontent-";
	if (k != std::string::npos) {
		foldercontent += folderhash.substr(k + 1);
	}
	string oldcontent = toGet(username, foldercontent);
	string newcontent = oldcontent;
	newcontent += filehash;
	newcontent += ";";
	printf("foldercontent update %s\n", foldercontent.c_str());
	toCput(username, foldercontent, oldcontent, newcontent);
	printf("%s\n", newcontent.c_str());
	if (this->serverDataMap[username][foldercontent].compare(newcontent) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}
string InterFaceAPI::driveCreate(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string value = out.at(2);

	string hash = hash_compute(value);

	string folderhash = "folder-";
	folderhash += hash;
	printf("%s\n", folderhash.c_str());
	string foldercontent = "foldercontent-";
	foldercontent += hash;
	toPut(username, value, folderhash);
	toPut(username, folderhash, value);
	string content = "";
	toPut(username, foldercontent, content);

	if (strcmp(value.c_str(), "/") == 0) {
		string suc = "+200 OK\n";
		return suc;
	}
	string foldername = decodeDir(username, value, 0);
	printf("foldername:%s\n", foldername.c_str());
	return addContent(username, foldername, folderhash);

}
string InterFaceAPI::driveOpen(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string value = out.at(2);

	string folderhash = toGet(username, value);
	int k = folderhash.find("-");
	string foldercontent = "foldercontent-";
	if (k != std::string::npos) {
		foldercontent += folderhash.substr(k + 1);
	}
	string folercontentlist = toGet(username, foldercontent);

	string unique = "";
	printf("111\n");
	string outlist = hashlist2namelist(username, folercontentlist, unique, 0);
//	this->serverDataMap[username][value].compare(outlist) == 0
	if (strcmp(outlist.c_str(), "") != 0) {
		string suc = "+200 OK " + outlist + "\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

void InterFaceAPI::toDeleteone(string &name, string &username, string &value) {
	if (strstr(name.c_str(), value.c_str()) != NULL) {
		string filehash = toGet(username, name);
		int k = filehash.find("-");
		string hash;
		if (k != std::string::npos) {
			hash = filehash.substr(k + 1);
		}
		if (strstr(filehash.c_str(), "file") != NULL) {
			string filecontent = "filecontent-";
			string filesize = "filesize-";
			filecontent += hash;
			filesize += hash;
			toDelete(username, name);
			toDelete(username, filecontent);
			toDelete(username, filesize);
			toDelete(username, filehash);
		} else if (strstr(filehash.c_str(), "folder") != NULL) {
			string foldercontent = "foldercontent-";
			foldercontent += hash;
			toDelete(username, name);
			toDelete(username, foldercontent);
			toDelete(username, filehash);
		}
	}
}
string InterFaceAPI::toDeletefile(string &username, string &value) {
	// for loop delete all clonme

	unordered_map < string, string > innerMap = this->serverDataMap[username];
	toDeleteone(value, username, value);
	value += "/";
	//string,map<string,string>
	for (auto it : innerMap) {

		string name = it.first;
		toDeleteone(name, username, value);

	}

	string suc = "+200 OK\n";
	return suc;

}
string InterFaceAPI::driveDelete(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string filename = out.at(2);

	string foldername = decodeDir(username, filename, 0);
	printf("%s\n", foldername.c_str());
	string folderhash = toGet(username, foldername);
	int k = folderhash.find("-");
	string pathfoldercontent = "foldercontent-";
	if (k != std::string::npos) {
		pathfoldercontent += folderhash.substr(k + 1);
	}
	string oldhashlist = toGet(username, pathfoldercontent);
	string filehash = toGet(username, filename);

	k = filehash.find("-");
	string hash;
	if (k != std::string::npos) {
		hash = filehash.substr(k + 1);
	}
//	printf("111\n");
	string newhashlist = hashlist2namelist(username, oldhashlist, filehash, 1);
	printf("new:%s, old:%s\n", newhashlist.c_str(), oldhashlist.c_str());
	toCput(username, pathfoldercontent, oldhashlist, newhashlist);
	printf("111\n");

	string res = toDeletefile(username, filename);

	if (res.compare("+200 OK\n") == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

//filerename()
string InterFaceAPI::toRename(string &username, string &oldname,
		string &newname) {

	unordered_map < string, string > innerMap = this->serverDataMap[username];
	for (auto it : innerMap) {
		string filename = it.first;
		if (strstr(filename.c_str(), oldname.c_str()) != NULL) {
			int index = filename.find(oldname);
			string newFileName = newname + filename.substr(index);
			toReplace(username, oldname, newFileName);
		}
	}

	string suc = "+200 OK\n";
	return suc;

}
void InterFaceAPI::toReplace(string &username, string &oldname,
		string &newname) {
	string filehash = toGet(username, oldname);
	toPut(username, newname, filehash);
	toCput(username, filehash, oldname, newname);
	toDelete(username, oldname);
}

string InterFaceAPI::driveRename(string &m) {
	vector < string > out;
	tokenize(m, out, 4);
	string username = out.at(1);
	string oldfilename = out.at(2);
	string newfilename = out.at(3);

	string filehash = toGet(username, oldfilename);
	toPut(username, newfilename, filehash);
	toCput(username, filehash, oldfilename, newfilename);
	toDelete(username, oldfilename);
	toRename(username, oldfilename, newfilename);
	if (this->serverDataMap[username].count(newfilename) != 0) {
		string suc = "+200 OK";
		return suc;
	} else {
		string err = "-400 ERR";
		return err;
	}
}
//string InterFaceAPI::hashlist2namelist(string &username, string &m,
//		string &unique, int mode) {
//	//mode 0 return name list
//	//mode 1 return newcontent after delete
//
////	printf("hashlist2namelist:\n");
////	char a[m.size() + 1];
////	strcpy(a, m.c_str());
//	printf("hashlist2namelist: %s\n", m.c_str());
//	string out;
//	string newcontent = "";
//	int k = m.find(";");
//	string formmer;
//	string latter = m;
////	string newcontent;
//	if(strcmp(m.c_str(),";")==0){
//		if(mode==1){
//			return m;
//		}else{
//			return newcontent;
//		}
//	}
//	while (k != std::string::npos) {
//		formmer = latter.substr(0, k);
//		latter = latter.substr(k + 1);
//		k = m.find(";");
//		if (strcmp(formmer.c_str(), unique.c_str()) == 0) {
//			continue;
//		} else {
//			string head;
//			if (strstr(formmer.c_str(), "file") != NULL) {
//				head = "file=";
//			} else {
//				head = "folder=";
//			}
//			if (strcmp(formmer.c_str(), unique.c_str()) != 0) {
//				newcontent += formmer;
//				newcontent.append(";");
//			}
//			string name = hash2name(username, formmer);
//			//		printf("name :%s\n", name.c_str());
//			name = getName(name);
//			out += head;
//			out += name;
//		}
//	}
//	if (strcmp(formmer.c_str(), unique.c_str()) == 0) {
////		continue;
//	} else {
//		string head;
//		if (strstr(formmer.c_str(), "file") != NULL) {
//			head = "file=";
//		} else {
//			head = "folder=";
//		}
//		if (strcmp(formmer.c_str(), unique.c_str()) != 0) {
//			newcontent += formmer;
//			newcontent.append(";");
//		}
//		string name = hash2name(username, formmer);
//		//		printf("name :%s\n", name.c_str());
//		name = getName(name);
//		out += head;
//		out += name;
//	}
//
//	if (mode == 0) {
//		return changeContent(out);
//	} else {
//		return newcontent;
//	}
//
//}
string InterFaceAPI::driveMove(string &m) {
	vector < string > out;
	tokenize(m, out, 4);
	string username = out.at(1);
	string oldfilename = out.at(2);
	string newfilename = out.at(3);

	string oldpath = decodeDir(username, oldfilename, 0);
	string filehash = toGet(username, oldfilename);

	string newpath = decodeDir(username, newfilename, 0);
	if (strcmp(newpath.c_str(), oldpath.c_str()) == 0) {
		return driveRename(m);
	} else {
		addContent(username, newpath, filehash);
		int k = oldpath.find("-");
		string hash = oldpath.substr(k + 1);
		string contenthash = "foldercontent-";
		contenthash += hash;
		string oldhashlist = toGet(username, contenthash);
		string newhashlist = hashlist2namelist(username, oldhashlist, filehash,
				1);
		printf("new:%s, old:%s\n", newhashlist.c_str(), oldhashlist.c_str());
		toCput(username, contenthash, oldhashlist, newhashlist);
	}
//	printf("foldername:%s\n", foldername.c_str());
//	return addContent(username, foldername, folderhash);

	return driveRename(m);
}

string InterFaceAPI::driveUpload(string &m) {
	vector < string > out;
	tokenize(m, out, 5);
	string username = out.at(1);
	string filename = out.at(2);
	string filesize = out.at(3);
	string data = out.at(4);
	string hash = hash_compute(filename);
	string filehash = "file-";
	string filecontent = "filecontent-";
	filehash += hash;
	filecontent += hash;
	toPut(username, filename, filehash);
	toPut(username, filehash, filename);
	string filesizehash = "filesize-";
	filesizehash += hash;
	toPut(username, filesize, filesize);
	string foldername = decodeDir(username, filename, 0);
	addContent(username, foldername, filehash);
//	string data = "";
	toPut(username, filecontent, data);
	string folderhash = toGet(username, foldername);
	if (this->serverDataMap[username][filecontent].compare(data) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}
string InterFaceAPI::driveDownload(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	string username = out.at(1);
	string filename = out.at(2);

	string filehash = toGet(username, filename);
	int k = filehash.find("-");
	string hash;
	if (k != std::string::npos) {
		hash = filehash.substr(k + 1);
	}
	string filesize = "filesize-";
	string filecontent = "filecontent-";
	filesize += hash;
	filecontent += hash;
	string size = toGet(username, filesize);
	string filedata = toGet(username, filecontent);
	if (this->serverDataMap[username][filecontent].compare(filedata) == 0) {
		string suc = "+200 OK fileSize fileAddr=filedata";
		return suc;
	} else {
		string err = "-400 ERR";
		return err;
	}
}
void InterFaceAPI::mailtokenize(string &m, vector<string> *vec, int vecsize) {
	int k = m.find(" ");
	string allcontent;
	if (k != std::string::npos) {
		allcontent = m.substr(k + 1);
	}
	int i = 0;
	for (i = 0; i < vecsize - 1; i++) {
		k = allcontent.find("\r\n");
		if (k != std::string::npos) {
			string tk = allcontent.substr(0, k);
//			printf("content email     %s\n", tk.c_str());
			vec->push_back(tk);
			allcontent = allcontent.substr(k + 1);

		} else {
			break;
		}
	}
	if(vecsize==2){
		printf("%d\n",vec->at(1));
	}
//	printf("content email     %s\n", allcontent.c_str());
	vec->push_back(allcontent);
}

string InterFaceAPI::Getuser(string &m) {
	string suc = "+200 OK name1 name2 name3";
	string err = "-400 ERR";
	return suc;
}
string InterFaceAPI::mailRecv(string &m) {
	vector < string > vec;
	printf("%s\n", m.c_str());
	mailtokenize(m, &vec, 3);
	string username = vec[0];
	string head = vec[1];
	string content = vec[2];
	string hash = hash_compute(head);
	printf("head:%s\n", head.c_str());
	string emailhash = "email-";
	emailhash += hash;
	string emailcontent = "emailcontent-";
	emailcontent += hash;
	toPut(username, emailhash, head);
	toPut(username, head, emailhash);
	toPut(username, emailcontent, content);
//	printf()
	printf("emailcontent:%s\n content:%s\n", emailcontent.c_str(),
			content.c_str());

	if (this->serverDataMap[username][emailcontent].compare(content) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}
string InterFaceAPI::mailInbox(string &m) {
	string content;
	vector < string > vec;
	mailtokenize(m, &vec, 0);
	string username = vec[0];
	string name;
	if (strcmp(name.substr(0, 6).c_str(), "email-") == 0) {
		content += toGet(username, name);
	}

	string suc = "+200 OK " + content + "\n";
	string err = "-400 ERR\n";
	return suc;
}
string InterFaceAPI::mailFetch(string &m) {

	vector < string > vec;
	printf("%s\n",m.c_str());
	mailtokenize(m, &vec, 2);
	string username = vec[0];
	string head = vec[1];
	printf("head:%s\n headersize:%d\n", head, head.size());
	string emailhash = toGet(username, head);
	printf("emailhash:%s\n", emailhash.c_str());
	int k = emailhash.find("-");
	string hash;
	if (k != std::string::npos) {
		hash = emailhash.substr(k + 1);
	}
	string contenthash = "emailcontent-";
	contenthash += hash;
	string contentdata = toGet(username, contenthash);
	printf("contentdata: %s\n", contenthash.c_str());
	if (this->serverDataMap[username][contenthash].compare(contentdata) == 0) {
		string suc = "Success: +200 OK " + contentdata + "\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

string InterFaceAPI::mailDelete(string &m) {
	vector < string > vec;
	mailtokenize(m, &vec, 2);
	string username = vec[0];
	string head = vec[1];
	string emailhash = toGet(username, head);
	int k = emailhash.find("-");
	string hash;
	if (k != std::string::npos) {
		hash = emailhash.substr(k + 1);
	}
	string contenthash = "emailcontent-";
	contenthash += hash;
	toDelete(username, head);
	toDelete(username, emailhash);
	toDelete(username, contenthash);
	if (this->serverDataMap[username].count(head) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}
string InterFaceAPI::checkCommand(string &m) {
	string res;
	if (strstr(m.c_str(), "checkCookie") != NULL) {
		res = checkCookie(m);
		return res;
	} else if (strstr(m.c_str(), "register") != NULL) {
		res = newregister(m);
	} else if (strstr(m.c_str(), "login") != NULL) {
		res = login(m);
	} else if (strstr(m.c_str(), "setCookie") != NULL) {
		res = setCookie(m);
		return res;
	} else if (strstr(m.c_str(), "changePSW") != NULL) {
		res = changePSW(m);
		return res;
	} else if (strstr(m.c_str(), "deleteCookie") != NULL) {
		res = deleteCookie(m);
		return res;
	}
	//folder
	else if (strstr(m.c_str(), "driveCreate") != NULL) {
		res = driveCreate(m);
		return res;
	} else if (strstr(m.c_str(), "driveOpen") != NULL) {
		res = driveOpen(m);
		return res;
	} else if (strstr(m.c_str(), "driveDelete") != NULL) {
		res = driveDelete(m);
		return res;

	} else if (strstr(m.c_str(), "driveRename") != NULL) {
		res = driveRename(m);
		return res;
	} else if (strstr(m.c_str(), "driveMove") != NULL) {
		res = driveMove(m);
		return res;
	} else if (strstr(m.c_str(), "driveUpload") != NULL) {
		res = driveUpload(m);
		return res;
	} else if (strstr(m.c_str(), "driveDownload") != NULL) {
		res = driveDownload(m);
		return res;
	} else if (strstr(m.c_str(), "mailGetuser") != NULL) {
		res = Getuser(m);
		return res;
	} else if (strstr(m.c_str(), "mailRev") != NULL) {
		res = mailRecv(m);
		return res;
	} else if (strstr(m.c_str(), "mailInbox") != NULL) {
		res = mailInbox(m);
		return res;
	} else if (strstr(m.c_str(), "mailFetch") != NULL) {
		res = mailFetch(m);
		return res;
	} else if (strstr(m.c_str(), "mailDelete") != NULL) {
		res = mailDelete(m);
		return res;
	} else {
		cout << "nothing match !!!!!!!!!!!!!!!!!!" << endl;
	}
	return res;

}
