/*
 * commandOperation.cc
 *
 *  Created on: Dec 12, 2020
 *      Author: cis505
 */
#include <stdlib.h>
#include <string>
#include <stdio.h>
#include <sys/file.h>
#include <unordered_map>
#include <vector>
#include "commandOperation.h"
using namespace std;

void command ::putFunction(string row, string col, string val){
	this->serverMap[row][col] = val;
}

string command ::getFunction(string row, string col){
	if(this->serverMap.count(row) == 0){
		return "";
	}
	if(this->serverMap[row].count(col) == 0){
		return "";
	}
	return this->serverMap[row][col];
}

void command ::cputFunction(string row, string col, string oldValue, string newValue){
	if(this->serverMap.count(row) == 0){
		return;
	}
	if(this->serverMap[row].count(col) == 0){
		return;
	}
	if(this->serverMap[row][col].compare(oldValue) == 0){
		return;
	}
	this->serverMap[row][col] = newValue;
}

void command ::deleteFunction(string row, string col){
	if(this->serverMap.count(row) == 0){
			return;
	}
	if(this->serverMap[row].count(col) == 0){
		return;
	}
	this->serverMap[row].erase(col);
}


