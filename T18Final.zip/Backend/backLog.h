#ifndef BACKLOG_H
#define BACKLOG_H
#include <stdio.h>
#include <string>
#include <map>
#include <tuple>
#include <iostream>
#include <vector>
using namespace std;


class backLog {
private:
	string f_path;
	FILE *fp;
	int mode;
public:

//	backLog(string path,int port);

	void setLog(string path,int port);

	int showmode();

	vector<string> readFile();

	void writeFile(int port,string &command);

	void checkRestart();

	void closeFile();
};

#endif
