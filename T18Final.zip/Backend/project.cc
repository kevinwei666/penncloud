#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <string>
#include <cstring>
#include <pthread.h>
#include <vector>
#include <cstdlib>
#include <signal.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <unordered_map>
#include <iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <string>
#include <cstring>
#include <pthread.h>
#include <vector>
#include <cstdlib>
#include <signal.h>
#include "KVcommand.h"

using namespace std;
int sockDescrip;
vector<int> acceptVector;
string path = "./file.txt";
KVcommand cmd;


void *worker(void *arg){
	int acceptVal = *(int*) arg;
	while(true){
		char test = 0;
		string readStr;
		while(read(acceptVal, &test, 1) != 0){
			if(test == '\n'){
				 readStr += '\n';
				 break;
			}else{
				 readStr += test;
			}
		}

		bool getRes = false;
		bool putRes = false;
		bool cputRes = false;
		bool deleRes = false;
        if(readStr.substr(0, 3).compare("GET") == 0){
        	string row = readStr.substr(4,1);
        	string col = readStr.substr(6,1);
        	string res = cmd.getFunction(row, col);
        	cout << "get is " << res << endl;
        }else if(readStr.substr(0, 3).compare("PUT") == 0){
        	cout<<"user input:"<<readStr.length()<<endl;
        	string row = readStr.substr(4, 1);

        	string col = readStr.substr(6,1);

        	string val = readStr.substr(8, 1);

        	cmd.putFunction(row, col, val);
        }else if(readStr.substr(0, 4).compare("CPUT") == 0){
        	string row = readStr.substr(5,1);
			string col = readStr.substr(7,1);
			string val1 = readStr.substr(9, 1);
			string val2 = readStr.substr(11, 1);
			cmd.cputFunction(row, col, val1, val2);
        }else if((readStr.substr(0, 6).compare("DELETE") == 0)){
        	string row = readStr.substr(7,1);
        	string col = readStr.substr(9,1);
        	cmd.deleteFunction(row, col);

        }else{
        	cout<< "wrong command" << endl;
        }
	}
	close(acceptVal);
    pthread_exit(NULL);
}


int keyValueServer(int portNum){

	struct sockaddr_in serverAddress;
	    //--------------create a new socket--------------------------//
	    sockDescrip = socket(PF_INET, SOCK_STREAM,0);

	    if(sockDescrip == 0){
	    	printf("the socket creation is wrong, Cannot open it!\n");
	    	exit(1);
	    }
	    //----------------bind()-------------------------------------//
	    bzero(&serverAddress, sizeof(serverAddress));
	    serverAddress.sin_family = AF_INET;
	    serverAddress.sin_port = htons(portNum);
	    serverAddress.sin_addr.s_addr = (INADDR_ANY);
	    int bindRes = bind(sockDescrip, (struct sockaddr *)&serverAddress, sizeof(serverAddress));

	    if(bindRes == -1){
	    	printf("bind failed\n");
	    	exit(1);
	    }
	    //---------------------listen() -----------------------------------//
	    int listenRes = listen(sockDescrip, 100);
	    if(listenRes == -1){
	    	printf("cannot listen\n");
	    	exit(1);
	    }

	    while(true){
		 //--------------accept()-----------------------------//
			struct sockaddr_in clientaddr;
			socklen_t sin_size = sizeof(clientaddr);
			int *acceptRes = (int*)malloc(sizeof(int));
			 *acceptRes = accept(sockDescrip, (struct sockaddr *)&clientaddr, &sin_size);
			if(*acceptRes == -1){
				printf("the wrong accept\n");
				exit(1);
			}
			printf("[%d] New connection! Server gets the connect is from %s and client port num is %d\n",*acceptRes, inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
			    	const char *welcomString = "+OK Server ready (Author: Kaiwen Wei / wkaiwen) \r\n";
			    	write(*acceptRes, welcomString, strlen(welcomString));
			    	pthread_t thread;
			    	acceptVector.push_back(*acceptRes);
			    	pthread_create(&thread, NULL, worker, acceptRes);

	    }
	    close(sockDescrip);
	    return 0;


}
int main(int argc, char *argv[])
{

    if (argc <= 2) {
		fprintf(stderr, "*** Author: Kaiwen Wei wkaiwen\n");
		exit(1);
    }

    int portNum = atoi(argv[2]);
    keyValueServer(portNum);
    return 0;
}
