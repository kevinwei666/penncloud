#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include<string>
#include<map>
#include<vector>
#include <unistd.h>
#include "KVcommunication.h"
#include "backLog.h"
#include "defaultport.h"
#include "basicServer.h"
#include "interface.h"
#include "MapFileFunctions.h"
#include "commandOperation.h"
#include "BackendMaster.h"
#define TRUE   1
#define FALSE  0
int PORT = 5001;
vector<int> portvec;
int debug = 0;
int second = 0;
int masterPort = 0;
int adminPort = 0;
using namespace std;
int mode = 0;
MapFile MF;
command kvCommand;
backendMaster bm;
InterFaceAPI IFA;
vector<int> lostConnection;
map<int, int> port2socket;

int main(int argc, char *argv[]) {

	vector<int> portVector;
	portVector.push_back(5001);
	portVector.push_back(5002);
	portVector.push_back(5003);
	portVector.push_back(6001);
	portVector.push_back(6002);
	portVector.push_back(6003);
	portVector.push_back(7001);
	portVector.push_back(7002);
	portVector.push_back(7003);

	while(1){
		sleep(10);
		for(int i = 0; i < portVector.size(); i++){
			int myport = 8001;
			int output = portVector[i];
			int socket = reconnectServer(myport, output);
			cout << "the socket is :" << socket << endl;
			if(socket == -1){
				continue;
			}
			string message = "write";
			if (send(socket, message.c_str(), strlen(message.c_str()), 0)
					!= strlen(message.c_str())) {
				perror("send");
			}
			close(socket);
//			shutdown
		}
	}

}

