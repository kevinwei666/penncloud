#include "basicServer.h"
#include<vector>
using namespace std;
//class basicServer {
//private:
//	int PORT;
//	vector<int> portvec;
//	int maxClient;
//	int client_socket[maxClient];
//	map<int, string> client_socket_add;
//	map<int, int> client_socket_port;
//	map<int, int> client_port2socket;
//
//public:
//
//};
void basicServer::put(int port, int socket) {
	for (int i = 0; i < maxClient; i++) {
		if (client_socket[i] == 0) {
			client_socket[i] = socket;
			break;
		}
	}
	client_socket_port[socket] = port;
	client_port2socket[port] = socket;
}
;
void basicServer::setServer(int num) {
	maxClient = num;

	int i;
	client_socket = new int[num];
	for (i = 0; i < maxClient; i++) {
		client_socket[i] = 0;
	}
}
;
void basicServer::removeSocket(int socket) {
	int i;
	for (i = 0; i < maxClient; i++) {
		if (client_socket[i] == socket) {
			client_socket[i] = 0;
			break;
		}
	}
	int removeport = client_socket_port[socket];
	client_socket_port.erase(socket);
	client_port2socket.erase(removeport);
}
;
bool basicServer::checkPort(int port){
	for (int i = 0; i < maxClient; i++) {
		if (client_socket[i] > 0) {
			if(client_socket_port[client_socket[i]]==port){
				return true;
			}
		}
	}
	return false;
}
