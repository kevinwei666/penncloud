#include<string>
#include <string.h>
#include<vector>
#include <time.h>
#include <openssl/md5.h>
#include "interface.h"
#include <stdio.h>
#include <iostream>
#include <unordered_map>
using namespace std;
void InterFaceAPI::newtime() {
	time_t now;
	time(&now);
	printf("Today is : %s", ctime(&now));
}
void InterFaceAPI::computeDigest(char *data, int dataLengthBytes,
		unsigned char *digestBuffer) {
	/* The digest will be written to digestBuffer, which must be at least MD5_DIGEST_LENGTH bytes long */

	MD5_CTX c;
	MD5_Init(&c);
	MD5_Update(&c, data, dataLengthBytes);
	MD5_Final(digestBuffer, &c);
}
//string InterFaceAPI::hash_compute(string text) {
//	int size = text.size();
//	unsigned char digestBuffer[MD5_DIGEST_LENGTH];
//	char input[size + 1];
//	strcpy(input, text.c_str());
//	computeDigest(input, text.size() + 1, digestBuffer);
//	string result;
//	char buf[32];
//	for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
//		sprintf(buf, "%02x", digestBuffer[i]);
//		result.append(buf);
//	}
//	return result;
//}
string InterFaceAPI::hash_compute(string text) {
	time_t now;
	time(&now);
	text.append(ctime(&now));
	int size = text.size();
	unsigned char digestBuffer[MD5_DIGEST_LENGTH];
	char input[size + 1];
	strcpy(input, text.c_str());
	computeDigest(input, text.size() + 1, digestBuffer);
	string result;
	char buf[32];
	for (int i = 0; i < 10; i++) {
		sprintf(buf, "%02x", digestBuffer[i]);
		result.append(buf);
	}
	return result;
}
void InterFaceAPI::tokenize(string &m, vector<string> &vec, int vecsize) {
	int k = m.find(" ");
	int i = 0;
	string latter = m;
	string formmer;
	while (k != std::string::npos) {
		if (i == vecsize - 1) {
			break;
		}
		formmer = latter.substr(0, k);
		latter = latter.substr(k + 1);

		vec.push_back(formmer);
//		printf("formmer: %s\n", formmer.c_str());
		k = latter.find(" ");
		i++;
	}
	vec.push_back(latter);

//	printf("aaaaaaaaaaaaaaaaaaaaaa %d %d %s\n",vecsize,vec.size(),vec[vecsize-1].c_str());

}
string InterFaceAPI::toGet(string &key1, string &key2) {
	char str[1024];
	sprintf(str, "get %s %s", key1.c_str(), key2.c_str());
	if (strcmp(key2.c_str(), "") == 0) {
		return key2;
	}
	return this->serverDataMap[key1][key2];
//	sprintf(str, "get(%s,%s)", key1.c_str(), key2.c_str());
//	string toBack = "";
//	toBack.append(str);
//	printf("%s\n", str);
//	string out = "";
	//return out;
}

string InterFaceAPI::checkCookie(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out[1];
	string cookie = out[2];
	string key = "cookie";
	string newcookie = toGet(username, key);
	//cout<< "new cookie is " << newcookie << endl;
	if (strcmp(newcookie.c_str(), cookie.c_str()) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}

}
void InterFaceAPI::toPut(string &key1, string &key2, string &value) {
	this->serverDataMap[key1][key2] = value;

}
string InterFaceAPI::newregister(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string key = "password";
	string ifexist = toGet(out[1], key);
	if (strcmp(ifexist.c_str(), "") != 0) {
		string err = "-400 ERR\n";
		return err;
	}

	string username = out[1];

	string value = out[2];

	toPut(username, key, value);

	if (this->serverDataMap[username][key].compare(value) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

void InterFaceAPI::toCput(string &key1, string &key2, string &oldvalue,
		string &newvalue) {
	char str[1024];
	if (this->serverDataMap[key1][key2].compare(oldvalue) != 0) {
		//old value doesn't match
		//do nothing
		return;
	}
	this->serverDataMap[key1][key2] = newvalue;

}
string InterFaceAPI::login(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out[1];
	string key = "password";
	string value = out[2];
	string realpass = toGet(username, key);
	if (strcmp(realpass.c_str(), value.c_str()) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}

}
string InterFaceAPI::setCookie(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out[1];
	string key = "cookie";
	string value = out[2];
	toPut(username, key, value);
//	string toBack = "put username cookie cookie";
	if (this->serverDataMap[username][key].compare(value) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

string InterFaceAPI::changePSW(string &m) {
	vector < string > out;
	tokenize(m, out, 4);
	if (out.size() != 4) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out[1];
	string key = "password";
	string oldvalue = out[2];
	string newvalue = out[3];
	toCput(username, key, oldvalue, newvalue);
	if (this->serverDataMap[username][key].compare(newvalue) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}
void InterFaceAPI::toDelete(string &key1, string &key2) {

	this->serverDataMap[key1].erase(key2);

}
string InterFaceAPI::deleteCookie(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out[1];
	string key = "cookie";
	string oldvalue = out[2];
	toDelete(username, key);

	if (this->serverDataMap[username].count(oldvalue) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

string InterFaceAPI::hash2name(string &username, string &folderhash) {
	string hash;
	string out = toGet(username, folderhash);
//	string toBack = "get username folder-hash";
	return out;
}
string InterFaceAPI::name2hash(string &username, string &foldername) {
//	string toBack = "get username name";
	string out = toGet(username, foldername);
	return out;
}
string InterFaceAPI::decodeDir(string &username, string &m, int mode) {
	// is mode =0 return folder
	// if mode =1 return all the files
	string out = "";
	string formmer = "";
	string latter = m;
	int k = latter.find("/");
	string dir = "";
	if (k == std::string::npos) {
		formmer = "/";
	}
	while (k != std::string::npos) {
		formmer = formmer + latter.substr(0, k) + "/";
		latter = latter.substr(k + 1);
		k = latter.find("/");
	}
	char ch = formmer.back();
	string lastele;
	lastele += ch;
	if (formmer.size() > 1 && strcmp(lastele.c_str(), "/") == 0) {
		formmer.pop_back();
	}
	printf("add is %s\n", formmer.c_str());
	if (strcmp(formmer.c_str(), "") != 0) {
		dir = name2hash(username, formmer);
	}
	printf("dirhash:%s\n", dir.c_str());
//	dir = name2hash(username, formmer);
	return dir;
}
string InterFaceAPI::changeContent(string &m) {

	string newcontent = "";
	int k = m.find(";");
	string latter = m;
	string formmer;
	while (k != std::string::npos) {
		formmer = latter.substr(0, k);
		latter = latter.substr(k + 1);
		if (strcmp(formmer.c_str(), "") == 0) {
			continue;
		}
		newcontent += formmer;
		newcontent.append(" ");
		k = latter.find(";");
	}
	if (strcmp(latter.c_str(), "") != 0) {
		newcontent += latter;
		newcontent.append(" ");
	}
	return newcontent;
}
string InterFaceAPI::getName(string &m) {
	printf("getname: %s\n", m.c_str());
	if (strcmp(m.c_str(), "/") == 0) {
		string out = "/";
		return out;
	}
	int k = m.find("/");
	string latter = m;
	while (k != std::string::npos) {
		latter = latter.substr(k + 1);
		k = latter.find("/");
	}
	return latter;

}

string InterFaceAPI::hashlist2namelist(string &username, string &m,
		string &unique, int mode) {
	//mode 0 return name list
	//mode 1 return newcontent after delete

	char a[m.size() + 1];
	strcpy(a, m.c_str());
	char *token = strtok(a, ";");
	int i = 0;
	string out;
	string newcontent = "";
	printf("unique:%s\n", unique.c_str());
	while (token != NULL) {
		if (strcmp(token, unique.c_str()) == 0) {
			token = strtok(NULL, ";");
			continue;
		}
		string str = "";
		str.append(token);
		newcontent += str;
		newcontent.append(";");
		string head;
		if (strstr(str.c_str(), "file") != NULL) {
			head = "file=";
		} else {
			head = "folder=";
		}
//		out += hash2name(username, str);
		string name = hash2name(username, str);
		printf("name:%s\n", name.c_str());
		name = getName(name);
//		if (strcmp(name.c_str(),"")==0) {
//			token = strtok(NULL, ";");
//			continue;
//		}
//		printf("token:%s\n name:%s\n",str.c_str(),name.c_str());
		out += head;
		out += name;

		out.append(";");
		token = strtok(NULL, ";");

	}
	printf("%s\n", out.c_str());
	printf("newcontent:%s\n", newcontent.c_str());
	if (mode == 0) {
		return changeContent(out);
	} else {
		return newcontent;
	}

}
//void
string InterFaceAPI::addContent(string &username, string &foldername,
		string &filehash) {

//	string folderhash = toGet(username, foldername);
	string folderhash = foldername;
//	printf("folderhash update %s\n", foldername.c_str());
	int k = folderhash.find("-");
	string foldercontent = "foldercontent-";
	if (k != std::string::npos) {
		foldercontent += folderhash.substr(k + 1);
	}
	string oldcontent = toGet(username, foldercontent);
	string newcontent = oldcontent;
	newcontent += filehash;
	newcontent += ";";
//	printf("foldercontent update %s\n", foldercontent.c_str());
	toCput(username, foldercontent, oldcontent, newcontent);
//	printf("%s\n", newcontent.c_str());
	if (this->serverDataMap[username][foldercontent].compare(newcontent) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

string InterFaceAPI::driveCreate(string &m) {
//	printf("111\n");
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out[1];
	string value = out[2];

	string hash = hash_compute(value);

	string folderhash = "folder-";
	folderhash += hash;
	printf("%s\n", folderhash.c_str());
	string foldercontent = "foldercontent-";
	foldercontent += hash;
	toPut(username, value, folderhash);

	toPut(username, folderhash, value);
	hash2name(username, folderhash);
	printf("new foldername %s\n", value.c_str());

	string content = ";";
	toPut(username, foldercontent, content);
//	printf("111\n");
//	printf("%s\n value:%s\n", foldercontent.c_str(),value.c_str());

	if (strcmp(value.c_str(), "/") == 0) {
//		printf("%s\n", toGet(username, foldercontent).c_str());
		string suc = "+200 OK\n";
		return suc;
	}
//	string test = "folder-1f47f8c68e38df3136ef2b535712721d";
//	hash2name(username, test);
	printf("value:%s\n", value.c_str());
	string foldername = decodeDir(username, value, 0);
	printf("pathhash:%s\n", foldername.c_str());
//	printf("foldername:%s\n", foldername.c_str());
	return addContent(username, foldername, folderhash);

}
string InterFaceAPI::driveOpen(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out[1];
	string value = out[2];

	string folderhash = toGet(username, value);
	printf("folderhash:%s\n", folderhash.c_str());
	int k = folderhash.find("-");
	string foldercontent = "foldercontent-";
	if (k != std::string::npos) {
		foldercontent += folderhash.substr(k + 1);
	}
	string folercontentlist = toGet(username, foldercontent);
	printf("folercontentlist:%s\n", folercontentlist.c_str());
	string unique = "";
//	printf("111\n");
	string outlist = hashlist2namelist(username, folercontentlist, unique, 0);
	printf("outlist:%s\n", outlist.c_str());
//	this->serverDataMap[username][value].compare(outlist) == 0
	if (strcmp(outlist.c_str(), "") != 0
			|| strcmp(folercontentlist.c_str(), ";") == 0) {
		string suc = "+200 OK " + outlist + "\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

void InterFaceAPI::toDeleteone(string &name, string &username, string &value) {
	if (strstr(name.c_str(), value.c_str()) != NULL) {
//		printf("delete")
		string filehash = toGet(username, name);
		int k = filehash.find("-");
		string hash;
		if (k != std::string::npos) {
			hash = filehash.substr(k + 1);
		}
		if (strstr(filehash.c_str(), "file") != NULL) {
			string filecontent = "filecontent-";
			string filesize = "filesize-";
			filecontent += hash;
			filesize += hash;
			toDelete(username, name);
			toDelete(username, filecontent);
			toDelete(username, filesize);
			toDelete(username, filehash);
		} else if (strstr(filehash.c_str(), "folder") != NULL) {
			string foldercontent = "foldercontent-";
			foldercontent += hash;
			toDelete(username, name);
			toDelete(username, foldercontent);
			toDelete(username, filehash);
		}
	}
}
string InterFaceAPI::toDeletefile(string &username, string &value) {
	// for loop delete all clonme

	unordered_map < string, string > innerMap = this->serverDataMap[username];
	toDeleteone(value, username, value);
	value += "/";
	//string,map<string,string>
	printf("deletepath:%s\n", value.c_str());
	for (auto it : innerMap) {

		string name = it.first;
		toDeleteone(name, username, value);
	}

	string suc = "+200 OK\n";
	return suc;

}
string InterFaceAPI::driveDelete(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out.at(1);
	string filename = out.at(2);

	string folderhash = decodeDir(username, filename, 0);
//	printf("%s\n", foldername.c_str());
//	string folderhash = toGet(username, foldername);
	int k = folderhash.find("-");
	string pathfoldercontent = "foldercontent-";
	string pathhash;
	if (k != std::string::npos) {
		pathhash = folderhash.substr(k + 1);
	}
	pathfoldercontent += pathhash;
//	printf("pathfoldercontent:%s\n",pathfoldercontent.c_str());

	string oldhashlist = toGet(username, pathfoldercontent);
//	printf("oldhashlist:%s\n",oldhashlist.c_str());
	string filehash = toGet(username, filename);

	k = filehash.find("-");
	string hash;
	if (k != std::string::npos) {
		hash = filehash.substr(k + 1);
	}
//	printf("111\n");
	string newhashlist = hashlist2namelist(username, oldhashlist, filehash, 1);
//	printf("new:%s, old:%s\n", newhashlist.c_str(), oldhashlist.c_str());
	if (strcmp(newhashlist.c_str(), "") == 0) {
		newhashlist = ";";
	}
	toCput(username, pathfoldercontent, oldhashlist, newhashlist);
//	printf("111 \n");
//
	string a = toGet(username, folderhash);
	string b = toGet(username, a);
	string res = toDeletefile(username, filename);

	if (res.compare("+200 OK\n") == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}

//filerename()
string InterFaceAPI::toRename(string &username, string &oldname,
		string &newname) {

	unordered_map < string, string > innerMap = this->serverDataMap[username];
	oldname += '/';
	for (auto it : innerMap) {
		string filename = it.first;
		if (strstr(filename.c_str(), oldname.c_str()) != NULL) {
			int index = filename.find(oldname);
			string newFileName = newname + '/'
					+ filename.substr(index + oldname.size());
			string oldfilename = oldname
					+ filename.substr(index + oldname.size());
			toReplace(username, oldfilename, newFileName);
			printf("oldname%s\nnewname:%s\n", oldfilename.c_str(),
					newFileName.c_str());
		}
	}
	string suc = "+200 OK\n";
	return suc;

}
void InterFaceAPI::toReplace(string &username, string &oldname,
		string &newname) {
	string filehash = toGet(username, oldname);
	toPut(username, newname, filehash);
	toCput(username, filehash, oldname, newname);
	toDelete(username, oldname);
}

string InterFaceAPI::driveRename(string &m) {
	vector < string > out;
	tokenize(m, out, 4);
	if (out.size() != 4) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out.at(1);
	string oldfilename = out.at(2);
	string newfilename = out.at(3);

	string filehash = toGet(username, oldfilename);
	toPut(username, newfilename, filehash);
	toCput(username, filehash, oldfilename, newfilename);
	toDelete(username, oldfilename);
	toRename(username, oldfilename, newfilename);
	if (this->serverDataMap[username].count(newfilename) != 0) {
		string suc = "+200 OK";
		return suc;
	} else {
		string err = "-400 ERR";
		return err;
	}
}
string InterFaceAPI::driveMove(string &m) {
	vector < string > out;
	tokenize(m, out, 4);
	if (out.size() != 4) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out.at(1);
	string oldfilename = out.at(2);
	string newfilename = out.at(3);
	printf("oldfilename%s\n", oldfilename.c_str());
	string oldpath = decodeDir(username, oldfilename, 0);
	string filehash = toGet(username, oldfilename);
	printf("oldfilename%s\n", filehash.c_str());
	string newpath = decodeDir(username, newfilename, 0);
	printf("newhash:%s\noldhash%s\n", newpath.c_str(), oldpath.c_str());
	if (strcmp(newpath.c_str(), oldpath.c_str()) == 0) {
		return driveRename(m);
	} else {
		addContent(username, newpath, filehash);
		int k = oldpath.find("-");
		string hash = oldpath.substr(k + 1);
		string contenthash = "foldercontent-";
		contenthash += hash;
		string oldhashlist = toGet(username, contenthash);
		string newhashlist = hashlist2namelist(username, oldhashlist, filehash,
				1);
		printf("filehash:%s\nnew:%s, old:%s\n", filehash.c_str(),
				newhashlist.c_str(), oldhashlist.c_str());
		toCput(username, contenthash, oldhashlist, newhashlist);
	}
//	printf("foldername:%s\n", foldername.c_str());
//	return addContent(username, foldername, folderhash);

	return driveRename(m);
}

string InterFaceAPI::driveUpload(string &m) {
	vector < string > out;
	tokenize(m, out, 5);
	if (out.size() != 5) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out[1];
	string filename = out[2];
	string filesize = out[3];
	string data = out[4];
	printf("filename:%s\n", data.c_str());
	string hash = hash_compute(filename);
	string filehash = "file-";
	string filecontent = "filecontent-";
	filehash += hash;
	filecontent += hash;
	toPut(username, filename, filehash);

//	string newfilename = "file=";
//	newfilename += getName(filename);
	toPut(username, filehash, filename);
//	printf("%s\n", newfilename.c_s/tr());

//	toPut(username, filehash, filename);
	string filesizehash = "filesize-";
	filesizehash += hash;
	toPut(username, filesizehash, filesize);
//	printf("filehash:%s")
	string foldername = decodeDir(username, filename, 0);
	addContent(username, foldername, filehash);
	toPut(username, filecontent, data);
	string folderhash = toGet(username, foldername);
	if (this->serverDataMap[username][filecontent].compare(data) == 0) {
		string suc = "+200 OK\n";
		return suc;
	} else {
		string err = "-400 ERR\n";
		return err;
	}
}
string InterFaceAPI::driveDownload(string &m) {
	vector < string > out;
	tokenize(m, out, 3);
	if (out.size() != 3) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = out.at(1);
	string filename = out.at(2);

	string filehash = toGet(username, filename);
	int k = filehash.find("-");
	string hash;
	if (k != std::string::npos) {
		hash = filehash.substr(k + 1);
	}
	string filesize = "filesize-";
	string filecontent = "filecontent-";
	filesize += hash;
	filecontent += hash;
	string size = toGet(username, filesize);
	string filedata = toGet(username, filecontent);
	if (this->serverDataMap[username][filecontent].compare(filedata) == 0) {
		string suc = "+200 OK " + size + " " + filedata + "\n";
		return suc;
	} else {
		string err = "-400 ERR";
		return err;
	}
}
void InterFaceAPI::mailtokenize(string &m, vector<string> *vec, int vecsize) {
	int k = m.find(" ");
	string allcontent;
	if (k != std::string::npos) {
		allcontent = m.substr(k + 1);
	}
	int i = 0;
	for (i = 0; i < vecsize - 1; i++) {
		k = allcontent.find("\r\n");
		if (k != std::string::npos) {
			string tk = allcontent.substr(0, k);
//			printf("content email     %s\n", tk.c_str());
			vec->push_back(tk);
			allcontent = allcontent.substr(k + 2);

		} else {
			break;
		}
	}
	vec->push_back(allcontent);
}

string InterFaceAPI::Getuser(string &m) {
	string nameList;
	printf("m:%s\n", m.c_str());
	if (this->serverDataMap.size() == 0) {
		string err = "ERR: -400 ERR";
		return err;
	} else {
		for (auto it : this->serverDataMap) {
			string username = it.first;
			nameList += username;
			nameList += " ";
		}
	}
	printf("nameList:%s\n", nameList.c_str());
	string suc = "+200 OK " + nameList;
	return suc;
}

string InterFaceAPI::mailRecv(string &m) {
	vector < string > vec;
	printf("%s\n", m.c_str());
	mailtokenize(m, &vec, 3);
	if (vec.size() != 3) {
		string err = "-400 ERR";
		return err;
	}
	string username = vec[0];
	string head = vec[1];
	string content = vec[2];
	string hash = hash_compute(head);
	int size = head.size();
	printf("head:%s\n headsize:%d \n", head.c_str(), size);
	string emailhash = "email-";
	emailhash += hash;
	string emailcontent = "emailcontent-";
	emailcontent += hash;
	toPut(username, emailhash, head);
	toPut(username, head, emailhash);
	toPut(username, emailcontent, content);
//	printf()
	printf("emailcontent:%s\n content:%s\n", emailcontent.c_str(),
			content.c_str());

	if (this->serverDataMap[username][emailcontent].compare(content) == 0) {
		string suc = "+200 OK";
		return suc;
	} else {
		string err = "-400 ERR";
		return err;
	}
}
string InterFaceAPI::mailInbox(string &m) {
	string content;
	vector < string > vec;
	mailtokenize(m, &vec, 1);
	if (vec.size() != 1) {
		string err = "-400 ERR";
		return err;
	}
	string username = vec.at(0);
	string name;
	string headList;
	for (auto it : this->serverDataMap[username]) {
		string innerKey = it.first;
		if (strstr(innerKey.c_str(), "email-")) {
			headList += it.second;
			headList += "\r\n";
		}
	}
	if (headList.length() != 0) {
		string suc = "+200 OK\r\n" + headList;
		return suc;
	} else {
		string err = "-400 ERR";
		return err;
	}
}
string InterFaceAPI::mailFetch(string &m) {

	vector < string > vec;
	mailtokenize(m, &vec, 2);
	if (vec.size() != 2) {
		string err = "-400 ERR\n";
		return err;
	}
	string username = vec[0];
	string head = vec[1];
	int size = head.size();
	printf("head:%s\n headsize:%d \n", head.c_str(), size);
	string emailhash = toGet(username, head);
	printf("emailhash:%s\n", emailhash.c_str());
	int k = emailhash.find("-");
	string hash;
	if (k != std::string::npos) {
		hash = emailhash.substr(k + 1);
	}
	string contenthash = "emailcontent-";
	contenthash += hash;
	string contentdata = toGet(username, contenthash);
	printf("contentdata: %s\n", contenthash.c_str());
	if (this->serverDataMap[username][contenthash].compare(contentdata) == 0) {
		string suc = "+200 OK\r\n" + contentdata;
		return suc;
	} else {
		string err = "-400 ERR";
		return err;
	}
}

string InterFaceAPI::mailDelete(string &m) {
	vector < string > vec;
	mailtokenize(m, &vec, 2);
	if (vec.size() != 2) {
		string err = "-400 ERR";
		return err;
	}
	string username = vec[0];
	string head = vec[1];
	string emailhash = toGet(username, head);
	int k = emailhash.find("-");
	string hash;
	if (k != std::string::npos) {
		hash = emailhash.substr(k + 1);
	}
	string contenthash = "emailcontent-";
	contenthash += hash;
	toDelete(username, head);
	toDelete(username, emailhash);
	toDelete(username, contenthash);
	if (this->serverDataMap[username].count(head) == 0) {
		string suc = "+200 OK";
		return suc;
	} else {
		string err = "-400 ERR";
		return err;
	}
}
string InterFaceAPI::checkCommand(string &m) {
	string res;
	if (strstr(m.c_str(), "checkCookie") != NULL) {
		res = checkCookie(m);
		return res;
	} else if (strstr(m.c_str(), "register") != NULL) {
		res = newregister(m);
	} else if (strstr(m.c_str(), "login") != NULL) {
		res = login(m);
	} else if (strstr(m.c_str(), "setCookie") != NULL) {
		res = setCookie(m);
		return res;
	} else if (strstr(m.c_str(), "changePSW") != NULL) {
		res = changePSW(m);
		return res;
	} else if (strstr(m.c_str(), "deleteCookie") != NULL) {
		res = deleteCookie(m);
		return res;
	}
	//folder
	else if (strstr(m.c_str(), "driveCreate") != NULL) {
		res = driveCreate(m);
		return res;
	} else if (strstr(m.c_str(), "driveOpen") != NULL) {
		res = driveOpen(m);
		return res;
	} else if (strstr(m.c_str(), "driveDelete") != NULL) {
		res = driveDelete(m);
		return res;

	} else if (strstr(m.c_str(), "driveRename") != NULL) {
		res = driveRename(m);
		return res;
	} else if (strstr(m.c_str(), "driveMove") != NULL) {
		res = driveMove(m);
		return res;
	} else if (strstr(m.c_str(), "driveUpload") != NULL) {
		res = driveUpload(m);
		return res;
	} else if (strstr(m.c_str(), "driveDownload") != NULL) {
		res = driveDownload(m);
		return res;
	} else if (strstr(m.c_str(), "mailGetuser") != NULL) {
		res = Getuser(m);
		return res;
	} else if (strstr(m.c_str(), "mailRev") != NULL) {
		res = mailRecv(m);
		return res;
	} else if (strstr(m.c_str(), "mailInbox") != NULL) {
		res = mailInbox(m);
		return res;
	} else if (strstr(m.c_str(), "mailFetch") != NULL) {
		res = mailFetch(m);
		return res;
	} else if (strstr(m.c_str(), "mailDelete") != NULL) {
		res = mailDelete(m);
		return res;
	} else {
		cout << "nothing match !!!!!!!!!!!!!!!!!!" << endl;
	}
	return res;
}
