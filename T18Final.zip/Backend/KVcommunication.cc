#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include<map>
#include "KVcommunication.h"
using namespace std;

void checkClient(int socket, int port, char *add, int connect = 0) {
	if (connect == 0) {
		if (port == 5002 || port == 5003) {
			printf(
					"Replication server connected , socket fd is %d , ip is : %s , port : %d\n",
					socket, add, port);
		} else {
			printf(
					"New client connection , socket fd is %d , ip is : %s , port : %d\n",
					socket, add, port);
		}
	} else {
		if (port == 5002 || port == 5003) {
			printf(
					"Replication server disconnected , socket fd is %d , ip is : %s , port : %d\n",
					socket, add, port);
		} else {
			printf(
					"New client disconnection , socket fd is %d , ip is : %s , port : %d\n",
					socket, add, port);
		}
	}

}

int connect2Port(int socket, int masterPort) {
	struct sockaddr_in masterservaddr;
	bzero(&masterservaddr, sizeof(masterservaddr));
	masterservaddr.sin_family = AF_INET;
	masterservaddr.sin_addr.s_addr = INADDR_ANY;
	masterservaddr.sin_port = htons(masterPort);
	int out = 0;
	if (connect(socket, (struct sockaddr*) &masterservaddr,
			sizeof(masterservaddr)) < 0) {
//		printf("\nConnection Failed \n");
		return -1;
//		exit(EXIT_FAILURE);
	} else {
//		printf("Connect to %d success\n", masterPort);
		return 1;
	}

}

int createSocket(int PORT) {
	int sopt = 1;
	int master_socket;
	if ((master_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	//set master socket to allow multiple connections
	if (setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
			(char*) &sopt, sizeof(sopt)) < 0) {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	struct sockaddr_in servaddr;
	bzero(&servaddr, sizeof(servaddr));
	//type of socket created
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = INADDR_ANY;
	servaddr.sin_port = htons(PORT);

	//bind the socket to localhost port 8888
	if (bind(master_socket, (struct sockaddr*) &servaddr, sizeof(servaddr))
			< 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
//	printf("Listener on port %d \n", PORT);
	return master_socket;
}

void shutServer(int socket) {
	close(socket);
	shutdown(socket, 2);
}

int reconnectServer(int selfPort, int connectedPort) {
	int socket = createSocket(selfPort);
	int out = connect2Port(socket, connectedPort);
	if(out<0){
		return -1;
	}else{
		return socket;
	}
//	return socket;
}
int listenServer(int PORT, int maxSocket) {
	int socket = createSocket(PORT);
	if (listen(socket, 10) < 0) {
		perror("listen");
		exit(EXIT_FAILURE);
	}
	return socket;
}
//void getNewclient(int socket, int *client_socket,
//		map<int, int> &client_socket_port, map<int, int> &client_port2socket,
//		map<int, string> &client_socket_add, int size) {
////	string k = ;
//	string message = "ECHO Daemon v1.0 \r\n";
//	struct sockaddr_in clientaddr;
//	socklen_t cliendaddrlen = sizeof(clientaddr);
//	int new_socket;
//	if ((new_socket = accept(socket, (struct sockaddr*) &clientaddr,
//			(socklen_t*) &cliendaddrlen)) < 0) {
//		perror("accept");
//		exit(EXIT_FAILURE);
//	}
//	int sock = new_socket;
//	checkClient(sock, ntohs(clientaddr.sin_port),
//			inet_ntoa(clientaddr.sin_addr), 0);
//	int msglen = message.size();
//	if (send(sock, message.c_str(),msglen , 0) != msglen) {
//		perror("send");
//	}
//
//	puts("Welcome message sent successfully");
//
//	for (int i = 0; i < sizeof(client_socket); i++) {
//		if (client_socket[i] == 0) {
//			client_socket[i] = new_socket;
//			client_socket_port[new_socket] = ntohs(clientaddr.sin_port);
//			client_socket_add[new_socket] = inet_ntoa(clientaddr.sin_addr);
//			client_port2socket[ntohs(clientaddr.sin_port)] = new_socket;
//			printf("Adding to list of sockets as %d\n", i);
//			break;
//		}
//	}
//}
int acceptNewclient(int socket, basicServer &socketInfo){
//	string message = "ECHO Daemon v1.0 \r\n";
	struct sockaddr_in clientaddr;
	socklen_t cliendaddrlen = sizeof(clientaddr);
	int new_socket;
	if ((new_socket = accept(socket, (struct sockaddr*) &clientaddr,
			(socklen_t*) &cliendaddrlen)) < 0) {
		perror("accept");
		exit(EXIT_FAILURE);
	}
	int sock = new_socket;
	checkClient(sock, ntohs(clientaddr.sin_port),
			inet_ntoa(clientaddr.sin_addr), 0);
	printf("%d %d\n",sock,ntohs(clientaddr.sin_port));


	puts("Welcome message sent successfully");
	socketInfo.put(ntohs(clientaddr.sin_port), new_socket);
	return ntohs(clientaddr.sin_port);
}

