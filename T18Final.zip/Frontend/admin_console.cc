#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <iostream>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <map>
#include <sstream> 
#include <limits.h>
#include <fstream>

using namespace std;

#define max_connection 256 //max connection concurrenctly
int vflag = 0;  // vflag for -v user input
volatile int sig_flag = 0;  // volatile sig_flag for synchronization connection while signal captured

unordered_set<pthread_t> thread_set;
unordered_set<int> sock_set;

vector<int> fe_ports = {10000, 10001,10002};


// write to client with while loop
int sock_write(int fd, char *buffer){
	int total_len = strlen(buffer);
	int sent_byte = 0;
	while(sent_byte < total_len){
		int one_time_sent = write(fd, &buffer[sent_byte],total_len-sent_byte);
		if(one_time_sent < 0){
	        fprintf(stderr, "error write (server)\n");
	        exit(1);
		}
		sent_byte += one_time_sent;
	}
	return sent_byte;
}

int bindSock(int PORT, int outport){
	int sopt = 1;
	int master_socket;
	if ((master_socket = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	//set master socket to allow multiple connections
	if (setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
			(char*) &sopt, sizeof(sopt)) < 0) {
		perror("setsockopt");
		exit(EXIT_FAILURE);
	}
	struct sockaddr_in servaddr;
	bzero(&servaddr, sizeof(servaddr));
	//type of socket created
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = INADDR_ANY;
	servaddr.sin_port = htons(PORT);

	//bind the socket to localhost port 8888
	if (bind(master_socket, (struct sockaddr*) &servaddr, sizeof(servaddr))
			< 0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

	struct sockaddr_in masterservaddr;
	bzero(&masterservaddr, sizeof(masterservaddr));
	masterservaddr.sin_family = AF_INET;
	masterservaddr.sin_addr.s_addr = INADDR_ANY;
	masterservaddr.sin_port = htons(outport);
	int out = 0;
	if (connect(master_socket, (struct sockaddr*) &masterservaddr,
			sizeof(masterservaddr)) < 0) {
		printf("\nConnection Failed \n");
		return -1;
	} else {
		printf("Connect to %d success\n", outport);
		return master_socket;
	}
}
string sendMsg(string &message) {
	int PORT = 8888;
	int outport = 8020;
	int sock = bindSock(PORT, outport);
	printf("sock:%d\n",sock);
	if (send(sock, message.c_str(), strlen(message.c_str()), 0)
			!= strlen(message.c_str())) {
		perror("send");
	}
	char buffer[102401];
	int valread;
	while (1) {
		if ((valread = read(sock, buffer, 102400)) != 0) {
			printf("%s\n",buffer);
			break;
		}
	}
	string outMsg;
	outMsg.append(buffer);
	close(sock);
	shutdown(sock,2);
	sleep(1);
	return outMsg;
}


int renderFile(string file_loc,string file_type,int sock){
    ifstream content(&file_loc[0]);
    stringstream html_content;
    string line;
    while(getline(content,line)){
         html_content<<line << "\n";
     }
    string conten_string = html_content.str();
    string tosend = "";
    if (file_type == "html"){
    	tosend += "HTTP/1.1 200 OK\r\n";
    	tosend += "Content-type: text/html\r\n";
    	tosend += "Content-length: "+ to_string(conten_string.length())+"\r\n";
    	tosend += "\r\n";// + "Set-Cookie: sid=123\r\n\r\n";
    }else if(file_type == "css"){
		tosend += "HTTP/1.1 200 OK\r\n";
		tosend += "Content-type: text/css\r\n";
		tosend += "Content-length: "+ to_string(conten_string.length())+"\r\n";
		tosend += "\r\n";// + "Set-Cookie: sid=deleted; expires=Thu, 01 Jan 1970 00:00:00 GMT\r\n\r\n";
	}

    tosend += conten_string;

    sock_write(sock,&tosend[0]);
    return 0;

}

int renderAdmin(vector<string>& portWithStatus,vector<string> & ports2detect, unordered_map<string,string> &value_get ,int sock){
	string send_BE = "8014 getStatus";
	string BE_response = sendMsg(send_BE);
	portWithStatus.clear();
	char* BE_ptr = &BE_response[0];
	if(strncmp(BE_ptr,"-400 ERR",8) == 0){
		renderFile("assets/fail_admin.html","html",sock);
		return 0;
	}
	char* tmp = strtok(BE_ptr," ");
	tmp = strtok(NULL," ");
	while((tmp = strtok(NULL," "))!= NULL ){
		string tmp_str(tmp);
		portWithStatus.push_back(tmp_str);
	}
	stringstream sendstream;

	sendstream << "<!DOCTYPE html>\n";
	sendstream << "<html lang=\"en\">\n";
	sendstream << "   <head>\n";
	sendstream << "       <meta charset=\"UTF-8\">\n";
	sendstream << "       <title>PennCloud Admin</title>\n";
	sendstream << "    </head>\n";
	sendstream << "   <body>\n";
	sendstream << "       <h1 >PennCloud Admin</h1>\n";
	sendstream << "       <ul>\n";
	for(int i = 0; i< ports2detect.size(); i++){
		string curport = ports2detect[i];
		string portStatus = portWithStatus[i];
		sendstream << "          <li>\n";
		sendstream << "          	Server:"<< portStatus  <<"\n";
		sendstream << " <form action=\"/Admin/kill/"<< curport  << "\" method= \"POST\">\n";
		sendstream << "	    <input type=\"submit\" value=\"KILL\">\n";
		sendstream << "	</form> \n";

		sendstream << " <form action=\"/Admin/restart/"<< curport  << "\" method= \"POST\">\n";
		sendstream << "	    <input type=\"submit\" value=\"Recovery\">\n";
		sendstream << "	</form> \n";

		sendstream << "	<form action=\"/Admin/getValue/"<< curport << "\" method= \"POST\">\n";
		sendstream << "	    <input type=\"text\" name=\"storeIndex\" placeholder=\"Storage Chunk Index\">\n";
		sendstream << "	    <input type=\"submit\"  value=\"Getvalue\">\n";
		sendstream << "	</form>  \n";
		string value_now = value_get[curport];
		sendstream << value_now << "\n";
		sendstream << "          </li>\n";
	}
	sendstream << "	</ul>\n";
	sendstream << "  </body>\n";

	sendstream << "</html>\n";
	string sendstr = sendstream.str();
	string tosend = "";
	tosend += "HTTP/1.1 200 OK\r\n";
	tosend += "Content-type: text/html\r\n";
	tosend += "Content-length: "+ to_string(sendstr.length())+"\r\n";
	tosend += "\r\n";
	tosend += sendstr;
	sock_write(sock,&tosend[0]);
	return 0;
}

// handle sigint in main thread
void sig_handler (int signuum ) {
	sig_flag = 1;
	for(auto sock: sock_set){
		cout << sock << endl;
		sock_write(sock,(char *)"-ERR Server shutting down\r\n");
		if(close(sock) < 0){
		    fprintf(stderr,"error close %d socket", sock);
			exit(1);
		}
	}

	for(auto thread: thread_set){
		pthread_cancel(thread);
	}
	exit(0);
}

// thread working
void *thread_handler(void *new_sock)
{

    int sock = *(int *)new_sock;
    char *write_msg;

    //initilize some variables
    char read_buffer[10250];
    char temp_buffer[10250];
    int onetime_read_size;
    int read_count = 0;
    int line_flag = 0;
    int line_length;
    unordered_map<string,string> port2status;

    vector<string> ports2detect;
    ports2detect.push_back("5001");
    ports2detect.push_back("5002");
    ports2detect.push_back("5003");
    ports2detect.push_back("6001");
    ports2detect.push_back("6002");
    ports2detect.push_back("6003");
    ports2detect.push_back("7001");
    ports2detect.push_back("7002");
    ports2detect.push_back("7003");

    vector<string> portWithStatus;
    unordered_map<string,string> value_get;
    value_get["5001"] = "";
    value_get["5002"] = "";
    value_get["5003"] = "";
    value_get["6001"] = "";
    value_get["6002"] = "";
    value_get["6003"] = "";
    value_get["7001"] = "";
    value_get["7002"] = "";
    value_get["7003"] = "";
//    write_msg = (char*)"220 localhost service ready!\r\n";
//    sock_write(sock,write_msg);

    // read from client
    while( (onetime_read_size = read(sock , &read_buffer[read_count] , sizeof(read_buffer)-1)) > 0)
    {
    	read_buffer[onetime_read_size] = '\0';
    	cout << read_buffer << endl;

		if(strncmp(read_buffer,"GET",3)==0 ){
			string request(read_buffer);
			char* request_ptr = strstr(read_buffer,"GET ") + strlen("GET ");
			char* request_tail = strstr(request_ptr," ");
			string request_cont = request.substr(request_ptr-read_buffer,request_tail-request_ptr);
			char* req_ptr = &request_cont[0];
			if(strcmp(req_ptr,"/Admin")==0){
				renderAdmin( portWithStatus,ports2detect, value_get ,sock);
			}

		}else if(strncmp(read_buffer,"POST",4)==0){
			string request(read_buffer);
			char* request_ptr = strstr(read_buffer,"POST ") + strlen("POST ");
			char* request_tail = strstr(request_ptr," ");
			string request_cont = request.substr(request_ptr-read_buffer,request_tail-request_ptr);
			char* res_ptr = &request_cont[0];
			char* cmd_ptr =  strstr(res_ptr,"/Admin/") + strlen("/Admin/");
			char* cmd_tail = strstr(cmd_ptr,"/");
			string cmd_str = request_cont.substr(cmd_ptr-res_ptr,cmd_tail-cmd_ptr);
			string port_we_handle(cmd_tail+1);
			if(cmd_str =="kill"){
				string send_BE = port_we_handle + " shutdown";
				cout << send_BE << endl;
				string BE_response = sendMsg(send_BE);
				cout << BE_response << endl;
				char* BE_ptr = &BE_response[0];
				if(strncmp(BE_ptr,"-400 ERR",8) == 0){
					renderFile("assets/fail_admin.html","html",sock);
				}else if(strncmp(BE_ptr,"+200 OK",7) == 0){
					renderAdmin( portWithStatus,ports2detect, value_get ,sock);
				}
			}else if(cmd_str =="restart"){
				string send_BE = port_we_handle + " restart";
				cout << send_BE << endl;
				string BE_response = sendMsg(send_BE);
				cout << BE_response << endl;
				char* BE_ptr = &BE_response[0];
				if(strncmp(BE_ptr,"-400 ERR",8) == 0){
					renderFile("assets/fail_admin.html","html",sock);
				}else if(strncmp(BE_ptr,"+200 OK",7) == 0){
					renderAdmin( portWithStatus,ports2detect, value_get ,sock);
				}
			}else if(cmd_str =="getValue"){
				string indexsend = strstr(read_buffer,"storeIndex=") + strlen("storeIndex=");
				string send_BE = port_we_handle + " getValue " + indexsend;
				cout << send_BE << endl;
				string BE_response = sendMsg(send_BE);
				cout << BE_response << endl;
				char* BE_ptr = &BE_response[0];
				if(strncmp(BE_ptr,"-400 ERR",8) == 0){
					renderFile("assets/fail_admin.html","html",sock);
				}else if(strncmp(BE_ptr,"+200 OK",7) == 0){
					value_get[port_we_handle] = BE_response;
					renderAdmin( portWithStatus,ports2detect, value_get ,sock);
				}

			}

		}
    }
    if(onetime_read_size == 0)
    {
    	sock_set.erase(sock);
    	cout << "one thread terminated" << endl;
    	return 0;
    }else{
        fprintf(stderr, "error read (server)\n");
        exit(1);
    }
    cout << "end reached" << endl;
	return 0;

}



int main(int argc , char *argv[])
{
	//get user input, initial port is 10000 (-v(debug mode)  -a(std error)  -p(port) 10000)
	int PORT = 8800;
	int c;

	while ((c = getopt (argc, argv, "p:av")) != -1)
	switch (c)
	  {
	  case 'a':{
		fprintf(stderr,"Full Name: Xinlong Zheng, SEAS login: xinlongz\n");
		exit(1);
	  }
		break;

	  case 'v':{
		vflag = 1;
	  }
		break;

	  case 'p':{

		  string s = optarg;
		  auto it = s.begin();
		  while (it != s.end() && std::isdigit(*it)) ++it;

		  if(!s.empty() && it == s.end() && atoi(optarg) >= 1){
			  PORT = atoi(optarg);
		  }
		  else{
			fprintf(stderr, "Option -n requires a positive integer argument.\n");
			exit(1);
		  }
	  }
		break;

	  case '?':
		if (optopt == 'p')
		  fprintf (stderr, "Option -%c requires an argument.\n", optopt);
		else if (isprint (optopt))
		  fprintf (stderr, "Unknown option `-%c'.\n", optopt);
		else
		  fprintf (stderr,"Unknown option character `\\x%x'.\n", optopt);
		exit(1);
	  default:
		abort ();
	  }
     // construct sock connection
    if ( signal(SIGINT, sig_handler) == SIG_ERR ) {
        fprintf(stderr, "error capture signal ctrl+c (server)\n");
        exit(1);
    }

    int server_fd , new_sock , addrlen, opt =1;
    struct sockaddr_in server_addr, client_addr;

    if((server_fd = socket(AF_INET , SOCK_STREAM , 0)) == 0){
        fprintf(stderr, "error create socket (server)\n");
        exit(1);
    }

    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,
                                                  &opt, sizeof(opt)))
    {
        fprintf(stderr, "error setosocketopt (server)\n");
        exit(1);
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons( PORT );

    if( bind(server_fd,(struct sockaddr *)&server_addr , sizeof(server_addr)) < 0)
    {
        fprintf(stderr, "error bind (server)\n");
        exit(1);
    }


    if (listen(server_fd, max_connection) < 0)
    {
        fprintf(stderr, "error listen (server)\n");
        exit(1);
    }

    addrlen = sizeof(struct sockaddr_in);

    //waiting for connection and create threads
    while(true)
    {
    	new_sock = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t*)&addrlen);
    	if(new_sock < 0){
            fprintf(stderr, "error accept (server)\n");
            exit(1);
    	}
     // handle sychronization issue
    	if(sig_flag == 1){
    		sock_write(new_sock,(char *)"-ERR Server shutting down\r\n");
    		if(close(new_sock) < 0){
    		    fprintf(stderr,"error close %d server", new_sock);
    			exit(1);
    		}
    	}
    	//create thread and make a record
    	if(sig_flag == 0){
        	cout << '['<< new_sock << ']' << " New connection" << endl;

        	pthread_t thread;
			if( pthread_create(&thread , NULL ,  thread_handler , (void*) &new_sock) < 0)
			{
				fprintf(stderr, "error create thread (server)\n");
				exit(1);
			}
			thread_set.insert(thread);
			sock_set.insert(new_sock);

    	}
    }

    return 0;
}
