#ifndef _CLIENT_H
#define _CLIENT_H
#include "httpserver.h"
// write to client with while loop

#define max_connection 2048 //max connection concurrenctly
int PORT = 10000;
int vflag = 0;  // vflag for -v user input
volatile int sig_flag = 0;  // volatile sig_flag for synchronization connection while signal captured

unordered_set<pthread_t> thread_set;
unordered_set<int> sock_set;
bool thread_exist[max_connection] = { false };

int sock_write(int fd, char *buffer);


#endif
