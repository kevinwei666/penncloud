/*
 * MapFileFunctions.cc
 *
 *  Created on: Dec 6, 2020
 *      Author: cis505
 */
#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/file.h>
#include <unordered_map>
#include "MapFileFunctions.h"
using namespace std;

void MapFile::MapToFILE(unordered_map<string, unordered_map<string, string>> hMap,
		string fileName) {
	//cout << "enter this function map to file" << endl;
	if (hMap.size() == 0) {
		cout << " map size is zero" << endl;
		return;
	}
	FILE *fp;
	fp = fopen(fileName.c_str(), "w");
	for (auto it : hMap) {
		string userName = it.first;
		for (auto inner : hMap[userName]) {
			if (inner.first.length() == 0) {
				continue;
			}
			string message = userName + " " + inner.first + " " + inner.second
					+ "\r\n";
			fprintf(fp, "%s", message.c_str());
			fflush(fp);
		}
	}
}

unordered_map<string, unordered_map<string, string>> MapFile::FileToMap(
		string fileName) {
	unordered_map<string, unordered_map<string, string>> result;
	if (fileName.length() == 0) {
		return result;
	}
	printf("start\n");
	FILE *fp;
	if((fp = fopen(fileName.c_str(), "r")) == NULL){
		return result;
	}
//	fp = fopen(fileName.c_str(), "r");
	char line[1024];
	string latter = "";
	while (fgets(line, 1024, fp)) {
		printf("%s\n",line);
		if (strcmp(line, "") == 0) {
			break;
		}
		latter.append(line);
		int k1 = latter.find("\r\n");
		while (k1 != std::string::npos) {
			string allMsg = latter.substr(0, k1);
			latter = latter.substr(k1 + 2);
			int k2 = allMsg.find(" ");
			string username = allMsg.substr(0, k2);
			allMsg = allMsg.substr(k2 + 1);
			k2 = allMsg.find(" ");
			string column = allMsg.substr(0, k2);
			string value = allMsg.substr(k2 + 1);
			result[username][column] = value;
			k1 = latter.find("\r\n");
		}
	}
	return result;
}


