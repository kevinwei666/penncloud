/*
 * BackendMaster.h
 *
 *  Created on: Dec 3, 2020
 *      Author: cis505
 */

#include <stdlib.h>
#include <string>
#include <stdio.h>
#include <sys/file.h>
#include <unordered_map>
#include <vector>
#ifndef BACKENDMASTER_H_
#define BACKENDMASTER_H_
using namespace std;
class backendMaster{
	//save the backedserver into three parts, each part has three server
	// one primary server, two secondary servers
	public: unordered_map<string, vector<string>> serverMap;
	 //groupName -> primaryServer address
	public: unordered_map<string, string> primaryMap;
	 // groupName -> clientid
	public: unordered_map<string, vector<string>> groupToclient;
	 // clientName -> groupName
	public: unordered_map<string, string> clientTogroup;
	//serverAddress -> groupName
	public: unordered_map<string, string> serverAddressTogroup;
	//groupName -> serverAddressses
	public: unordered_map<string, vector<string>> groupToservers;
	 //client number
	public: int clientNum;

     public: unordered_map<string, vector<string>> constructServerMap(string fileName);

     public: unordered_map<string, string> constructPrimaryMap(string groupName, string primaryAddress, unordered_map<string, string> primaryMap);

     public: unordered_map<string, vector<string>> constructGroupToClient(string groupName, string clientId, unordered_map<string, vector<string>> groupToclient);

     public: string gettargetClientGroup (string userName);

     public: unordered_map<string, string> constructClientToGroup(unordered_map<string, string> clientTogroup,
    		                                                              unordered_map<string, vector<string>> groupToclient);

     public: string getAssignedServer(string userName);

     public: string getPort(string address);

     public: string getIpAdress(string address);

     public: void constructServerAddressTogroup();

     public: void constructGroupToServers();



};

#endif /* BACKENDMASTER_H_ */
