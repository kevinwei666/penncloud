#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <ctype.h>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include "KVcommunication.h"
#include "backLog.h"
#include "defaultport.h"
#include "basicServer.h"
#include "interface.h"
#include "MapFileFunctions.h"
#include "commandOperation.h"
#include "BackendMaster.h"
#define TRUE   1
#define FALSE  0
int PORT = 8014;
vector<int> portvec;
int debug = 0;
int second = 0;
int masterPort = 0;
int adminPort = 0;
using namespace std;
int mode = 0;
MapFile MF;
command kvCommand;
backendMaster bm;
InterFaceAPI IFA;
vector<int> lostConnection;
map<int, int> port2socket;
void reconnectPort(basicServer &socketInfo, int port, int outport) {
	if (!socketInfo.checkPort(outport)) {
		int reconnect_socket = reconnectServer(port, outport);
		if (reconnect_socket < 0) {
			printf("Port %d should be open first\n", outport);
			//									exit(1);
		} else {
			printf("Connect to %d\n", outport);
			socketInfo.put(outport, reconnect_socket);
		}
	}
}

void send2port(int port, string &buffer, basicServer &socketInfo) {
	if (send(socketInfo.getSocketbyport(port), buffer.c_str(),
			strlen(buffer.c_str()), 0) != strlen(buffer.c_str())) {
		perror("send");
	}
}
void reply(int socket, string &buffer) {
	if (send(socket, buffer.c_str(), strlen(buffer.c_str()), 0)
			!= strlen(buffer.c_str())) {
		perror("send");
	}
}
void shutAllserver(basicServer &socketInfo, int max_clients,
		int master_socket) {
	for (int i = 0; i < max_clients; i++) {
		int sock = socketInfo.getSocketbyid(i);
		if (sock > 0 && sock != master_socket) {
			shutServer(sock);
			socketInfo.removeSocket(sock);
		}
	}
}

bool ifFromBack(int port) {
	if (port == 5001 || port == 5002 || port == 5003 || port == 6001
			|| port == 6002 || port == 6003 || port == 7001 || port == 7002
			|| port == 7003) {
		return true;
	}
	return false;
}
void MapToFILE(unordered_map<string, unordered_map<string, string>> hMap,
		string fileName) {
	//cout << "enter this function map to file" << endl;
	if (hMap.size() == 0) {
		cout << " map size is zero" << endl;
		return;
	}
	FILE *fp;
	fp = fopen(fileName.c_str(), "w");
	for (auto it : hMap) {
		string userName = it.first;
		for (auto inner : hMap[userName]) {
			if (inner.first.length() == 0) {
				continue;
			}
			string message = userName + " " + inner.first + " " + inner.second
					+ "\r\n";
			fprintf(fp, "%s", message.c_str());
			fflush(fp);
		}
	}
}

unordered_map<string, unordered_map<string, string>> FileToMap(
		string fileName) {
	unordered_map<string, unordered_map<string, string>> result;
	if (fileName.length() == 0) {
		return result;
	}
	printf("start\n");
	FILE *fp;
	if((fp = fopen(fileName.c_str(), "r")) == NULL){
		return result;
	}
//	fp = fopen(fileName.c_str(), "r");
	char line[1024];
	string latter = "";
	while (fgets(line, 1024, fp)) {
		printf("%s\n",line);
		if (strcmp(line, "") == 0) {
			break;
		}
		latter.append(line);
		int k1 = latter.find("\r\n");
		while (k1 != std::string::npos) {
			string allMsg = latter.substr(0, k1);
			latter = latter.substr(k1 + 2);
			int k2 = allMsg.find(" ");
			string username = allMsg.substr(0, k2);
			allMsg = allMsg.substr(k2 + 1);
			k2 = allMsg.find(" ");
			string column = allMsg.substr(0, k2);
			string value = allMsg.substr(k2 + 1);
			result[username][column] = value;
			k1 = latter.find("\r\n");
		}
	}
	return result;
}
int main(int argc, char *argv[]) {
	int sopt = TRUE;
	int master_socket, addrlen, client_socket[30], max_clients = 30, activity,
			i, valread, sd;
	map<int, string> client_socket_add;
	map<int, int> client_socket_port;
	map<int, int> client_port2socket;
	int max_sd;

	char buffer[102400];
	int PORTbuffer[3];

	int opt;
	string path = "";
	string modeString = "";
	int masterPort = 8014;
	int adminPort = 8020;
	int checkPort = 8001;
	int listen_socket, admin_socket, primary_socket, second_socket1,
			second_socket2, check_socket;
	//construct the keyword of this server
//	MF.constructKeyWord();
	while ((opt = getopt(argc, argv, "p:avm:")) != -1) {
		switch (opt) {
		case 'p':
			PORT = atoi(optarg);
			portassign(PORT, portvec);
			break;
		case 'a':
			fprintf(stderr, "Name: Shaozhe Lyu, Login: shaozhe\n");
			exit(1);
			break;
		case 'v':
			debug = 1;
			break;
		case 'm':
			modeString.append(optarg);
			if (strcmp(modeString.c_str(), "Primary") == 0) {
				mode = 0;
			} else if (strcmp(modeString.c_str(), "Secondary") == 0) {
				mode = 1;
			} else if (strcmp(modeString.c_str(), "Master") == 0) {
				mode = 2;
			} else if (strcmp(modeString.c_str(), "Admin") == 0) {
				mode = 3;
			}
			break;
		case '?':
			break;
		}
	}
	backLog log;
	log.setLog(path, PORT);
	string fname = "DataFile - " + to_string(PORT);
	IFA.serverDataMap = MF.FileToMap(fname);
	//cout << "the size of the server map is " << IFA.serverDataMap.size() << endl;
	//log ----> map
	InterFaceAPI IFA_log_begin;
	vector < string > logVector;
	logVector = log.readFile();
	int receiveData = 0;
	for (int i = 0; i < logVector.size(); i++) {
		IFA_log_begin.checkCommand(logVector[i]);
	}
	if (IFA_log_begin.serverDataMap.size() != 0) {
		for (auto it : IFA_log_begin.serverDataMap) {
			string outKey = it.first;
			unordered_map < string, string > innerMap =
					IFA_log_begin.serverDataMap[outKey];
			for (auto iit : innerMap) {
				string innerKey = iit.first;
				IFA.serverDataMap[outKey][innerKey] =
						IFA_log_begin.serverDataMap[outKey][innerKey];
			}
		}
	}
	printf("%s\n", log.showmode() ? "WRITE" : "READ");

	basicServer socketInfo;
	socketInfo.setServer(max_clients);

	for (i = 0; i < max_clients; i++) {
		client_socket[i] = 0;
	}
	admin_socket = 0;
	master_socket = 0;
	int shutdown = 0;
	int start2write = 0;

	listen_socket = listenServer(PORT, 10);
	cout << "this is a master server" << endl;
	bm.serverMap = bm.constructServerMap("addressFile");
	bm.primaryMap = bm.constructPrimaryMap("GroupA", "127.0.0.1:5001",
			bm.primaryMap);
	bm.primaryMap = bm.constructPrimaryMap("GroupB", "127.0.0.1:6001",
			bm.primaryMap);
	bm.primaryMap = bm.constructPrimaryMap("GroupC", "127.0.0.1:7001",
			bm.primaryMap);
	bm.constructServerAddressTogroup();
	bm.constructGroupToServers();

	fd_set readfds;
	int lost = 0;
	int only_once = 0;

	while (TRUE) {

		FD_ZERO(&readfds);
		FD_SET(listen_socket, &readfds);
		max_sd = listen_socket;
		//add child sockets to set
		for (i = 0; i < max_clients; i++) {
			sd = socketInfo.getSocketbyid(i);
			if (sd > 0) {
				FD_SET(sd, &readfds);
			}
			if (sd > max_sd) {
				max_sd = sd;
			}
		}
		activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
		if ((activity < 0) && (errno != EINTR)) {
			printf("select error %d %d\n", activity, errno);
		}
		//accept new connection from new port
		int newportAcc;
		if (FD_ISSET(listen_socket, &readfds)) {
			newportAcc = acceptNewclient(listen_socket, socketInfo);
			if (newportAcc == 5001) {
				if (socketInfo.checkPort(5002) == false
						&& socketInfo.checkPort(5003) == false) {
					bm.primaryMap["GroupA"] = "127.0.0.1:5001";
				}
				cout << "5001RIGHT NOW REIMARY" << bm.primaryMap["GroupA"]
						<< endl;
			}
			if (newportAcc == 5002) {
				if (socketInfo.checkPort(5001) == false
						&& socketInfo.checkPort(5003) == false) {
					bm.primaryMap["GroupA"] = "127.0.0.1:5002";
				}
				cout << "5002RIGHT NOW REIMARY" << bm.primaryMap["GroupA"]
						<< endl;
			}
			if (newportAcc == 5003) {
				if (socketInfo.checkPort(5001) == false
						&& socketInfo.checkPort(5002) == false) {
					bm.primaryMap["GroupA"] = "127.0.0.1:5003";
				}
				cout << "5003RIGHT NOW REIMARY" << bm.primaryMap["GroupA"]
						<< endl;
			}
			if (newportAcc == 6001) {
				if (socketInfo.checkPort(6002) == false
						&& socketInfo.checkPort(6003) == false) {
					bm.primaryMap["GroupB"] = "127.0.0.1:6001";
				}
				cout << "6001RIGHT NOW REIMARY" << bm.primaryMap["GroupB"]
						<< endl;
			}
			if (newportAcc == 6002) {
				if (socketInfo.checkPort(6001) == false
						&& socketInfo.checkPort(6003) == false) {
					bm.primaryMap["GroupB"] = "127.0.0.1:6002";
				}
				cout << "6002RIGHT NOW REIMARY" << bm.primaryMap["GroupB"]
						<< endl;
			}
			if (newportAcc == 6003) {
				if (socketInfo.checkPort(6001) == false
						&& socketInfo.checkPort(6002) == false) {
					bm.primaryMap["GroupB"] = "127.0.0.1:6003";
				}
				cout << "6003RIGHT NOW REIMARY" << bm.primaryMap["GroupB"]
						<< endl;
			}
			if (newportAcc == 7001) {
				if (socketInfo.checkPort(7002) == false
						&& socketInfo.checkPort(7003) == false) {
					bm.primaryMap["GroupC"] = "127.0.0.1:7001";
				}
				cout << "7001RIGHT NOW REIMARY" << bm.primaryMap["GroupC"]
						<< endl;
			}
			if (newportAcc == 7002) {
				if (socketInfo.checkPort(7001) == false
						&& socketInfo.checkPort(7003) == false) {
					bm.primaryMap["GroupC"] = "127.0.0.1:7002";
				}
				cout << "7002RIGHT NOW REIMARY" << bm.primaryMap["GroupC"]
						<< endl;
			}
			if (newportAcc == 7003) {
				if (socketInfo.checkPort(7001) == false
						&& socketInfo.checkPort(7002) == false) {
					bm.primaryMap["GroupC"] = "127.0.0.1:7003";
				}
				cout << "7003RIGHT NOW REIMARY" << bm.primaryMap["GroupC"]
						<< endl;
			}
		}

		for (i = 0; i < max_clients; i++) {
			sd = socketInfo.getSocketbyid(i);
			bool ifBack = ifFromBack(socketInfo.getPortbysocket(sd));
			if (FD_ISSET(sd, &readfds)) {
				int globalPort = socketInfo.getPortbysocket(sd);
				if (shutdown == 1 && sd != admin_socket) {
					continue;
				}
				struct sockaddr_in clientaddr;

				socklen_t cliendaddrlen = sizeof(clientaddr);
				if ((valread = read(sd, buffer, 102400)) == 0) {
					string crashPort = to_string(
							socketInfo.getPortbysocket(sd));
					//cout<< " PORT" << crashPort <<"CRASH!!!!!!!!!!!!!!!!!!"<< endl;
					getpeername(sd, (struct sockaddr*) &clientaddr,
							(socklen_t*) &cliendaddrlen);
					int sock = sd;
					checkClient(sock, ntohs(clientaddr.sin_port),
							inet_ntoa(clientaddr.sin_addr), 1);
					//get the crash of the primary server and assign new one
					string crashesAddress;
					crashesAddress.append(inet_ntoa(clientaddr.sin_addr));
					crashesAddress = crashesAddress + ":" + crashPort;
					string groupName = bm.serverAddressTogroup[crashesAddress];
					//cout<< " GROUP" << groupName <<"CRASH!!!!!!!!!!!!!!!!!!"<< endl;
					vector < string > serverAddresses =
							bm.groupToservers[groupName];
					bool newPrimary = false;
					for (int i = 0; i < serverAddresses.size(); i++) {
						if (serverAddresses[i].compare(crashesAddress) == 0) {
							continue;
						}
						string newip = bm.getIpAdress(serverAddresses[i]);
						string newport = bm.getPort(serverAddresses[i]);
						int portNum = stoi(newport);
						bool ifhasport = socketInfo.checkPort(portNum);
						if (ifhasport == true) {
							//set the new primary
							newPrimary = true;
							string primary = "primary";
							cout << "send the message primary to port "
									<< portNum << endl;
							send2port(portNum, primary, socketInfo);
							string addressOfserver = newip + ":" + newport;
							bm.primaryMap = bm.constructPrimaryMap(groupName,
									addressOfserver, bm.primaryMap);
							for (int i = 0; i < serverAddresses.size(); i++) {
								if (serverAddresses[i].compare(crashesAddress)
										== 0
										|| serverAddresses[i].compare(
												addressOfserver) == 0) {
									continue;
								}
								string otherport = bm.getPort(
										serverAddresses[i]);
								if (socketInfo.checkPort(stoi(otherport))
										== false) {
									continue;
								}
								//string otherport = bm.getPort(serverAddresses[i]);
//								cout << "THE PORT " << otherport
//										<< " get primaryport " << newport
//										<< endl;
//								int otherportNum = stoi(otherport);
//								string primaryMessage = "primaryport "
//										+ newport;
//								send2port(otherportNum, primaryMessage,
//										socketInfo);
							}
							break;
						}
					}
					if (newPrimary == false) {
						cout << "no new primary server in group " << groupName
								<< endl;
						bm.primaryMap.erase(groupName);
					}

					close(sd);
					socketInfo.removeSocket(sock);
				} else {
					buffer[valread] = '\0';
					string m = "";
					m.append(buffer);
					printf("[%d]:%s\n", globalPort, buffer);
//					if (strstr(m.c_str(), "primary") != NULL) {
//						int portOFback = socketInfo.getPortbysocket(sd);
//						string sADDRESS = "127.0.0.1:" + to_string(portOFback);
//						string gNAME = bm.serverAddressTogroup[sADDRESS];
//						string res = bm.primaryMap[gNAME];
//						int maohao = res.find(":");
//						string replyPri = res.substr(maohao+1);
//						reply(sd, replyPri);
//					}
					if (ifBack == false) {
						cout << "get the message from the client:" << m << endl;
						int port = socketInfo.getPortbysocket(sd);
						string addressStr = "127.0.0.1:" + to_string(port);
						//check if this message is from the client or the backend server
						if (bm.serverMap.count(addressStr) == 0) {

							if (m.compare("getUser") == 0) {
								string nameList;
								if (bm.clientTogroup.size() == 0) {
									string err = "ERR: -400 ERR";
									send2port(port, err, socketInfo);
								} else {
									for (auto it : bm.clientTogroup) {
										string username = it.first;
										nameList += username;
										nameList += " ";
									}
									string suc = "+200 OK " + nameList;
									send2port(port, suc, socketInfo);
								}

							} else if (strstr(m.c_str(), "getStatus") != NULL) {
								vector<int> portVector;
								portVector.push_back(5001);
								portVector.push_back(5002);
								portVector.push_back(5003);
								portVector.push_back(6001);
								portVector.push_back(6002);
								portVector.push_back(6003);
								portVector.push_back(7001);
								portVector.push_back(7002);
								portVector.push_back(7003);
								string status = "+200 OK ";
								bool ifLive;
								for (int i = 0; i < portVector.size(); i++) {
									ifLive = socketInfo.checkPort(
											portVector[i]);
									if (ifLive == true) {
										string portStatus = to_string(
												portVector[i]) + ":" + "Live ";
										status += portStatus;
									} else {
										string portStatus = to_string(
												portVector[i]) + ":" + "Die ";
										status += portStatus;
									}
								}
								send2port(port, status, socketInfo);

							} else {
								string userName = m;
								if (bm.clientTogroup.count(userName) != 0) {
									cout << "old client" << endl;
									string group = bm.clientTogroup[userName];
									string res = bm.primaryMap[group] + "\n";
									reply(sd, res);

								} else {
									cout << "new client" << userName << endl;
									string assignedGroup =
											bm.gettargetClientGroup(userName);
									bm.groupToclient =
											bm.constructGroupToClient(
													assignedGroup, userName,
													bm.groupToclient);
									bm.clientTogroup =
											bm.constructClientToGroup(
													bm.clientTogroup,
													bm.groupToclient);
									string res = bm.getAssignedServer(userName)
											+ "\n";
									reply(sd, res);

								}
							}
						}

					} else if (ifBack == true) {
						if (strstr(m.c_str(), "primary") != NULL) {
							int portOFback = socketInfo.getPortbysocket(sd);
							string sADDRESS = "127.0.0.1:"
									+ to_string(portOFback);
							string gNAME = bm.serverAddressTogroup[sADDRESS];
							string res = bm.primaryMap[gNAME];
							int maohao = res.find(":");
							string replyPri = res.substr(maohao + 1);
							printf("send message\n");
							reply(sd, replyPri);
						}
					}
				}

			}
		}
	}
	return 0;
}
