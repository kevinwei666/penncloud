#include <stdlib.h>
#include <stdio.h>
#include <openssl/md5.h>
#include <errno.h>
#include <unistd.h>
//#include <string.h>
#include<sys/wait.h>
#include<iostream>
#include<vector>
#include<string>
#include<limits.h>
#include <sys/mman.h>
#include <pthread.h>
#include<fstream>
#include<arpa/inet.h>
#include <signal.h>
#include <ctime>
#include <time.h>
#include<dirent.h>
using namespace std;

int port = 11000;
int debug = 0;
void read2Map(string &path);
int main(int argc, char *argv[]) {

	/*This is the code to sparse the terminal command*/
	int opt;
	while ((opt = getopt(argc, argv, "p:av")) != -1) {
		switch (opt) {
		case 'p':
			port = atoi(optarg);
			break;
		case 'a':
			fprintf(stderr, "Name: Shaozhe Lyu, Login: shaozhe\n");
			exit(1);
			break;
		case 'v':
			debug = 1;
			break;
		case '?':
			break;
		}
	}

	if (optind == argc) {
		fprintf(stderr, "Please Enter path\n");
		exit(1);
	}

	for (; optind < argc; optind++) {
		string path = "./";
		path += argv[optind];
//		read2Map(path);
	}

	//Build server socket
	int listen_fd = socket(PF_INET, SOCK_STREAM, 0);
	int sopt = 1;
	if (setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &sopt,
			sizeof(sopt))) {
		perror("setsocketopt");
		exit(EXIT_FAILURE);
	}

	struct sockaddr_in servaddr;
	bzero

}
