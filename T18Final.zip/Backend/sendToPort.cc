#include <stdio.h>
#include <string.h>   //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>   //close
#include <arpa/inet.h>    //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros
#include<string>
#include<map>
#include<vector>
#include <unistd.h>
#include "KVcommunication.h"
#include "backLog.h"
#include "defaultport.h"
#include "basicServer.h"
#include "interface.h"
#include "MapFileFunctions.h"
#include "commandOperation.h"
#include "BackendMaster.h"
#define TRUE   1
#define FALSE  0
int PORT = 5001;
vector<int> portvec;
int debug = 0;
int second = 0;
int masterPort = 0;
int adminPort = 0;
using namespace std;
int mode = 0;
MapFile MF;
command kvCommand;
backendMaster bm;
InterFaceAPI IFA;
vector<int> lostConnection;
map<int, int> port2socket;

void decomposeString(char *buffer, string &out) {
	string a = "";
	a.append(buffer);
	int k = 0;
	if (a.find("\r\n") != std::string::npos) {
		k = a.find("\r\n");
	}
	if (a.find("\n") != std::string::npos) {
		int j = a.find("\n");
		k = min(k, j);
	}
	if (a.find("\r") != std::string::npos) {
		int j = a.find("\r");
		k = min(k, j);
	}
	string m;
	if (k > 0) {
		out = a.substr(0, k);
	} else if (k == 0) {
		out = a;
	}
}
void send2port(int port, string &buffer, basicServer &socketInfo) {
	if (send(socketInfo.getSocketbyport(port), buffer.c_str(),
			strlen(buffer.c_str()), 0) != strlen(buffer.c_str())) {
		perror("send");
	}
}
void reply(int socket, string &buffer) {
	if (send(socket, buffer.c_str(), strlen(buffer.c_str()), 0)
			!= strlen(buffer.c_str())) {
		perror("send");
	}
}
void shutAllserver(basicServer &socketInfo, int max_clients,
		int master_socket) {
	for (int i = 0; i < max_clients; i++) {
		int sock = socketInfo.getSocketbyid(i);

		if (sock > 0 && sock != master_socket) {
			printf("port:%d\n", socketInfo.getPortbysocket(sock));
			shutServer(sock);
			socketInfo.removeSocket(sock);
		}
	}
}
int main(int argc, char *argv[]) {
	int sopt = TRUE;
	int master_socket, addrlen, client_socket[30], max_clients = 30, activity,
			i, valread, sd;
	map<int, string> client_socket_add;
	map<int, int> client_socket_port;
	map<int, int> client_port2socket;
	int max_sd;

	char buffer[102401];
	int PORTbuffer[3];

	int opt;
	string path = "";
	string modeString = "";
	int masterPort = 8014;
	int adminPort = 8020;
	int listen_socket, admin_socket, primary_socket, second_socket1,
			second_socket2;
	string message;
	int outport;
	string value = "";
	while ((opt = getopt(argc, argv, "p:av:f:m:")) != -1) {
		switch (opt) {
		case 'p':
			PORT = atoi(optarg);
			portassign(PORT, portvec);
			break;
		case 'f':
			outport = atoi(optarg);
			break;
		case 'a':
			fprintf(stderr, "Name: Shaozhe Lyu, Login: shaozhe\n");
			exit(1);
			break;
		case 'v':
			value.append(optarg);
			break;
		case 'm':
			modeString.append(optarg);
			message.append(optarg);
			break;
		case '?':
			break;
		}
	}

	backLog log;
	log.setLog(path, PORT);
//	printf("%s\n", log.showmode() ? "WRITE" : "READ");

	basicServer socketInfo;
	socketInfo.setServer(max_clients);
	int socket = reconnectServer(PORT, outport);
	if (strcmp(value.c_str(), "") != 0) {
		message = message + " " + value;
	}
	if (send(socket, message.c_str(), strlen(message.c_str()), 0)
			!= strlen(message.c_str())) {
		perror("send");
	}
	while ((valread = read(socket, buffer, 102400)) != 0) {
		printf("data if %s\n", buffer);
		break;
	}

	close(socket);
	return 0;
}
