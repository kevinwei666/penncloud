#ifndef KVCOMMAND_H
#define KVCOMMAND_H
#include <stdio.h>
#include <string>
#include <map>
#include <tuple>
#include <iostream>
using namespace std;
class KVcommand {
	//password, email-2345:email context;file-2345:file context. Column set
private:
	string f_path;
	map<string, map<string, string>> keyValueMap;
public:

	void writeToFile();

	void readToMap();

	void putFunction(string row, string col, string value);

	string getFunction(string row, string col);

	void cputFunction(string row, string col, string val1, string val2);

	void deleteFunction(string row, string col);
};

#endif
