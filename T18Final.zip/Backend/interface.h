#ifndef INTERFACE_H
#define INTERFACE_H
#include<string>
#include <string.h>
#include<vector>
#include <unordered_map>
using namespace std;
class InterFaceAPI{

    public: unordered_map<string, unordered_map<string, string>> serverDataMap;

	public:	void newtime();
	public: void computeDigest(char *data, int dataLengthBytes,
				unsigned char *digestBuffer);
	public: string hash_compute(string text);
	public: void tokenize(string &m, vector<string> &vec,int vecsize);
	public: string toGet(string &key1, string &key2);
	public: void toPut(string &key1, string &key2, string &value);
	public: void toCput(string &key1, string &key2, string &oldvalue, string &newvalue);
	public: void toDelete(string &key1, string &key2);
	public: string checkCookie(string &m);
	public: string newregister(string &m);
	public: string login(string &m);
	public: string setCookie(string &m);
	public: string changePSW(string &m);
	public: string deleteCookie(string &m);
	public: string hash2name(string &username,string &folderhash);
	public: string name2hash(string &username,string &foldername);
	public: string decodeDir(string &username, string &m, int mode);
	public: string changeContent(string &m);
	public: string hashlist2namelist(string &username,string &m, string &unique, int mode);
	public: string addContent(string &username,string &foldername, string &filehash);
	public: string getName(string &m);
	public: string driveCreate(string &m);
	public: string driveOpen(string &m);
	public: void toDeleteone(string &name, string &username,string &value);
	public: string toDeletefile(string &username,string &value);
	public: string driveDelete(string &m);
	public: string toRename(string &username,string &oldname,string &newname);
	public: void toReplace(string &username, string &oldname, string &newname);
	public: string driveRename(string &m);
	public: void move2rename(string &m);
	public: string driveMove(string &m);
	public: string driveUpload(string &m);
	public: string driveDownload(string &m);
	public: string checkCommand(string &m);
	public:	void mailtokenize(string &m, vector<string> *vec, int vecsize);
	public:	string Getuser(string &m);
	public:	string mailRecv(string &m);
	public:	string mailInbox(string &m);
	public:	string mailFetch(string &m);
	public:	string mailDelete(string &m);


};
#endif
